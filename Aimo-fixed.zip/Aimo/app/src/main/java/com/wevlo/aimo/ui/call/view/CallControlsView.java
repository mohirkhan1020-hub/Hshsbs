package com.wevlo.aimo.ui.call.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.wevlo.aimo.R;

public class CallControlsView extends LinearLayout {

    public interface Listener {
        void onToggleMute();
        void onAudioRouteClicked();
        void onSwitchCameraClicked();
        void onScreenShareClicked();
        void onEndCallClicked();
    }

    private final ImageButton btnMute;
    private final ImageButton btnAudio;
    private final ImageButton btnFlipCamera;
    private final ImageButton btnScreenShare;
    private final ImageButton btnEndCall;
    private Listener listener;

    public CallControlsView(Context context) {
        this(context, null);
    }

    public CallControlsView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CallControlsView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (12 * d);
        setPadding(pad, pad, pad, pad);

        btnAudio = createControlButton(R.drawable.ic_speaker, false);
        btnFlipCamera = createControlButton(R.drawable.ic_camera_flip, false);
        btnMute = createControlButton(R.drawable.ic_mic, false);
        btnScreenShare = createControlButton(R.drawable.ic_screen_share, false);
        btnEndCall = createControlButton(R.drawable.ic_close, true);

        addView(btnAudio);
        addView(btnFlipCamera);
        addView(btnMute);
        addView(btnScreenShare);
        addView(btnEndCall);

        btnAudio.setOnClickListener(v -> {
            if (listener != null) listener.onAudioRouteClicked();
        });
        btnFlipCamera.setOnClickListener(v -> {
            if (listener != null) listener.onSwitchCameraClicked();
        });
        btnMute.setOnClickListener(v -> {
            if (listener != null) listener.onToggleMute();
        });
        btnScreenShare.setOnClickListener(v -> {
            if (listener != null) listener.onScreenShareClicked();
        });
        btnEndCall.setOnClickListener(v -> {
            if (listener != null) listener.onEndCallClicked();
        });
    }

    private ImageButton createControlButton(int iconRes, boolean isEnd) {
        float d = getResources().getDisplayMetrics().density;
        int size = (int) ((isEnd ? 56 : 48) * d);
        int margin = (int) (8 * d);
        ImageButton btn = new ImageButton(getContext());
        LayoutParams lp = new LayoutParams(size, size);
        lp.setMargins(margin, 0, margin, 0);
        btn.setLayoutParams(lp);
        btn.setImageResource(iconRes);
        btn.setColorFilter(ContextCompat.getColor(getContext(), R.color.aimo_white));
        btn.setBackgroundResource(isEnd ? R.drawable.bg_call_action_decline : R.drawable.bg_scroll_bottom_fab);
        return btn;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setVideoMode(boolean isVideo) {
        btnFlipCamera.setVisibility(isVideo ? View.VISIBLE : View.GONE);
    }

    public void setMuted(boolean muted) {
        btnMute.setImageResource(muted ? R.drawable.ic_mic_off : R.drawable.ic_mic);
    }
}
