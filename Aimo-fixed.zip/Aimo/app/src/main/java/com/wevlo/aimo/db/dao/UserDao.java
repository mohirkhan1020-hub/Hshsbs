package com.wevlo.aimo.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.wevlo.aimo.db.entity.UserEntity;

import java.util.List;

@Dao
public interface UserDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(UserEntity user);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<UserEntity> users);

    @Update
    void update(UserEntity user);

    @Query("SELECT * FROM users WHERE uid != :currentUid ORDER BY pinned DESC, lastMessageTime DESC, name ASC")
    LiveData<List<UserEntity>> observeAllUsers(String currentUid);

    @Query("SELECT * FROM users ORDER BY name ASC")
    List<UserEntity> getAllUsersSync();

    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    LiveData<UserEntity> observeUser(String uid);

    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    UserEntity getUserById(String uid);

    @Query("UPDATE users SET lastMessage = :lastMessage, lastMessageSenderId = :senderId, lastMessageTime = :time WHERE uid = :uid")
    void updateChatSummary(String uid, String lastMessage, String senderId, long time);

    @Query("UPDATE users SET unreadCount = 0 WHERE uid = :uid")
    void clearUnread(String uid);

    @Query("UPDATE users SET unreadCount = unreadCount + 1 WHERE uid = :uid")
    void incrementUnread(String uid);

    @Query("UPDATE users SET pinned = :pinned WHERE uid = :uid")
    void setPinned(String uid, boolean pinned);

    @Query("UPDATE users SET muted = :muted WHERE uid = :uid")
    void setMuted(String uid, boolean muted);

    @Query("UPDATE users SET archived = :archived WHERE uid = :uid")
    void setArchived(String uid, boolean archived);

    @Query("DELETE FROM users")
    void deleteAll();
}
