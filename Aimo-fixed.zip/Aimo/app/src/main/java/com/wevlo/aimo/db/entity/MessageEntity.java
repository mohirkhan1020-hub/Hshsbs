package com.wevlo.aimo.db.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.MessageModel;

import java.util.HashMap;
import java.util.Map;

@Entity(
        tableName = "messages",
        indices = {@Index(value = {"chatId", "timestamp"})}
)
public class MessageEntity {

    @PrimaryKey
    @NonNull
    public String messageId = "";

    @NonNull
    public String chatId = "";

    public String senderId = "";
    public String senderName = "";
    public String receiverId = "";
    public String type = Constants.MSG_TEXT;
    public String text = "";
    public String mediaBase64 = "";
    public String mediaUrl = "";
    public String localPath = "";
    public String fileName = "";
    public long mediaSize = 0L;
    public long durationMs = 0L;
    public long timestamp = 0L;
    public int status = Constants.STATUS_SENDING;

    public String replyToId = "";
    public String replyToText = "";
    public String replyToSender = "";

    public boolean forwarded = false;
    public boolean edited = false;
    public boolean deleted = false;
    public boolean starred = false;

    public Map<String, String> reactions = new HashMap<>();

    public MessageEntity() {
    }

    @Ignore
    public static MessageEntity fromModel(MessageModel model) {
        MessageEntity entity = new MessageEntity();
        if (model == null) return entity;
        entity.messageId = model.messageId != null ? model.messageId : "";
        entity.chatId = model.chatId != null ? model.chatId : "";
        entity.senderId = model.senderId != null ? model.senderId : "";
        entity.senderName = model.senderName != null ? model.senderName : "";
        entity.receiverId = model.receiverId != null ? model.receiverId : "";
        entity.type = model.type != null ? model.type : Constants.MSG_TEXT;
        entity.text = model.text != null ? model.text : "";
        entity.mediaBase64 = model.mediaBase64 != null ? model.mediaBase64 : "";
        entity.mediaUrl = model.mediaUrl != null ? model.mediaUrl : "";
        entity.localPath = model.localPath != null ? model.localPath : "";
        entity.fileName = model.fileName != null ? model.fileName : "";
        entity.mediaSize = model.mediaSize;
        entity.durationMs = model.durationMs;
        entity.timestamp = model.timestamp;
        entity.status = model.status;
        entity.replyToId = model.replyToId != null ? model.replyToId : "";
        entity.replyToText = model.replyToText != null ? model.replyToText : "";
        entity.replyToSender = model.replyToSender != null ? model.replyToSender : "";
        entity.forwarded = model.forwarded;
        entity.edited = model.edited;
        entity.deleted = model.deleted;
        entity.starred = model.starred;
        entity.reactions = model.reactions != null ? new HashMap<>(model.reactions) : new HashMap<>();
        return entity;
    }

    @Ignore
    public MessageModel toModel() {
        MessageModel model = new MessageModel();
        model.messageId = messageId;
        model.chatId = chatId;
        model.senderId = senderId;
        model.senderName = senderName;
        model.receiverId = receiverId;
        model.type = type;
        model.text = text;
        model.mediaBase64 = mediaBase64;
        model.mediaUrl = mediaUrl;
        model.localPath = localPath;
        model.fileName = fileName;
        model.mediaSize = mediaSize;
        model.durationMs = durationMs;
        model.timestamp = timestamp;
        model.status = status;
        model.replyToId = replyToId;
        model.replyToText = replyToText;
        model.replyToSender = replyToSender;
        model.forwarded = forwarded;
        model.edited = edited;
        model.deleted = deleted;
        model.starred = starred;
        model.reactions = reactions != null ? new HashMap<>(reactions) : new HashMap<>();
        return model;
    }
}
