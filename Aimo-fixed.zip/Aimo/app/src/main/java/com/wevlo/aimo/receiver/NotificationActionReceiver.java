package com.wevlo.aimo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.core.app.RemoteInput;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.MessageModel;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.notification.MessageNotificationBuilder;
import com.wevlo.aimo.notification.NotificationHelper;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.UUID;

public class NotificationActionReceiver extends BroadcastReceiver {

    public static final String ACTION_MARK_READ = "com.wevlo.aimo.ACTION_MARK_READ";
    public static final String ACTION_REPLY = "com.wevlo.aimo.ACTION_REPLY";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String chatId = intent.getStringExtra(Constants.EXTRA_CHAT_ID);
        String peerUid = intent.getStringExtra(Constants.EXTRA_PEER_UID);
        if (chatId == null) chatId = "";
        if (peerUid == null) peerUid = "";

        int notifId = Math.abs(chatId.hashCode());
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null) return;

        if (ACTION_MARK_READ.equals(intent.getAction())) {
            String finalChatId = chatId;
            String finalPeerUid = peerUid;
            AppDatabase.dbExecutor.execute(() -> {
                AppDatabase db = AppDatabase.getInstance(context);
                db.messageDao().markChatRead(finalChatId, myUid);
                if (!finalPeerUid.isEmpty()) db.userDao().clearUnread(finalPeerUid);
            });
            NotificationHelper.cancel(context, notifId);
        } else if (ACTION_REPLY.equals(intent.getAction())) {
            Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
            if (remoteInput == null) return;
            CharSequence replySeq = remoteInput.getCharSequence(MessageNotificationBuilder.KEY_TEXT_REPLY);
            String text = replySeq != null ? replySeq.toString().trim() : "";
            if (text.isEmpty()) return;

            String myName = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE)
                    .getString(Constants.PREF_CURRENT_NAME, "Me");
            String msgId = UUID.randomUUID().toString();
            MessageModel model = new MessageModel(
                    msgId, chatId, myUid, myName, peerUid, Constants.MSG_TEXT, text);
            model.status = Constants.STATUS_SENT;

            AppDatabase.dbExecutor.execute(() ->
                    AppDatabase.getInstance(context).messageDao().insert(MessageEntity.fromModel(model)));
            FirestorePaths.messageDoc(chatId, msgId).set(model);
            NotificationHelper.cancel(context, notifId);
        }
    }
}
