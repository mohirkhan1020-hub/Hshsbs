package com.wevlo.aimo.ui.call.webrtc;

import org.webrtc.PeerConnection;

import java.util.ArrayList;
import java.util.List;

public final class TurnServerConfig {

    private TurnServerConfig() {
    }

    public static List<PeerConnection.IceServer> getIceServers() {
        List<PeerConnection.IceServer> servers = new ArrayList<>();
        servers.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());
        servers.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer());
        servers.add(PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer());
        return servers;
    }
}
