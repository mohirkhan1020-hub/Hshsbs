package com.wevlo.aimo.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.DeviceBindingModel;
import com.wevlo.aimo.data.UserModel;
import com.wevlo.aimo.databinding.ActivityLoginBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.ui.home.MainActivity;
import com.wevlo.aimo.utils.BatteryOptimizationHelper;
import com.wevlo.aimo.utils.DeviceIdHelper;
import com.wevlo.aimo.utils.FirestorePaths;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private FirebaseAuth auth;
    private boolean isSignUpMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser != null) {
            verifyDeviceAndProceed(currentUser, false, "", "");
            return;
        }

        setupUi();
    }

    private void setupUi() {
        updateModeUi();

        binding.tvToggleMode.setOnClickListener(v -> {
            isSignUpMode = !isSignUpMode;
            updateModeUi();
        });

        binding.tvForgotPassword.setOnClickListener(v -> handleForgotPassword());
        binding.btnPrimary.setOnClickListener(v -> attemptAuth());
    }

    private void updateModeUi() {
        binding.tilName.setVisibility(isSignUpMode ? View.VISIBLE : View.GONE);
        binding.tilAbout.setVisibility(isSignUpMode ? View.VISIBLE : View.GONE);
        binding.tvForgotPassword.setVisibility(isSignUpMode ? View.GONE : View.VISIBLE);
        binding.btnPrimary.setText(isSignUpMode ? R.string.btn_sign_up : R.string.btn_sign_in);
        binding.tvToggleMode.setText(isSignUpMode ? R.string.toggle_to_sign_in : R.string.toggle_to_sign_up);
    }

    private void attemptAuth() {
        String email = binding.etEmail.getText() != null ? binding.etEmail.getText().toString().trim() : "";
        String password = binding.etPassword.getText() != null ? binding.etPassword.getText().toString().trim() : "";
        String name = binding.etName.getText() != null ? binding.etName.getText().toString().trim() : "";
        String about = binding.etAbout.getText() != null ? binding.etAbout.getText().toString().trim() : "";

        if (isSignUpMode && TextUtils.isEmpty(name)) {
            binding.tilName.setError(getString(R.string.error_empty_name));
            return;
        }
        binding.tilName.setError(null);

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.setError(getString(R.string.error_invalid_email));
            return;
        }
        binding.tilEmail.setError(null);

        if (password.length() < 6) {
            binding.tilPassword.setError(getString(R.string.error_short_password));
            return;
        }
        binding.tilPassword.setError(null);

        setLoading(true);
        if (isSignUpMode) {
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener(result -> {
                        if (result.getUser() != null) {
                            verifyDeviceAndProceed(result.getUser(), true, name, about);
                        } else {
                            setLoading(false);
                        }
                    })
                    .addOnFailureListener(e -> {
                        setLoading(false);
                        Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    });
        } else {
            auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener(result -> {
                        if (result.getUser() != null) {
                            verifyDeviceAndProceed(result.getUser(), false, "", "");
                        } else {
                            setLoading(false);
                        }
                    })
                    .addOnFailureListener(e -> {
                        setLoading(false);
                        Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    });
        }
    }

    private void verifyDeviceAndProceed(FirebaseUser firebaseUser, boolean isNewUser,
                                        String name, String about) {
        String uid = firebaseUser.getUid();
        String currentDeviceId = DeviceIdHelper.getDeviceId(this);

        FirestorePaths.deviceBindingDoc(uid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        DeviceBindingModel existing = snapshot.toObject(DeviceBindingModel.class);
                        if (existing != null && existing.active
                                && !existing.deviceId.isEmpty()
                                && !existing.deviceId.equals(currentDeviceId)) {
                            setLoading(false);
                            showDeviceBoundSheet(firebaseUser, existing.deviceName, isNewUser, name, about);
                            return;
                        }
                    }
                    bindDeviceAndSyncProfile(firebaseUser, isNewUser, name, about);
                })
                .addOnFailureListener(e -> bindDeviceAndSyncProfile(firebaseUser, isNewUser, name, about));
    }

    private void showDeviceBoundSheet(FirebaseUser firebaseUser, String existingDeviceName,
                                      boolean isNewUser, String name, String about) {
        DeviceBoundSheet sheet = DeviceBoundSheet.newInstance(existingDeviceName);
        sheet.setCancelable(false);
        sheet.setListener(new DeviceBoundSheet.Listener() {
            @Override
            public void onSwitchDeviceConfirmed() {
                setLoading(true);
                bindDeviceAndSyncProfile(firebaseUser, isNewUser, name, about);
            }

            @Override
            public void onSwitchDeviceCancelled() {
                auth.signOut();
            }
        });
        sheet.show(getSupportFragmentManager(), "device_bound_sheet");
    }

    private void bindDeviceAndSyncProfile(FirebaseUser firebaseUser, boolean isNewUser,
                                          String name, String about) {
        String uid = firebaseUser.getUid();
        String email = firebaseUser.getEmail() != null ? firebaseUser.getEmail() : "";
        String deviceId = DeviceIdHelper.getDeviceId(this);
        String deviceName = DeviceIdHelper.getDeviceName();

        DeviceBindingModel bindingModel = new DeviceBindingModel(uid, email, deviceId, deviceName);
        FirestorePaths.deviceBindingDoc(uid).set(bindingModel);

        getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE)
                .edit()
                .putString(Constants.PREF_CURRENT_UID, uid)
                .apply();

        FirestorePaths.userDoc(uid).get().addOnSuccessListener(doc -> {
            UserModel userModel;
            if (!doc.exists() || isNewUser) {
                String resolvedName = !name.isEmpty()
                        ? name
                        : (email.contains("@") ? email.substring(0, email.indexOf('@')) : "Aimo User");
                userModel = new UserModel(uid, resolvedName, email, about, "");
                userModel.deviceId = deviceId;
                userModel.online = true;
                FirestorePaths.userDoc(uid).set(userModel);
            } else {
                userModel = doc.toObject(UserModel.class);
                if (userModel != null) {
                    userModel.deviceId = deviceId;
                    userModel.online = true;
                    userModel.lastSeen = System.currentTimeMillis();
                    FirestorePaths.userDoc(uid).update("deviceId", deviceId, "online", true,
                            "lastSeen", userModel.lastSeen);
                }
            }

            if (userModel != null) {
                getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(Constants.PREF_CURRENT_NAME, userModel.name)
                        .apply();
                UserModel finalUser = userModel;
                AppDatabase.dbExecutor.execute(() ->
                        AppDatabase.getInstance(this).userDao().insert(UserEntity.fromModel(finalUser)));
            }

            if (!BatteryOptimizationHelper.isIgnoringBatteryOptimizations(this)) {
                BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(this);
            }
            openMain();
        }).addOnFailureListener(e -> openMain());
    }

    private void handleForgotPassword() {
        String email = binding.etEmail.getText() != null ? binding.etEmail.getText().toString().trim() : "";
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.setError(getString(R.string.error_invalid_email));
            return;
        }
        binding.tilEmail.setError(null);
        auth.sendPasswordResetEmail(email)
                .addOnSuccessListener(unused ->
                        Toast.makeText(this, "Password reset email sent", Toast.LENGTH_LONG).show())
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show());
    }

    private void setLoading(boolean loading) {
        binding.progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.btnPrimary.setEnabled(!loading);
    }

    private void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
