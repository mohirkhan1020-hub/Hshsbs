package com.wevlo.aimo.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

import com.wevlo.aimo.Constants;

import java.util.UUID;

public final class DeviceIdHelper {

    private DeviceIdHelper() {
    }

    @SuppressLint("HardwareIds")
    public static String getDeviceId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        String cached = prefs.getString(Constants.PREF_DEVICE_ID, "");
        if (!cached.isEmpty()) {
            return cached;
        }

        String androidId = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ANDROID_ID
        );
        if (androidId == null || androidId.isEmpty() || "9774d56d682e549c".equals(androidId)) {
            androidId = UUID.randomUUID().toString();
        }
        prefs.edit().putString(Constants.PREF_DEVICE_ID, androidId).apply();
        return androidId;
    }

    public static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER : "";
        String model = Build.MODEL != null ? Build.MODEL : "Android";
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return model;
        }
        return (manufacturer + " " + model).trim();
    }
}
