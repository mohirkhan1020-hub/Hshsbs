package com.wevlo.aimo;

import android.app.Activity;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.PersistentCacheSettings;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.utils.FirestorePaths;
import com.wevlo.aimo.utils.LruCacheManager;

import java.util.HashMap;
import java.util.Map;

public class AimoApp extends Application implements Application.ActivityLifecycleCallbacks {

    private static AimoApp instance;
    private int activeActivityCount = 0;

    public static AimoApp getInstance() {
        return instance;
    }

    public static Context getAppContext() {
        return instance.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        LruCacheManager.getInstance();
        AppDatabase.getInstance(this);
        initFirestore();
        createNotificationChannels();
        registerActivityLifecycleCallbacks(this);
    }

    private void initFirestore() {
        try {
            FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                    .build();
            FirebaseFirestore.getInstance().setFirestoreSettings(settings);
        } catch (IllegalStateException ignored) {
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;

            NotificationChannel msgChannel = new NotificationChannel(
                    Constants.CHANNEL_MESSAGES,
                    "Messages",
                    NotificationManager.IMPORTANCE_HIGH
            );
            msgChannel.setDescription("Incoming chat and group messages");
            msgChannel.enableVibration(true);

            NotificationChannel callChannel = new NotificationChannel(
                    Constants.CHANNEL_CALLS,
                    "Calls",
                    NotificationManager.IMPORTANCE_HIGH
            );
            callChannel.setDescription("Incoming voice and video calls");
            callChannel.enableVibration(true);

            NotificationChannel serviceChannel = new NotificationChannel(
                    Constants.CHANNEL_SERVICE,
                    "Background Sync",
                    NotificationManager.IMPORTANCE_LOW
            );
            serviceChannel.setDescription("Keeps messages and calls connected");

            manager.createNotificationChannel(msgChannel);
            manager.createNotificationChannel(callChannel);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    public void updatePresence(boolean online) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        Map<String, Object> updates = new HashMap<>();
        updates.put("online", online);
        updates.put("lastSeen", System.currentTimeMillis());
        FirestorePaths.userDoc(user.getUid()).update(updates);
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        if (activeActivityCount == 0) {
            updatePresence(true);
        }
        activeActivityCount++;
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        activeActivityCount = Math.max(0, activeActivityCount - 1);
        if (activeActivityCount == 0) {
            updatePresence(false);
        }
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }
}
