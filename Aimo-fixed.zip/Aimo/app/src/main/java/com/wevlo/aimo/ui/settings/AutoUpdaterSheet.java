package com.wevlo.aimo.ui.settings;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.databinding.SheetAutoUpdateBinding;
import com.wevlo.aimo.utils.FirestorePaths;

public class AutoUpdaterSheet extends BottomSheetDialogFragment {

    private SheetAutoUpdateBinding binding;
    private String downloadUrl = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetAutoUpdateBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        long currentCode = getCurrentVersionCode();
        binding.tvVersionInfo.setText("Checking for updates...");
        binding.btnDownloadUpdate.setEnabled(false);

        FirestorePaths.appConfigDoc().get()
                .addOnSuccessListener(doc -> {
                    if (binding == null) return;
                    if (!doc.exists()) {
                        binding.tvVersionInfo.setText("You are on the latest version.");
                        binding.tvReleaseNotes.setText("Current version code: " + currentCode);
                        return;
                    }
                    Long remoteCode = doc.getLong("versionCode");
                    String versionName = doc.getString("versionName");
                    String notes = doc.getString("notes");
                    String url = doc.getString("downloadUrl");
                    if (remoteCode != null && remoteCode > currentCode && url != null && !url.isEmpty()) {
                        downloadUrl = url;
                        binding.tvVersionInfo.setText("Update available: v" + (versionName != null ? versionName : remoteCode));
                        binding.tvReleaseNotes.setText(notes != null ? notes : "Bug fixes and performance improvements.");
                        binding.btnDownloadUpdate.setEnabled(true);
                    } else {
                        binding.tvVersionInfo.setText("Aimo is up to date.");
                        binding.tvReleaseNotes.setText("Installed version code: " + currentCode);
                    }
                })
                .addOnFailureListener(e -> {
                    if (binding != null) {
                        binding.tvVersionInfo.setText("Could not check for updates.");
                    }
                });

        binding.btnDownloadUpdate.setOnClickListener(v -> {
            if (!downloadUrl.isEmpty()) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)));
            }
            dismiss();
        });
        binding.btnCloseUpdate.setOnClickListener(v -> dismiss());
    }

    @SuppressWarnings("deprecation")
    private long getCurrentVersionCode() {
        try {
            PackageInfo info = requireContext().getPackageManager()
                    .getPackageInfo(requireContext().getPackageName(), 0);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                    ? info.getLongVersionCode()
                    : info.versionCode;
        } catch (Exception e) {
            return 1L;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
