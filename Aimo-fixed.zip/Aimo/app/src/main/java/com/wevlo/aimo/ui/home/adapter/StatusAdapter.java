package com.wevlo.aimo.ui.home.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ItemStatusBinding;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class StatusAdapter extends RecyclerView.Adapter<StatusAdapter.ViewHolder> {

    public static class StatusSummary {
        public String userId = "";
        public String userName = "";
        public String userPhoto = "";
        public long latestTimestamp = 0L;
        public int count = 1;
        public boolean seen = false;
    }

    public interface Listener {
        void onStatusClicked(StatusSummary summary);
    }

    private final List<StatusSummary> items = new ArrayList<>();
    private final Listener listener;

    public StatusAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<StatusSummary> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemStatusBinding binding = ItemStatusBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StatusSummary summary = items.get(position);
        holder.binding.tvName.setText(summary.userName);
        holder.binding.tvTime.setText(DateUtils.formatChatTime(summary.latestTimestamp));
        holder.binding.vStatusRing.setBackgroundResource(summary.seen
                ? R.drawable.bg_status_ring_seen
                : R.drawable.bg_status_ring_unseen);

        Base64ImageUtils.loadAvatar(holder.binding.ivAvatar, "avatar_" + summary.userId,
                summary.userPhoto, "", R.drawable.ic_attachment_contact);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onStatusClicked(summary);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemStatusBinding binding;

        ViewHolder(ItemStatusBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
