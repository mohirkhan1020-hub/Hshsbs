package com.wevlo.aimo.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import com.wevlo.aimo.Constants;

public final class NotificationChannelHelper {

    private NotificationChannelHelper() {
    }

    public static void ensureChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        NotificationChannel msgChannel = new NotificationChannel(
                Constants.CHANNEL_MESSAGES, "Messages", NotificationManager.IMPORTANCE_HIGH);
        msgChannel.enableVibration(true);

        NotificationChannel callChannel = new NotificationChannel(
                Constants.CHANNEL_CALLS, "Calls", NotificationManager.IMPORTANCE_HIGH);
        callChannel.enableVibration(true);

        NotificationChannel serviceChannel = new NotificationChannel(
                Constants.CHANNEL_SERVICE, "Background Sync", NotificationManager.IMPORTANCE_LOW);

        manager.createNotificationChannel(msgChannel);
        manager.createNotificationChannel(callChannel);
        manager.createNotificationChannel(serviceChannel);
    }
}
