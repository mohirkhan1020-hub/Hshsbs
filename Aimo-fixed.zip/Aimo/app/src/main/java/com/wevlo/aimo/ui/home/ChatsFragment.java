package com.wevlo.aimo.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.GroupModel;
import com.wevlo.aimo.data.UserModel;
import com.wevlo.aimo.databinding.FragmentChatsBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.GroupEntity;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.ui.chat.ChatActivity;
import com.wevlo.aimo.ui.group.CreateGroupActivity;
import com.wevlo.aimo.ui.home.adapter.ChatListAdapter;
import com.wevlo.aimo.ui.home.bottomsheet.QuickContactSheet;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChatsFragment extends Fragment {

    private FragmentChatsBinding binding;
    private ChatListAdapter adapter;
    private final List<UserEntity> cachedUsers = new ArrayList<>();
    private final List<GroupEntity> cachedGroups = new ArrayList<>();
    private String currentFilter = "ALL";
    private String searchQuery = "";
    private ListenerRegistration usersListener;
    private ListenerRegistration groupsListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentChatsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new ChatListAdapter(new ChatListAdapter.Listener() {
            @Override
            public void onChatClicked(ChatListAdapter.ChatListItem item) {
                Intent intent = new Intent(requireContext(), ChatActivity.class);
                intent.putExtra(Constants.EXTRA_CHAT_ID, item.chatId);
                intent.putExtra(Constants.EXTRA_PEER_UID, item.peerId);
                intent.putExtra(Constants.EXTRA_PEER_NAME, item.title);
                intent.putExtra(Constants.EXTRA_PEER_PHOTO, item.photoBase64);
                intent.putExtra(Constants.EXTRA_IS_GROUP, item.isGroup);
                startActivity(intent);
            }

            @Override
            public void onAvatarClicked(ChatListAdapter.ChatListItem item) {
                QuickContactSheet.newInstance(item.peerId, item.title, item.photoBase64, item.isGroup)
                        .show(getChildFragmentManager(), "quick_contact");
            }
        });

        binding.rvChats.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvChats.setAdapter(adapter);

        setupFilterChips();
        binding.swipeRefresh.setColorSchemeResources(R.color.aimo_accent);
        binding.swipeRefresh.setOnRefreshListener(() -> {
            syncFromFirestore();
            binding.swipeRefresh.setRefreshing(false);
        });

        binding.fabNewChat.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), CreateGroupActivity.class)));

        observeDatabase();
        syncFromFirestore();
    }

    private void setupFilterChips() {
        binding.chipAll.setOnClickListener(v -> selectFilter("ALL"));
        binding.chipUnread.setOnClickListener(v -> selectFilter("UNREAD"));
        binding.chipOnline.setOnClickListener(v -> selectFilter("ONLINE"));
        binding.chipGroups.setOnClickListener(v -> selectFilter("GROUPS"));
        updateChipStyles();
    }

    private void selectFilter(String filter) {
        currentFilter = filter;
        updateChipStyles();
        rebuildList();
    }

    private void updateChipStyles() {
        binding.chipAll.setBackgroundResource("ALL".equals(currentFilter)
                ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
        binding.chipUnread.setBackgroundResource("UNREAD".equals(currentFilter)
                ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
        binding.chipOnline.setBackgroundResource("ONLINE".equals(currentFilter)
                ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
        binding.chipGroups.setBackgroundResource("GROUPS".equals(currentFilter)
                ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
    }

    public void setSearchQuery(String query) {
        this.searchQuery = query != null ? query.toLowerCase() : "";
        if (binding != null) {
            rebuildList();
        }
    }

    private void observeDatabase() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null) return;

        AppDatabase db = AppDatabase.getInstance(requireContext());
        db.userDao().observeAllUsers(myUid).observe(getViewLifecycleOwner(), users -> {
            cachedUsers.clear();
            if (users != null) cachedUsers.addAll(users);
            rebuildList();
        });

        db.groupDao().observeAllGroups().observe(getViewLifecycleOwner(), groups -> {
            cachedGroups.clear();
            if (groups != null) cachedGroups.addAll(groups);
            rebuildList();
        });
    }

    private void syncFromFirestore() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null) return;

        if (usersListener != null) usersListener.remove();
        usersListener = FirestorePaths.usersCol().addSnapshotListener((snapshots, error) -> {
            if (snapshots == null || getContext() == null) return;
            List<UserModel> models = new ArrayList<>();
            for (DocumentSnapshot doc : snapshots.getDocuments()) {
                UserModel model = doc.toObject(UserModel.class);
                if (model != null && !myUid.equals(model.uid)) {
                    models.add(model);
                }
            }
            AppDatabase db = AppDatabase.getInstance(requireContext().getApplicationContext());
            AppDatabase.dbExecutor.execute(() -> {
                List<UserEntity> list = new ArrayList<>();
                for (UserModel model : models) {
                    UserEntity existing = db.userDao().getUserById(model.uid);
                    UserEntity entity = UserEntity.fromModel(model);
                    if (existing != null) {
                        entity.lastMessage = existing.lastMessage;
                        entity.lastMessageSenderId = existing.lastMessageSenderId;
                        entity.lastMessageTime = existing.lastMessageTime;
                        entity.unreadCount = existing.unreadCount;
                        entity.pinned = existing.pinned;
                        entity.muted = existing.muted;
                        entity.archived = existing.archived;
                    }
                    list.add(entity);
                }
                db.userDao().insertAll(list);
            });
        });

        if (groupsListener != null) groupsListener.remove();
        groupsListener = FirestorePaths.groupsCol()
                .whereArrayContains("memberIds", myUid)
                .addSnapshotListener((snapshots, error) -> {
                    if (snapshots == null || getContext() == null) return;
                    List<GroupEntity> list = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        GroupModel model = doc.toObject(GroupModel.class);
                        if (model != null) {
                            list.add(GroupEntity.fromModel(model));
                        }
                    }
                    AppDatabase db = AppDatabase.getInstance(requireContext().getApplicationContext());
                    AppDatabase.dbExecutor.execute(() -> db.groupDao().insertAll(list));
                });
    }

    private void rebuildList() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null || binding == null) return;

        List<ChatListAdapter.ChatListItem> items = new ArrayList<>();
        if (!"GROUPS".equals(currentFilter)) {
            for (UserEntity u : cachedUsers) {
                if (u.archived) continue;
                if ("UNREAD".equals(currentFilter) && u.unreadCount <= 0) continue;
                if ("ONLINE".equals(currentFilter) && !u.online) continue;
                if (!searchQuery.isEmpty() && !u.name.toLowerCase().contains(searchQuery)) continue;

                ChatListAdapter.ChatListItem item = new ChatListAdapter.ChatListItem();
                item.chatId = FirestorePaths.getDirectChatId(myUid, u.uid);
                item.peerId = u.uid;
                item.title = u.name;
                item.subtitle = !u.lastMessage.isEmpty() ? u.lastMessage : u.about;
                item.photoBase64 = u.photoBase64;
                item.timestamp = u.lastMessageTime > 0 ? u.lastMessageTime : u.lastSeen;
                item.unreadCount = u.unreadCount;
                item.online = u.online;
                item.pinned = u.pinned;
                item.muted = u.muted;
                item.isGroup = false;
                items.add(item);
            }
        }

        if (!"ONLINE".equals(currentFilter)) {
            for (GroupEntity g : cachedGroups) {
                if (g.archived) continue;
                if ("UNREAD".equals(currentFilter) && g.unreadCount <= 0) continue;
                if (!searchQuery.isEmpty() && !g.name.toLowerCase().contains(searchQuery)) continue;

                ChatListAdapter.ChatListItem item = new ChatListAdapter.ChatListItem();
                item.chatId = g.groupId;
                item.peerId = g.groupId;
                item.title = g.name;
                item.subtitle = !g.lastMessage.isEmpty() ? g.lastMessage : "Group created";
                item.photoBase64 = g.photoBase64;
                item.timestamp = g.lastMessageTime > 0 ? g.lastMessageTime : g.createdAt;
                item.unreadCount = g.unreadCount;
                item.pinned = g.pinned;
                item.muted = g.muted;
                item.isGroup = true;
                items.add(item);
            }
        }

        Collections.sort(items, (a, b) -> {
            if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
            return Long.compare(b.timestamp, a.timestamp);
        });

        adapter.submitList(items);
        binding.tvEmptyChats.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (usersListener != null) usersListener.remove();
        if (groupsListener != null) groupsListener.remove();
        binding = null;
    }
}
