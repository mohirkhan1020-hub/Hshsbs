package com.wevlo.aimo.ui.group;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ActivityGroupInfoBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.GroupEntity;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.ui.group.adapter.GroupMemberAdapter;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.List;

public class GroupInfoActivity extends AppCompatActivity {

    private ActivityGroupInfoBinding binding;
    private GroupMemberAdapter adapter;
    private String groupId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGroupInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Group info");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        groupId = getIntent().getStringExtra(Constants.EXTRA_GROUP_ID);
        if (groupId == null) groupId = "";

        adapter = new GroupMemberAdapter(false);
        binding.rvMembers.setLayoutManager(new LinearLayoutManager(this));
        binding.rvMembers.setAdapter(adapter);

        binding.btnLeaveGroup.setOnClickListener(v -> confirmLeave());
        loadGroup();
    }

    private void loadGroup() {
        AppDatabase.getInstance(this).groupDao().observeGroup(groupId)
                .observe(this, group -> {
                    if (group == null) return;
                    binding.tvGroupName.setText(group.name);
                    binding.tvGroupMeta.setText("Group · " + group.memberIds.size() + " participants");
                    Base64ImageUtils.loadAvatar(binding.ivGroupAvatar, "avatar_" + group.groupId,
                            group.photoBase64, group.photoUrl, R.drawable.ic_group);
                    adapter.setAdminIds(group.adminIds);
                    loadMembers(group);
                });
    }

    private void loadMembers(GroupEntity group) {
        AppDatabase.dbExecutor.execute(() -> {
            List<UserEntity> all = AppDatabase.getInstance(this).userDao().getAllUsersSync();
            List<UserEntity> members = new ArrayList<>();
            for (UserEntity u : all) {
                if (group.memberIds.contains(u.uid)) {
                    members.add(u);
                }
            }
            runOnUiThread(() -> adapter.submitUsers(members));
        });
    }

    private void confirmLeave() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Leave group?")
                .setMessage("Are you sure you want to leave this group?")
                .setPositiveButton("Leave", (d, w) -> {
                    FirestorePaths.groupDoc(groupId)
                            .update("memberIds", FieldValue.arrayRemove(myUid));
                    AppDatabase.dbExecutor.execute(() ->
                            AppDatabase.getInstance(this).groupDao().deleteById(groupId));
                    Toast.makeText(this, "Left group", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }
}
