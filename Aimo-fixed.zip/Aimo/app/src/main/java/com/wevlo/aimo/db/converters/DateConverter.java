package com.wevlo.aimo.db.converters;

import androidx.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DateConverter {

    private static final Gson gson = new Gson();

    @TypeConverter
    public static Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    @TypeConverter
    public static Long dateToTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }

    @TypeConverter
    public static List<String> fromStringList(String json) {
        if (json == null || json.isEmpty()) return new ArrayList<>();
        Type type = new TypeToken<List<String>>() {}.getType();
        List<String> list = gson.fromJson(json, type);
        return list != null ? list : new ArrayList<>();
    }

    @TypeConverter
    public static String toStringList(List<String> list) {
        return list == null ? "[]" : gson.toJson(list);
    }

    @TypeConverter
    public static Map<String, String> fromStringMap(String json) {
        if (json == null || json.isEmpty()) return new HashMap<>();
        Type type = new TypeToken<Map<String, String>>() {}.getType();
        Map<String, String> map = gson.fromJson(json, type);
        return map != null ? map : new HashMap<>();
    }

    @TypeConverter
    public static String toStringMap(Map<String, String> map) {
        return map == null ? "{}" : gson.toJson(map);
    }
}
