package com.wevlo.aimo.ui.settings;

import android.content.pm.PackageInfo;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.wevlo.aimo.databinding.ActivityAboutBinding;

public class AboutActivity extends AppCompatActivity {

    private ActivityAboutBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAboutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("About");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            binding.tvVersion.setText("Version " + info.versionName);
        } catch (Exception e) {
            binding.tvVersion.setText("Version 1.0.0");
        }
    }
}
