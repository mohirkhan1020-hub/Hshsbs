package com.wevlo.aimo.ui.call.webrtc;

import android.content.Context;

import com.wevlo.aimo.data.CallLogModel;

import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoTrack;

public class WebRTCManager {

    public interface CallEvents {
        void onRemoteVideoAvailable(VideoTrack track);
        void onCallConnected();
        void onCallEnded();
    }

    private final EglBase eglBase = EglBase.create();
    private final WebRTCClient rtcClient;
    private final SignalingClient signalingClient;
    private final CallEvents callEvents;

    public WebRTCManager(Context context, String callId, boolean isCaller, CallEvents events) {
        this.callEvents = events;
        this.signalingClient = new SignalingClient(callId, isCaller);
        this.rtcClient = new WebRTCClient(context, eglBase, new WebRTCClient.Events() {
            @Override
            public void onLocalIceCandidate(IceCandidate candidate) {
                signalingClient.sendIceCandidate(candidate);
            }

            @Override
            public void onLocalSdpCreated(SessionDescription sdp) {
                if (isCaller) {
                    signalingClient.sendOffer(sdp.description);
                } else {
                    signalingClient.sendAnswer(sdp.description);
                }
            }

            @Override
            public void onRemoteVideoTrack(VideoTrack videoTrack) {
                if (callEvents != null) callEvents.onRemoteVideoAvailable(videoTrack);
            }

            @Override
            public void onConnected() {
                if (callEvents != null) callEvents.onCallConnected();
            }

            @Override
            public void onDisconnected() {
                if (callEvents != null) callEvents.onCallEnded();
            }
        });
    }

    public EglBase.Context getEglContext() {
        return eglBase.getEglBaseContext();
    }

    public void start(boolean isVideo, SurfaceViewRenderer localRenderer, CallLogModel outgoingModel) {
        rtcClient.startLocalMedia(isVideo, localRenderer);
        rtcClient.createPeerConnection();

        if (outgoingModel != null) {
            signalingClient.createCallDocument(outgoingModel);
            rtcClient.createOffer();
        }

        signalingClient.listen(new SignalingClient.Listener() {
            @Override
            public void onOfferReceived(String sdp) {
                rtcClient.setRemoteDescription(SessionDescription.Type.OFFER, sdp);
                rtcClient.createAnswer();
            }

            @Override
            public void onAnswerReceived(String sdp) {
                rtcClient.setRemoteDescription(SessionDescription.Type.ANSWER, sdp);
            }

            @Override
            public void onIceCandidateReceived(IceCandidate candidate) {
                rtcClient.addIceCandidate(candidate);
            }

            @Override
            public void onCallEnded(String status) {
                if (callEvents != null) callEvents.onCallEnded();
            }
        });
    }

    public void setMicEnabled(boolean enabled) {
        rtcClient.setMicEnabled(enabled);
    }

    public void setCameraEnabled(boolean enabled) {
        rtcClient.setCameraEnabled(enabled);
    }

    public void switchCamera() {
        rtcClient.switchCamera();
    }

    public void endCall(String status, long durationSec) {
        signalingClient.updateCallStatus(status, durationSec);
        release();
    }

    public void release() {
        signalingClient.stop();
        rtcClient.release();
        eglBase.release();
    }
}
