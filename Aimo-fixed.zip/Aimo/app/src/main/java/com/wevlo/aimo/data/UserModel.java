package com.wevlo.aimo.data;

public class UserModel {

    public String uid = "";
    public String name = "";
    public String email = "";
    public String about = "Hey there! I am using Aimo.";
    public String photoBase64 = "";
    public String photoUrl = "";
    public boolean online = false;
    public long lastSeen = 0L;
    public String typingTo = "";
    public String deviceId = "";
    public String fcmToken = "";
    public long createdAt = 0L;

    public UserModel() {
    }

    public UserModel(String uid, String name, String email, String about, String photoBase64) {
        this.uid = uid != null ? uid : "";
        this.name = name != null ? name : "";
        this.email = email != null ? email : "";
        this.about = about != null && !about.isEmpty() ? about : "Hey there! I am using Aimo.";
        this.photoBase64 = photoBase64 != null ? photoBase64 : "";
        this.createdAt = System.currentTimeMillis();
        this.lastSeen = this.createdAt;
    }
}
