package com.wevlo.aimo.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.wevlo.aimo.db.entity.CallLogEntity;

import java.util.List;

@Dao
public interface CallLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(CallLogEntity callLog);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<CallLogEntity> callLogs);

    @Query("SELECT * FROM call_logs ORDER BY startedAt DESC")
    LiveData<List<CallLogEntity>> observeAllCallLogs();

    @Query("SELECT * FROM call_logs WHERE callId = :callId LIMIT 1")
    CallLogEntity getCallLogById(String callId);

    @Query("DELETE FROM call_logs WHERE callId = :callId")
    void deleteById(String callId);

    @Query("DELETE FROM call_logs")
    void deleteAll();
}
