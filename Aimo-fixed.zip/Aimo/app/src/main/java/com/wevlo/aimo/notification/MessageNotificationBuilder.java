package com.wevlo.aimo.notification;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.RemoteInput;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.receiver.NotificationActionReceiver;
import com.wevlo.aimo.ui.chat.ChatActivity;

public final class MessageNotificationBuilder {

    public static final String KEY_TEXT_REPLY = "key_text_reply";

    private MessageNotificationBuilder() {
    }

    public static Notification build(Context context, String chatId, String peerUid,
                                     String senderName, String messageText, boolean isGroup) {
        Intent openIntent = new Intent(context, ChatActivity.class);
        openIntent.putExtra(Constants.EXTRA_CHAT_ID, chatId);
        openIntent.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        openIntent.putExtra(Constants.EXTRA_PEER_NAME, senderName);
        openIntent.putExtra(Constants.EXTRA_IS_GROUP, isGroup);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int reqCode = chatId != null ? chatId.hashCode() : 101;
        PendingIntent contentPi = PendingIntent.getActivity(
                context,
                reqCode,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent readIntent = new Intent(context, NotificationActionReceiver.class);
        readIntent.setAction(NotificationActionReceiver.ACTION_MARK_READ);
        readIntent.putExtra(Constants.EXTRA_CHAT_ID, chatId);
        readIntent.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        PendingIntent readPi = PendingIntent.getBroadcast(
                context,
                reqCode + 1,
                readIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        RemoteInput remoteInput = new RemoteInput.Builder(KEY_TEXT_REPLY)
                .setLabel("Reply")
                .build();
        Intent replyIntent = new Intent(context, NotificationActionReceiver.class);
        replyIntent.setAction(NotificationActionReceiver.ACTION_REPLY);
        replyIntent.putExtra(Constants.EXTRA_CHAT_ID, chatId);
        replyIntent.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        PendingIntent replyPi = PendingIntent.getBroadcast(
                context,
                reqCode + 2,
                replyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
        );

        NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
                R.drawable.ic_reply, "Reply", replyPi)
                .addRemoteInput(remoteInput)
                .build();

        return new NotificationCompat.Builder(context, Constants.CHANNEL_MESSAGES)
                .setSmallIcon(R.drawable.ic_stat_aimo)
                .setContentTitle(senderName != null && !senderName.isEmpty() ? senderName : "Aimo")
                .setContentText(messageText != null ? messageText : "New message")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(contentPi)
                .addAction(replyAction)
                .addAction(R.drawable.ic_check_double, "Mark as read", readPi)
                .build();
    }
}
