package com.wevlo.aimo.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * SimpleTabFragment — placeholder fragment for MainActivity's ViewPager2.
 *
 * Each tab (Chats, Updates, Calls) is actually rendered by
 * ChatsFragment / UpdatesFragment / CallsFragment inside the Activity.
 * This class is only used to satisfy the FragmentStateAdapter contract.
 */
public class SimpleTabFragment extends Fragment {

    private static final String ARG_TITLE = "title";

    public static SimpleTabFragment newInstance(String title) {
        SimpleTabFragment fragment = new SimpleTabFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return new FrameLayout(requireContext());
    }
}
