package com.wevlo.aimo.ui.home.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ItemCallLogBinding;
import com.wevlo.aimo.db.entity.CallLogEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class CallLogAdapter extends RecyclerView.Adapter<CallLogAdapter.ViewHolder> {

    public interface Listener {
        void onCallClicked(CallLogEntity callLog);
    }

    private final List<CallLogEntity> items = new ArrayList<>();
    private final Listener listener;

    public CallLogAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<CallLogEntity> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemCallLogBinding binding = ItemCallLogBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CallLogEntity item = items.get(position);
        holder.binding.tvName.setText(item.peerName);
        holder.binding.tvTime.setText(DateUtils.formatChatTime(item.startedAt));

        boolean isMissed = Constants.CALL_DIR_MISSED.equals(item.direction);
        holder.binding.tvName.setTextColor(ContextCompat.getColor(
                holder.itemView.getContext(),
                isMissed ? R.color.aimo_call_decline : R.color.aimo_text_primary
        ));

        if (isMissed) {
            holder.binding.ivDirection.setImageResource(R.drawable.ic_call_missed);
        } else if (Constants.CALL_DIR_INCOMING.equals(item.direction)) {
            holder.binding.ivDirection.setImageResource(R.drawable.ic_arrow_incoming);
        } else {
            holder.binding.ivDirection.setImageResource(R.drawable.ic_arrow_outgoing);
        }

        holder.binding.btnCallAction.setImageResource(
                item.isVideo ? R.drawable.ic_video_call : R.drawable.ic_voice_call);

        Base64ImageUtils.loadAvatar(holder.binding.ivAvatar, "avatar_" + item.peerId,
                item.peerPhoto, "", R.drawable.ic_attachment_contact);

        holder.binding.btnCallAction.setOnClickListener(v -> {
            if (listener != null) listener.onCallClicked(item);
        });
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onCallClicked(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemCallLogBinding binding;

        ViewHolder(ItemCallLogBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
