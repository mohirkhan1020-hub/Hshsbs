package com.wevlo.aimo.ui.call;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.wevlo.aimo.R;

public class FloatingCallWindow {

    private final Context context;
    private final WindowManager windowManager;
    private View floatingView;

    public FloatingCallWindow(Context context) {
        this.context = context.getApplicationContext();
        this.windowManager = (WindowManager) this.context.getSystemService(Context.WINDOW_SERVICE);
    }

    public void show(String peerName, String statusText) {
        if (floatingView != null || windowManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            return;
        }

        try {
            floatingView = LayoutInflater.from(context).inflate(R.layout.view_floating_call, null);
            TextView tvName = floatingView.findViewById(R.id.tvFloatingName);
            TextView tvStatus = floatingView.findViewById(R.id.tvFloatingStatus);
            tvName.setText(peerName);
            tvStatus.setText(statusText);

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.END;
            params.x = 24;
            params.y = 120;

            floatingView.setOnClickListener(v -> {
                Intent intent = new Intent(context, ActiveCallActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                context.startActivity(intent);
                hide();
            });

            windowManager.addView(floatingView, params);
        } catch (Exception ignored) {
            floatingView = null;
        }
    }

    public void hide() {
        if (floatingView != null && windowManager != null) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {
            }
            floatingView = null;
        }
    }
}
