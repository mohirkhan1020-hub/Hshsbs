package com.wevlo.aimo.data;

import java.util.ArrayList;
import java.util.List;

public class GroupModel {

    public String groupId = "";
    public String name = "";
    public String description = "";
    public String photoBase64 = "";
    public String photoUrl = "";
    public String createdBy = "";
    public long createdAt = 0L;
    public List<String> memberIds = new ArrayList<>();
    public List<String> adminIds = new ArrayList<>();
    public String lastMessage = "";
    public String lastMessageSender = "";
    public long lastMessageTime = 0L;
    public boolean onlyAdminsCanSend = false;

    public GroupModel() {
    }

    public GroupModel(String groupId, String name, String createdBy, List<String> memberIds) {
        this.groupId = groupId != null ? groupId : "";
        this.name = name != null ? name : "";
        this.createdBy = createdBy != null ? createdBy : "";
        this.createdAt = System.currentTimeMillis();
        this.lastMessageTime = this.createdAt;
        if (memberIds != null) {
            this.memberIds = new ArrayList<>(memberIds);
        }
        if (createdBy != null && !createdBy.isEmpty()) {
            this.adminIds.add(createdBy);
        }
    }
}
