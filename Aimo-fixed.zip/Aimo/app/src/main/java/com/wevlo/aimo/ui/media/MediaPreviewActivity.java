package com.wevlo.aimo.ui.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.MessageModel;
import com.wevlo.aimo.databinding.ActivityMediaPreviewBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;
import com.wevlo.aimo.utils.ImageCompressor;

import java.util.UUID;

public class MediaPreviewActivity extends AppCompatActivity {

    private ActivityMediaPreviewBinding binding;
    private Bitmap originalBitmap;
    private String chatId = "", peerUid = "";
    private boolean isGroup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMediaPreviewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Preview");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        chatId = getIntent().getStringExtra(Constants.EXTRA_CHAT_ID);
        peerUid = getIntent().getStringExtra(Constants.EXTRA_PEER_UID);
        isGroup = getIntent().getBooleanExtra(Constants.EXTRA_IS_GROUP, false);
        String uriStr = getIntent().getStringExtra(Constants.EXTRA_MEDIA_URI);
        if (chatId == null) chatId = "";
        if (peerUid == null) peerUid = "";

        if (uriStr != null) {
            Uri uri = Uri.parse(uriStr);
            AppDatabase.dbExecutor.execute(() -> {
                Bitmap bmp = ImageCompressor.decodeSampledBitmap(this, uri, Constants.MAX_IMAGE_DIM);
                runOnUiThread(() -> {
                    originalBitmap = bmp;
                    if (bmp != null) binding.ivPreview.setImageBitmap(bmp);
                    else { Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show(); finish(); }
                });
            });
        }
        binding.fabSendMedia.setOnClickListener(v -> sendImageMessage());
    }

    private void sendImageMessage() {
        if (originalBitmap == null) return;
        binding.fabSendMedia.setEnabled(false);
        String caption = binding.etCaption.getText() != null ? binding.etCaption.getText().toString().trim() : "";
        String myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
        String myName = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).getString(Constants.PREF_CURRENT_NAME, "Me");
        Bitmap finalBmp = binding.doodleView.compositeOnto(originalBitmap);

        AppDatabase.dbExecutor.execute(() -> {
            String msgId = UUID.randomUUID().toString();
            MessageModel model = new MessageModel(msgId, chatId, myUid, myName, peerUid,
                    Constants.MSG_IMAGE, caption.isEmpty() ? "Photo" : caption);
            model.mediaBase64 = Base64ImageUtils.bitmapToBase64(finalBmp);
            model.status = Constants.STATUS_SENT;
            AppDatabase db = AppDatabase.getInstance(this);
            db.messageDao().insert(MessageEntity.fromModel(model));
            if (isGroup) {
                FirestorePaths.groupDoc(chatId).update("lastMessage", "Photo", "lastMessageSender", myName, "lastMessageTime", model.timestamp);
            } else {
                db.userDao().updateChatSummary(peerUid, "Photo", myUid, model.timestamp);
            }
            FirestorePaths.messageDoc(chatId, msgId).set(model);
            runOnUiThread(this::finish);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_media_preview, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_doodle) {
            boolean next = !binding.doodleView.isDrawingEnabled();
            binding.doodleView.setDrawingEnabled(next);
            Toast.makeText(this, next ? "Doodle enabled" : "Doodle disabled", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_undo) { binding.doodleView.undo(); return true; }
        else if (id == R.id.action_clear_doodle) { binding.doodleView.clear(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
