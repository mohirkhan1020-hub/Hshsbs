package com.wevlo.aimo.ui.group;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.data.GroupModel;
import com.wevlo.aimo.databinding.ActivityCreateGroupBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.GroupEntity;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.ui.group.adapter.GroupMemberAdapter;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CreateGroupActivity extends AppCompatActivity {

    private ActivityCreateGroupBinding binding;
    private GroupMemberAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateGroupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("New group");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        adapter = new GroupMemberAdapter(true);
        binding.rvSelectMembers.setLayoutManager(new LinearLayoutManager(this));
        binding.rvSelectMembers.setAdapter(adapter);

        loadContacts();
        binding.fabCreateGroup.setOnClickListener(v -> createGroup());
    }

    private void loadContacts() {
        String myUid = FirebaseAuth.getInstance().getUid();
        AppDatabase.dbExecutor.execute(() -> {
            List<UserEntity> all = AppDatabase.getInstance(this).userDao().getAllUsersSync();
            List<UserEntity> contacts = new ArrayList<>();
            for (UserEntity u : all) {
                if (myUid == null || !myUid.equals(u.uid)) {
                    contacts.add(u);
                }
            }
            runOnUiThread(() -> adapter.submitUsers(contacts));
        });
    }

    private void createGroup() {
        String name = binding.etGroupName.getText() != null
                ? binding.etGroupName.getText().toString().trim() : "";
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter a group subject", Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> members = adapter.getSelectedIds();
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid != null && !members.contains(myUid)) {
            members.add(myUid);
        }
        if (members.size() < 2) {
            Toast.makeText(this, "Select at least 1 participant", Toast.LENGTH_SHORT).show();
            return;
        }

        String groupId = UUID.randomUUID().toString();
        GroupModel model = new GroupModel(groupId, name, myUid, members);
        AppDatabase.dbExecutor.execute(() ->
                AppDatabase.getInstance(this).groupDao().insert(GroupEntity.fromModel(model)));
        FirestorePaths.groupDoc(groupId).set(model);
        Toast.makeText(this, "Group created", Toast.LENGTH_SHORT).show();
        finish();
    }
}
