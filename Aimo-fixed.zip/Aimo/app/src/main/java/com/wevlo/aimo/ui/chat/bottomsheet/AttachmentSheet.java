package com.wevlo.aimo.ui.chat.bottomsheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.SheetAttachmentBinding;

import java.util.Arrays;
import java.util.List;

public class AttachmentSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onAttachmentSelected(String type);
    }

    private static class AttachmentOption {
        final String type;
        final int titleRes;
        final int iconRes;
        final int colorRes;

        AttachmentOption(String type, int titleRes, int iconRes, int colorRes) {
            this.type = type;
            this.titleRes = titleRes;
            this.iconRes = iconRes;
            this.colorRes = colorRes;
        }
    }

    private SheetAttachmentBinding binding;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetAttachmentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<AttachmentOption> options = Arrays.asList(
                new AttachmentOption("DOCUMENT", R.string.attach_document, R.drawable.ic_attachment_document, R.color.aimo_attach_document),
                new AttachmentOption("CAMERA", R.string.attach_camera, R.drawable.ic_attachment_camera, R.color.aimo_attach_camera),
                new AttachmentOption("GALLERY", R.string.attach_gallery, R.drawable.ic_attachment_gallery, R.color.aimo_attach_gallery),
                new AttachmentOption("AUDIO", R.string.attach_audio, R.drawable.ic_attachment_audio, R.color.aimo_attach_audio),
                new AttachmentOption("LOCATION", R.string.attach_location, R.drawable.ic_attachment_location, R.color.aimo_attach_location),
                new AttachmentOption("CONTACT", R.string.attach_contact, R.drawable.ic_attachment_contact, R.color.aimo_attach_contact)
        );

        binding.rvAttachments.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        binding.rvAttachments.setAdapter(new RecyclerView.Adapter<OptionVH>() {
            @NonNull
            @Override
            public OptionVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_attachment_grid, parent, false);
                return new OptionVH(itemView);
            }

            @Override
            public void onBindViewHolder(@NonNull OptionVH holder, int position) {
                AttachmentOption opt = options.get(position);
                holder.tvLabel.setText(opt.titleRes);
                holder.ivIcon.setImageResource(opt.iconRes);
                holder.ivIcon.getBackground().setTint(
                        ContextCompat.getColor(requireContext(), opt.colorRes));
                holder.itemView.setOnClickListener(v -> {
                    if (listener != null) listener.onAttachmentSelected(opt.type);
                    dismiss();
                });
            }

            @Override
            public int getItemCount() {
                return options.size();
            }
        });
    }

    static class OptionVH extends RecyclerView.ViewHolder {
        final ImageView ivIcon;
        final TextView tvLabel;

        OptionVH(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivTileIcon);
            tvLabel = itemView.findViewById(R.id.tvTileLabel);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
