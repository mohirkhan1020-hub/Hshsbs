package com.wevlo.aimo.ui.chat.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageButton;

public class VoiceRecordButton extends AppCompatImageButton {

    public interface VoiceRecordListener {
        void onRecordStart();
        void onRecordStop(boolean cancelled);
    }

    private VoiceRecordListener listener;
    private float downX;
    private boolean recording = false;
    private boolean cancelled = false;
    private final float cancelThreshold;

    public VoiceRecordButton(@NonNull Context context) {
        this(context, null);
    }

    public VoiceRecordButton(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VoiceRecordButton(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        cancelThreshold = 96f * getResources().getDisplayMetrics().density;
    }

    public void setVoiceRecordListener(VoiceRecordListener listener) {
        this.listener = listener;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                recording = true;
                cancelled = false;
                animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).start();
                if (listener != null) listener.onRecordStart();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (recording) {
                    float dragLeft = downX - event.getRawX();
                    if (dragLeft > cancelThreshold) {
                        cancelled = true;
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (recording) {
                    recording = false;
                    animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    if (listener != null) {
                        listener.onRecordStop(cancelled || event.getActionMasked() == MotionEvent.ACTION_CANCEL);
                    }
                }
                return true;
        }
        return super.onTouchEvent(event);
    }
}
