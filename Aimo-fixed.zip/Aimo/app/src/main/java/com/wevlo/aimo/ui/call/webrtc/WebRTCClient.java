package com.wevlo.aimo.ui.call.webrtc;

import android.content.Context;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;

import java.util.Collections;

public class WebRTCClient {

    public interface Events {
        void onLocalIceCandidate(IceCandidate candidate);
        void onLocalSdpCreated(SessionDescription sdp);
        void onRemoteVideoTrack(VideoTrack videoTrack);
        void onConnected();
        void onDisconnected();
    }

    private final Context context;
    private final EglBase eglBase;
    private final Events events;
    private PeerConnectionFactory factory;
    private PeerConnection peerConnection;
    private AudioSource audioSource;
    private AudioTrack localAudioTrack;
    private VideoSource videoSource;
    private VideoTrack localVideoTrack;
    private VideoCapturer videoCapturer;
    private SurfaceTextureHelper surfaceTextureHelper;

    public WebRTCClient(Context context, EglBase eglBase, Events events) {
        this.context = context.getApplicationContext();
        this.eglBase = eglBase;
        this.events = events;
        initFactory();
    }

    private void initFactory() {
        PeerConnectionFactory.InitializationOptions opts =
                PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions();
        PeerConnectionFactory.initialize(opts);

        factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(new DefaultVideoEncoderFactory(eglBase.getEglBaseContext(), true, true))
                .setVideoDecoderFactory(new DefaultVideoDecoderFactory(eglBase.getEglBaseContext()))
                .createPeerConnectionFactory();
    }

    public void startLocalMedia(boolean isVideo, SurfaceViewRenderer localRenderer) {
        audioSource = factory.createAudioSource(new MediaConstraints());
        localAudioTrack = factory.createAudioTrack("AIMO_AUDIO", audioSource);

        if (isVideo) {
            videoCapturer = createCameraCapturer();
            if (videoCapturer != null) {
                surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.getEglBaseContext());
                videoSource = factory.createVideoSource(videoCapturer.isScreencast());
                videoCapturer.initialize(surfaceTextureHelper, context, videoSource.getCapturerObserver());
                videoCapturer.startCapture(720, 1280, 24);
                localVideoTrack = factory.createVideoTrack("AIMO_VIDEO", videoSource);
                if (localRenderer != null) {
                    localVideoTrack.addSink(localRenderer);
                }
            }
        }
    }

    public void createPeerConnection() {
        PeerConnection.RTCConfiguration config =
                new PeerConnection.RTCConfiguration(TurnServerConfig.getIceServers());
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;

        peerConnection = factory.createPeerConnection(config, new PeerConnectionObserver() {
            @Override
            public void onIceCandidate(IceCandidate iceCandidate) {
                if (events != null) events.onLocalIceCandidate(iceCandidate);
            }

            @Override
            public void onAddStream(MediaStream mediaStream) {
                if (mediaStream.videoTracks != null && !mediaStream.videoTracks.isEmpty() && events != null) {
                    events.onRemoteVideoTrack(mediaStream.videoTracks.get(0));
                }
            }

            @Override
            public void onIceConnectionChange(PeerConnection.IceConnectionState state) {
                if (events == null) return;
                if (state == PeerConnection.IceConnectionState.CONNECTED) {
                    events.onConnected();
                } else if (state == PeerConnection.IceConnectionState.DISCONNECTED
                        || state == PeerConnection.IceConnectionState.FAILED) {
                    events.onDisconnected();
                }
            }
        });

        if (peerConnection != null) {
            if (localAudioTrack != null) {
                peerConnection.addTrack(localAudioTrack, Collections.singletonList("AIMO_STREAM"));
            }
            if (localVideoTrack != null) {
                peerConnection.addTrack(localVideoTrack, Collections.singletonList("AIMO_STREAM"));
            }
        }
    }

    public void createOffer() {
        if (peerConnection == null) return;
        MediaConstraints constraints = new MediaConstraints();
        peerConnection.createOffer(new SimpleSdpObserver() {
            @Override
            public void onCreateSuccess(SessionDescription sdp) {
                peerConnection.setLocalDescription(new SimpleSdpObserver(), sdp);
                if (events != null) events.onLocalSdpCreated(sdp);
            }
        }, constraints);
    }

    public void createAnswer() {
        if (peerConnection == null) return;
        MediaConstraints constraints = new MediaConstraints();
        peerConnection.createAnswer(new SimpleSdpObserver() {
            @Override
            public void onCreateSuccess(SessionDescription sdp) {
                peerConnection.setLocalDescription(new SimpleSdpObserver(), sdp);
                if (events != null) events.onLocalSdpCreated(sdp);
            }
        }, constraints);
    }

    public void setRemoteDescription(SessionDescription.Type type, String sdp) {
        if (peerConnection == null) return;
        peerConnection.setRemoteDescription(new SimpleSdpObserver(), new SessionDescription(type, sdp));
    }

    public void addIceCandidate(IceCandidate candidate) {
        if (peerConnection != null && candidate != null) {
            peerConnection.addIceCandidate(candidate);
        }
    }

    public void setMicEnabled(boolean enabled) {
        if (localAudioTrack != null) localAudioTrack.setEnabled(enabled);
    }

    public void setCameraEnabled(boolean enabled) {
        if (localVideoTrack != null) localVideoTrack.setEnabled(enabled);
    }

    public void switchCamera() {
        if (videoCapturer instanceof CameraVideoCapturer) {
            ((CameraVideoCapturer) videoCapturer).switchCamera(null);
        }
    }

    private VideoCapturer createCameraCapturer() {
        Camera2Enumerator enumerator = new Camera2Enumerator(context);
        for (String name : enumerator.getDeviceNames()) {
            if (enumerator.isFrontFacing(name)) {
                VideoCapturer capturer = enumerator.createCapturer(name, null);
                if (capturer != null) return capturer;
            }
        }
        for (String name : enumerator.getDeviceNames()) {
            VideoCapturer capturer = enumerator.createCapturer(name, null);
            if (capturer != null) return capturer;
        }
        return null;
    }

    public void release() {
        try {
            if (videoCapturer != null) {
                videoCapturer.stopCapture();
                videoCapturer.dispose();
            }
        } catch (Exception ignored) {
        }
        if (surfaceTextureHelper != null) surfaceTextureHelper.dispose();
        if (videoSource != null) videoSource.dispose();
        if (audioSource != null) audioSource.dispose();
        if (peerConnection != null) peerConnection.close();
        if (factory != null) factory.dispose();
    }

    private static class SimpleSdpObserver implements SdpObserver {
        @Override
        public void onCreateSuccess(SessionDescription sdp) {
        }

        @Override
        public void onSetSuccess() {
        }

        @Override
        public void onCreateFailure(String error) {
        }

        @Override
        public void onSetFailure(String error) {
        }
    }
}
