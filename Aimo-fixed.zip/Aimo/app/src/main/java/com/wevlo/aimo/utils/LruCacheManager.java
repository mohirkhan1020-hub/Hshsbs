package com.wevlo.aimo.utils;

import android.graphics.Bitmap;
import android.util.LruCache;

public class LruCacheManager {

    private static volatile LruCacheManager instance;
    private final LruCache<String, Bitmap> memoryCache;

    private LruCacheManager() {
        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = Math.max(4096, maxMemory / 8);
        memoryCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
    }

    public static LruCacheManager getInstance() {
        if (instance == null) {
            synchronized (LruCacheManager.class) {
                if (instance == null) {
                    instance = new LruCacheManager();
                }
            }
        }
        return instance;
    }

    public void putBitmap(String key, Bitmap bitmap) {
        if (key == null || bitmap == null || bitmap.isRecycled()) return;
        memoryCache.put(key, bitmap);
    }

    public Bitmap getBitmap(String key) {
        if (key == null) return null;
        return memoryCache.get(key);
    }

    public void removeBitmap(String key) {
        if (key != null) {
            memoryCache.remove(key);
        }
    }

    public void clear() {
        memoryCache.evictAll();
    }
}
