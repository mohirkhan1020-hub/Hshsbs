package com.wevlo.aimo.ui.chat.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.wevlo.aimo.R;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class ReactionPillView extends LinearLayout {

    private final TextView tvContent;

    public ReactionPillView(Context context) {
        this(context, null);
    }

    public ReactionPillView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ReactionPillView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
        setBackgroundResource(R.drawable.bg_reaction_pill);
        float d = getResources().getDisplayMetrics().density;
        setPadding((int) (8 * d), (int) (2 * d), (int) (8 * d), (int) (2 * d));

        tvContent = new TextView(context);
        tvContent.setTextSize(12f);
        tvContent.setTextColor(ContextCompat.getColor(context, R.color.aimo_text_primary));
        addView(tvContent);
    }

    public void setReactions(Map<String, String> reactions) {
        if (reactions == null || reactions.isEmpty()) {
            setVisibility(GONE);
            return;
        }
        Set<String> unique = new LinkedHashSet<>(reactions.values());
        StringBuilder sb = new StringBuilder();
        for (String emoji : unique) {
            sb.append(emoji);
        }
        if (reactions.size() > 1) {
            sb.append(" ").append(reactions.size());
        }
        tvContent.setText(sb.toString());
        setVisibility(VISIBLE);
    }
}
