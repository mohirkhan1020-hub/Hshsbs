package com.wevlo.aimo.ui.media.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DoodleView extends View {

    private static class Stroke {
        final Path path;
        final Paint paint;
        Stroke(Path path, Paint paint) { this.path = path; this.paint = paint; }
    }

    private final List<Stroke> strokes = new ArrayList<>();
    private Path currentPath;
    private int strokeColor = Color.parseColor("#25D366");
    private boolean drawingEnabled = false;

    public DoodleView(Context context) { this(context, null); }
    public DoodleView(Context context, @Nullable AttributeSet attrs) { this(context, attrs, 0); }
    public DoodleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }

    public void setDrawingEnabled(boolean enabled) { this.drawingEnabled = enabled; }
    public boolean isDrawingEnabled() { return drawingEnabled; }
    public void setStrokeColor(int color) { this.strokeColor = color; }

    public void undo() {
        if (!strokes.isEmpty()) {
            strokes.remove(strokes.size() - 1);
            invalidate();
        }
    }

    public void clear() {
        strokes.clear();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!drawingEnabled) return false;
        float x = event.getX(), y = event.getY();
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            currentPath = new Path();
            currentPath.moveTo(x, y);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(strokeColor);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(10f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            strokes.add(new Stroke(currentPath, paint));
            invalidate();
            return true;
        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (currentPath != null) { currentPath.lineTo(x, y); invalidate(); }
            return true;
        } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            currentPath = null;
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Stroke s : strokes) canvas.drawPath(s.path, s.paint);
    }

    public Bitmap compositeOnto(Bitmap base) {
        if (base == null || strokes.isEmpty() || getWidth() <= 0 || getHeight() <= 0) return base;
        Bitmap result = base.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(result);
        canvas.scale((float) base.getWidth() / getWidth(), (float) base.getHeight() / getHeight());
        for (Stroke s : strokes) canvas.drawPath(s.path, s.paint);
        return result;
    }
}
