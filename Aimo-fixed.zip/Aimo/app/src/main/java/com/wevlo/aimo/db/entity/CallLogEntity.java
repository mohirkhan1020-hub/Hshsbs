package com.wevlo.aimo.db.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.CallLogModel;

@Entity(tableName = "call_logs")
public class CallLogEntity {

    @PrimaryKey
    @NonNull
    public String callId = "";

    public String peerId = "";
    public String peerName = "";
    public String peerPhoto = "";
    public boolean isVideo = false;
    public String direction = Constants.CALL_DIR_OUTGOING;
    public String status = Constants.CALL_STATE_ENDED;
    public long startedAt = 0L;
    public long durationSec = 0L;

    public CallLogEntity() {
    }

    @Ignore
    public static CallLogEntity fromModel(CallLogModel model, String currentUid) {
        CallLogEntity entity = new CallLogEntity();
        if (model == null) return entity;
        entity.callId = model.callId != null ? model.callId : "";
        boolean isCaller = currentUid != null && currentUid.equals(model.callerId);
        entity.peerId = isCaller ? model.receiverId : model.callerId;
        entity.peerName = isCaller ? model.receiverName : model.callerName;
        entity.peerPhoto = isCaller ? model.receiverPhoto : model.callerPhoto;
        entity.isVideo = model.isVideo;
        if (Constants.CALL_STATE_MISSED.equals(model.status) && !isCaller) {
            entity.direction = Constants.CALL_DIR_MISSED;
        } else {
            entity.direction = isCaller ? Constants.CALL_DIR_OUTGOING : Constants.CALL_DIR_INCOMING;
        }
        entity.status = model.status != null ? model.status : Constants.CALL_STATE_ENDED;
        entity.startedAt = model.startedAt;
        entity.durationSec = model.durationSec;
        return entity;
    }
}
