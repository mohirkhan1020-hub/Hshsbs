package com.wevlo.aimo.utils;

import android.content.Context;
import android.media.MediaRecorder;
import android.os.Build;

import java.io.File;

public class AudioRecorderHelper {

    private final Context context;
    private MediaRecorder recorder;
    private File outputFile;
    private long startTimeMs = 0L;
    private long lastDurationMs = 0L;

    public AudioRecorderHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    public void startRecording() {
        try {
            outputFile = new File(context.getCacheDir(), "rec_" + System.currentTimeMillis() + ".m4a");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                recorder = new MediaRecorder(context);
            } else {
                recorder = new MediaRecorder();
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(64000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            startTimeMs = System.currentTimeMillis();
        } catch (Exception e) {
            releaseRecorder();
            outputFile = null;
        }
    }

    public File stopRecording() {
        lastDurationMs = startTimeMs > 0 ? System.currentTimeMillis() - startTimeMs : 0L;
        if (recorder != null) {
            try {
                recorder.stop();
            } catch (Exception ignored) {
                if (outputFile != null && outputFile.exists()) {
                    outputFile.delete();
                }
                outputFile = null;
            } finally {
                releaseRecorder();
            }
        }
        return lastDurationMs >= 400 ? outputFile : null;
    }

    public long getLastDurationMs() {
        return lastDurationMs;
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try {
                recorder.reset();
                recorder.release();
            } catch (Exception ignored) {
            }
            recorder = null;
        }
    }
}
