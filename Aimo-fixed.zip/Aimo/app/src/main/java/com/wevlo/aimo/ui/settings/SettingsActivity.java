package com.wevlo.aimo.ui.settings;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ActivitySettingsBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.service.WhatsAppBgService;
import com.wevlo.aimo.ui.auth.LoginActivity;
import com.wevlo.aimo.utils.BackupRestoreHelper;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;

public class SettingsActivity extends AppCompatActivity {

    private ActivitySettingsBinding binding;
    private String myUid = "";

    private final ActivityResultLauncher<String> avatarPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::updateAvatar);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.menu_settings);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
        loadMyProfile();

        binding.ivProfile.setOnClickListener(v -> avatarPicker.launch("image/*"));
        binding.btnEditProfile.setOnClickListener(v -> showEditProfileDialog());
        binding.rowBackup.setOnClickListener(v -> BackupRestoreHelper.exportBackup(
                this, (ok, msg) -> runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show())));
        binding.rowRestore.setOnClickListener(v -> BackupRestoreHelper.importBackup(
                this, (ok, msg) -> runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show())));
        binding.rowUpdate.setOnClickListener(v ->
                new AutoUpdaterSheet().show(getSupportFragmentManager(), "auto_updater"));
        binding.rowAbout.setOnClickListener(v ->
                startActivity(new Intent(this, AboutActivity.class)));
        binding.btnSignOut.setOnClickListener(v -> signOut());
    }

    private void loadMyProfile() {
        if (myUid.isEmpty()) return;
        FirestorePaths.userDoc(myUid).get().addOnSuccessListener(doc -> {
            if (!doc.exists()) return;
            String name = doc.getString("name");
            String about = doc.getString("about");
            String photo = doc.getString("photoBase64");
            binding.tvName.setText(name != null ? name : "Aimo User");
            binding.tvAbout.setText(about != null ? about : "");
            Base64ImageUtils.loadAvatar(binding.ivProfile, "avatar_" + myUid,
                    photo, "", R.drawable.ic_attachment_contact);
        });
    }

    private void updateAvatar(Uri uri) {
        if (uri == null || myUid.isEmpty()) return;
        AppDatabase.dbExecutor.execute(() -> {
            String b64 = Base64ImageUtils.uriToBase64(this, uri);
            if (!b64.isEmpty()) {
                FirestorePaths.userDoc(myUid).update("photoBase64", b64);
                runOnUiThread(() -> Base64ImageUtils.loadAvatar(
                        binding.ivProfile, "avatar_" + myUid + "_new", b64, "", R.drawable.ic_attachment_contact));
            }
        });
    }

    private void showEditProfileDialog() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = getResources().getDimensionPixelSize(R.dimen.spacing_lg);
        container.setPadding(pad, pad, pad, pad);

        EditText etName = new EditText(this);
        etName.setHint(R.string.hint_full_name);
        etName.setText(binding.tvName.getText());
        EditText etAbout = new EditText(this);
        etAbout.setHint(R.string.hint_about);
        etAbout.setText(binding.tvAbout.getText());
        container.addView(etName);
        container.addView(etAbout);

        new AlertDialog.Builder(this)
                .setTitle("Edit Profile")
                .setView(container)
                .setPositiveButton(R.string.action_save, (d, w) -> {
                    String newName = etName.getText().toString().trim();
                    String newAbout = etAbout.getText().toString().trim();
                    if (!newName.isEmpty() && !myUid.isEmpty()) {
                        FirestorePaths.userDoc(myUid).update("name", newName, "about", newAbout);
                        getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE)
                                .edit().putString(Constants.PREF_CURRENT_NAME, newName).apply();
                        binding.tvName.setText(newName);
                        binding.tvAbout.setText(newAbout);
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void signOut() {
        stopService(new Intent(this, WhatsAppBgService.class));
        if (!myUid.isEmpty()) {
            FirestorePaths.userDoc(myUid).update("online", false, "lastSeen", System.currentTimeMillis());
            FirestorePaths.deviceBindingDoc(myUid).update("active", false);
        }
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
