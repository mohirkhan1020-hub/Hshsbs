package com.wevlo.aimo.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public final class PermissionHelper {

    public static final int REQ_CORE_PERMISSIONS = 101;
    public static final int REQ_CALL_PERMISSIONS = 102;
    public static final int REQ_MEDIA_PERMISSIONS = 103;

    private PermissionHelper() {
    }

    public static String[] getCorePermissions() {
        List<String> perms = new ArrayList<>();
        perms.add(Manifest.permission.CAMERA);
        perms.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
            perms.add(Manifest.permission.READ_MEDIA_IMAGES);
            perms.add(Manifest.permission.READ_MEDIA_VIDEO);
            perms.add(Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        return perms.toArray(new String[0]);
    }

    public static boolean hasPermission(Context context, String permission) {
        return ContextCompat.checkSelfPermission(context, permission)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean hasCallPermissions(Context context, boolean isVideo) {
        boolean audio = hasPermission(context, Manifest.permission.RECORD_AUDIO);
        if (!isVideo) return audio;
        return audio && hasPermission(context, Manifest.permission.CAMERA);
    }

    public static void requestCorePermissions(Activity activity) {
        List<String> missing = new ArrayList<>();
        for (String perm : getCorePermissions()) {
            if (!hasPermission(activity, perm)) {
                missing.add(perm);
            }
        }
        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(
                    activity,
                    missing.toArray(new String[0]),
                    REQ_CORE_PERMISSIONS
            );
        }
    }

    public static void requestCallPermissions(Activity activity, boolean isVideo) {
        List<String> missing = new ArrayList<>();
        if (!hasPermission(activity, Manifest.permission.RECORD_AUDIO)) {
            missing.add(Manifest.permission.RECORD_AUDIO);
        }
        if (isVideo && !hasPermission(activity, Manifest.permission.CAMERA)) {
            missing.add(Manifest.permission.CAMERA);
        }
        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(
                    activity,
                    missing.toArray(new String[0]),
                    REQ_CALL_PERMISSIONS
            );
        }
    }
}
