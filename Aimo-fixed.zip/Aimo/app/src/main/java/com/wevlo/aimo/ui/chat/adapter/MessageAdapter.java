package com.wevlo.aimo.ui.chat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ItemMessageIncomingBinding;
import com.wevlo.aimo.databinding.ItemMessageOutgoingBinding;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_INCOMING = 1;
    private static final int TYPE_OUTGOING = 2;

    public interface Listener {
        void onMessageLongClicked(MessageEntity message);
        void onSwipeReply(MessageEntity message);
        void onReactionClicked(MessageEntity message);
        void onImageClicked(MessageEntity message);
    }

    private final String myUid;
    private final Listener listener;
    private final List<MessageEntity> messages = new ArrayList<>();

    public MessageAdapter(String myUid, Listener listener) {
        this.myUid = myUid != null ? myUid : "";
        this.listener = listener;
    }

    public void submitList(List<MessageEntity> list) {
        messages.clear();
        if (list != null) messages.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return myUid.equals(messages.get(position).senderId) ? TYPE_OUTGOING : TYPE_INCOMING;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        return viewType == TYPE_OUTGOING
                ? new OutgoingVH(ItemMessageOutgoingBinding.inflate(inf, parent, false))
                : new IncomingVH(ItemMessageIncomingBinding.inflate(inf, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MessageEntity msg = messages.get(position);
        boolean showDate = position == 0 || !DateUtils.isSameDay(messages.get(position - 1).timestamp, msg.timestamp);
        if (holder instanceof OutgoingVH) {
            ItemMessageOutgoingBinding b = ((OutgoingVH) holder).binding;
            b.tvDateDivider.setVisibility(showDate ? View.VISIBLE : View.GONE);
            if (showDate) b.tvDateDivider.setText(DateUtils.formatDateDivider(msg.timestamp));
            b.layoutReply.setVisibility(!msg.replyToText.isEmpty() ? View.VISIBLE : View.GONE);
            b.tvReplySender.setText(msg.replyToSender);
            b.tvReplyText.setText(msg.replyToText);
            boolean isImage = Constants.MSG_IMAGE.equals(msg.type) && !msg.deleted && !msg.mediaBase64.isEmpty();
            boolean isAudio = Constants.MSG_AUDIO.equals(msg.type) && !msg.deleted;
            b.ivMedia.setVisibility(isImage ? View.VISIBLE : View.GONE);
            if (isImage) Base64ImageUtils.loadImage(b.ivMedia, "msg_" + msg.messageId, msg.mediaBase64, msg.mediaUrl, R.drawable.bg_bubble_outgoing_media);
            b.voicePlayer.setVisibility(isAudio ? View.VISIBLE : View.GONE);
            if (isAudio) b.voicePlayer.bind(msg.messageId, msg.mediaBase64, msg.localPath, msg.durationMs);
            b.tvMessage.setVisibility(isAudio ? View.GONE : View.VISIBLE);
            b.tvMessage.setText(msg.deleted ? "This message was deleted" : msg.text);
            b.tvTime.setText((msg.edited && !msg.deleted ? "Edited · " : "") + DateUtils.formatMessageTime(msg.timestamp));
            b.ivTick.setImageResource(msg.status >= Constants.STATUS_DELIVERED ? R.drawable.ic_check_double : R.drawable.ic_check);
            b.reactionPill.setReactions(msg.reactions);
            b.reactionPill.setOnClickListener(v -> { if (listener != null) listener.onReactionClicked(msg); });
            b.swipeReply.setSwipeListener(() -> { if (listener != null) listener.onSwipeReply(msg); });
            b.bubbleContainer.setOnLongClickListener(v -> { if (listener != null) listener.onMessageLongClicked(msg); return true; });
            b.ivMedia.setOnClickListener(v -> { if (listener != null) listener.onImageClicked(msg); });
        } else {
            ItemMessageIncomingBinding b = ((IncomingVH) holder).binding;
            b.tvDateDivider.setVisibility(showDate ? View.VISIBLE : View.GONE);
            if (showDate) b.tvDateDivider.setText(DateUtils.formatDateDivider(msg.timestamp));
            b.tvSenderName.setVisibility(!msg.senderName.isEmpty() ? View.VISIBLE : View.GONE);
            b.tvSenderName.setText(msg.senderName);
            b.layoutReply.setVisibility(!msg.replyToText.isEmpty() ? View.VISIBLE : View.GONE);
            b.tvReplySender.setText(msg.replyToSender);
            b.tvReplyText.setText(msg.replyToText);
            boolean isImage = Constants.MSG_IMAGE.equals(msg.type) && !msg.deleted && !msg.mediaBase64.isEmpty();
            boolean isAudio = Constants.MSG_AUDIO.equals(msg.type) && !msg.deleted;
            b.ivMedia.setVisibility(isImage ? View.VISIBLE : View.GONE);
            if (isImage) Base64ImageUtils.loadImage(b.ivMedia, "msg_" + msg.messageId, msg.mediaBase64, msg.mediaUrl, R.drawable.bg_bubble_incoming_media);
            b.voicePlayer.setVisibility(isAudio ? View.VISIBLE : View.GONE);
            if (isAudio) b.voicePlayer.bind(msg.messageId, msg.mediaBase64, msg.localPath, msg.durationMs);
            b.tvMessage.setVisibility(isAudio ? View.GONE : View.VISIBLE);
            b.tvMessage.setText(msg.deleted ? "This message was deleted" : msg.text);
            b.tvTime.setText((msg.edited && !msg.deleted ? "Edited · " : "") + DateUtils.formatMessageTime(msg.timestamp));
            b.reactionPill.setReactions(msg.reactions);
            b.reactionPill.setOnClickListener(v -> { if (listener != null) listener.onReactionClicked(msg); });
            b.swipeReply.setSwipeListener(() -> { if (listener != null) listener.onSwipeReply(msg); });
            b.bubbleContainer.setOnLongClickListener(v -> { if (listener != null) listener.onMessageLongClicked(msg); return true; });
            b.ivMedia.setOnClickListener(v -> { if (listener != null) listener.onImageClicked(msg); });
        }
    }

    @Override public int getItemCount() { return messages.size(); }

    static class OutgoingVH extends RecyclerView.ViewHolder {
        final ItemMessageOutgoingBinding binding;
        OutgoingVH(ItemMessageOutgoingBinding b) { super(b.getRoot()); binding = b; }
    }

    static class IncomingVH extends RecyclerView.ViewHolder {
        final ItemMessageIncomingBinding binding;
        IncomingVH(ItemMessageIncomingBinding b) { super(b.getRoot()); binding = b; }
    }
}
