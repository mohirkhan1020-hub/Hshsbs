package com.wevlo.aimo.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.wevlo.aimo.Constants;

public final class Base64ImageUtils {

    private Base64ImageUtils() {
    }

    public static String uriToBase64(Context context, Uri uri) {
        Bitmap bitmap = ImageCompressor.decodeSampledBitmap(context, uri, Constants.MAX_IMAGE_DIM);
        if (bitmap == null) return "";
        return bitmapToBase64(bitmap);
    }

    public static String bitmapToBase64(Bitmap bitmap) {
        if (bitmap == null) return "";
        byte[] bytes = ImageCompressor.compressToJpeg(bitmap, Constants.MAX_BASE64_BYTES);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    public static Bitmap base64ToBitmap(String base64) {
        if (base64 == null || base64.isEmpty()) return null;
        try {
            byte[] decoded = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
        } catch (Exception e) {
            return null;
        }
    }

    public static void loadAvatar(ImageView imageView, String cacheKey, String base64, String url, int placeholderRes) {
        if (imageView == null) return;
        if (base64 != null && !base64.isEmpty()) {
            String key = cacheKey != null ? cacheKey : String.valueOf(base64.hashCode());
            Bitmap cached = LruCacheManager.getInstance().getBitmap(key);
            if (cached == null) {
                cached = base64ToBitmap(base64);
                if (cached != null) {
                    LruCacheManager.getInstance().putBitmap(key, cached);
                }
            }
            if (cached != null) {
                Glide.with(imageView.getContext())
                        .load(cached)
                        .circleCrop()
                        .placeholder(placeholderRes)
                        .into(imageView);
                return;
            }
        }

        if (url != null && !url.isEmpty()) {
            Glide.with(imageView.getContext())
                    .load(url)
                    .circleCrop()
                    .placeholder(placeholderRes)
                    .into(imageView);
        } else {
            imageView.setImageResource(placeholderRes);
        }
    }

    public static void loadImage(ImageView imageView, String cacheKey, String base64, String url, int placeholderRes) {
        if (imageView == null) return;
        if (base64 != null && !base64.isEmpty()) {
            String key = cacheKey != null ? cacheKey : String.valueOf(base64.hashCode());
            Bitmap cached = LruCacheManager.getInstance().getBitmap(key);
            if (cached == null) {
                cached = base64ToBitmap(base64);
                if (cached != null) {
                    LruCacheManager.getInstance().putBitmap(key, cached);
                }
            }
            if (cached != null) {
                imageView.setImageBitmap(cached);
                return;
            }
        }
        if (url != null && !url.isEmpty()) {
            Glide.with(imageView.getContext())
                    .load(url)
                    .placeholder(placeholderRes)
                    .into(imageView);
        } else {
            imageView.setImageResource(placeholderRes);
        }
    }
}
