package com.wevlo.aimo.ui.chat.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class SwipeReplyLayout extends FrameLayout {

    public interface SwipeListener {
        void onSwipeReply();
    }

    private SwipeListener swipeListener;
    private float startX;
    private float startY;
    private boolean isSwiping = false;
    private boolean triggered = false;
    private final int touchSlop;
    private final float triggerThreshold;

    public SwipeReplyLayout(@NonNull Context context) {
        this(context, null);
    }

    public SwipeReplyLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SwipeReplyLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        triggerThreshold = 64f * getResources().getDisplayMetrics().density;
    }

    public void setSwipeListener(SwipeListener listener) {
        this.swipeListener = listener;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startX = ev.getX();
                startY = ev.getY();
                isSwiping = false;
                triggered = false;
                break;
            case MotionEvent.ACTION_MOVE:
                float dx = ev.getX() - startX;
                float dy = Math.abs(ev.getY() - startY);
                if (dx > touchSlop && dx > dy * 1.5f) {
                    isSwiping = true;
                    return true;
                }
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        View child = getChildCount() > 0 ? getChildAt(0) : null;
        if (child == null) return super.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                float dx = Math.max(0f, Math.min(event.getX() - startX, triggerThreshold * 1.3f));
                if (isSwiping || dx > touchSlop) {
                    isSwiping = true;
                    child.setTranslationX(dx);
                    if (dx >= triggerThreshold && !triggered) {
                        triggered = true;
                        performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                    }
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (isSwiping) {
                    child.animate().translationX(0f).setDuration(150).start();
                    if (triggered && swipeListener != null) {
                        swipeListener.onSwipeReply();
                    }
                    isSwiping = false;
                    triggered = false;
                    return true;
                }
                break;
        }
        return super.onTouchEvent(event);
    }
}
