package com.wevlo.aimo.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.CallLogModel;
import com.wevlo.aimo.databinding.FragmentCallsBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.CallLogEntity;
import com.wevlo.aimo.ui.call.ActiveCallActivity;
import com.wevlo.aimo.ui.home.adapter.CallLogAdapter;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.List;

public class CallsFragment extends Fragment {

    private FragmentCallsBinding binding;
    private CallLogAdapter adapter;
    private final List<CallLogEntity> allCalls = new ArrayList<>();
    private String searchQuery = "";
    private ListenerRegistration callerListener;
    private ListenerRegistration receiverListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentCallsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new CallLogAdapter(callLog -> {
            Intent intent = new Intent(requireContext(), ActiveCallActivity.class);
            intent.putExtra(Constants.EXTRA_PEER_UID, callLog.peerId);
            intent.putExtra(Constants.EXTRA_PEER_NAME, callLog.peerName);
            intent.putExtra(Constants.EXTRA_PEER_PHOTO, callLog.peerPhoto);
            intent.putExtra(Constants.EXTRA_IS_VIDEO, callLog.isVideo);
            intent.putExtra(Constants.EXTRA_IS_INCOMING, false);
            startActivity(intent);
        });

        binding.rvCalls.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvCalls.setAdapter(adapter);

        binding.swipeRefresh.setColorSchemeResources(R.color.aimo_accent);
        binding.swipeRefresh.setOnRefreshListener(() -> {
            syncCalls();
            binding.swipeRefresh.setRefreshing(false);
        });

        observeCalls();
        syncCalls();
    }

    public void setSearchQuery(String query) {
        this.searchQuery = query != null ? query.toLowerCase() : "";
        if (binding != null) {
            filterCalls();
        }
    }

    private void observeCalls() {
        AppDatabase.getInstance(requireContext()).callLogDao()
                .observeAllCallLogs()
                .observe(getViewLifecycleOwner(), calls -> {
                    allCalls.clear();
                    if (calls != null) allCalls.addAll(calls);
                    filterCalls();
                });
    }

    private void filterCalls() {
        List<CallLogEntity> filtered = new ArrayList<>();
        for (CallLogEntity c : allCalls) {
            if (searchQuery.isEmpty() || c.peerName.toLowerCase().contains(searchQuery)) {
                filtered.add(c);
            }
        }
        adapter.submitList(filtered);
        binding.tvEmptyCalls.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void syncCalls() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null) return;

        if (callerListener != null) callerListener.remove();
        callerListener = FirestorePaths.callsCol()
                .whereEqualTo("callerId", myUid)
                .addSnapshotListener((snapshots, error) -> saveSnapshots(snapshots, myUid));

        if (receiverListener != null) receiverListener.remove();
        receiverListener = FirestorePaths.callsCol()
                .whereEqualTo("receiverId", myUid)
                .addSnapshotListener((snapshots, error) -> saveSnapshots(snapshots, myUid));
    }

    private void saveSnapshots(QuerySnapshot snapshots, String myUid) {
        if (snapshots == null || getContext() == null) return;
        List<CallLogEntity> list = new ArrayList<>();
        for (DocumentSnapshot doc : snapshots.getDocuments()) {
            CallLogModel model = doc.toObject(CallLogModel.class);
            if (model != null) {
                list.add(CallLogEntity.fromModel(model, myUid));
            }
        }
        AppDatabase db = AppDatabase.getInstance(requireContext().getApplicationContext());
        AppDatabase.dbExecutor.execute(() -> db.callLogDao().insertAll(list));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (callerListener != null) callerListener.remove();
        if (receiverListener != null) receiverListener.remove();
        binding = null;
    }
}
