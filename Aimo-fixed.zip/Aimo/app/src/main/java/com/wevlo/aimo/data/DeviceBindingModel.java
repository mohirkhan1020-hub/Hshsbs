package com.wevlo.aimo.data;

public class DeviceBindingModel {

    public String uid = "";
    public String email = "";
    public String deviceId = "";
    public String deviceName = "";
    public long boundAt = 0L;
    public long lastActiveAt = 0L;
    public boolean active = true;

    public DeviceBindingModel() {
    }

    public DeviceBindingModel(String uid, String email, String deviceId, String deviceName) {
        this.uid = uid != null ? uid : "";
        this.email = email != null ? email : "";
        this.deviceId = deviceId != null ? deviceId : "";
        this.deviceName = deviceName != null ? deviceName : "";
        this.boundAt = System.currentTimeMillis();
        this.lastActiveAt = this.boundAt;
        this.active = true;
    }
}
