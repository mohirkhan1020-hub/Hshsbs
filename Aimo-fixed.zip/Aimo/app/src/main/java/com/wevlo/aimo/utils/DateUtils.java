package com.wevlo.aimo.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class DateUtils {

    private DateUtils() {
    }

    public static String formatMessageTime(long timestamp) {
        if (timestamp <= 0) return "";
        return new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(timestamp));
    }

    public static String formatChatTime(long timestamp) {
        if (timestamp <= 0) return "";
        if (isToday(timestamp)) {
            return formatMessageTime(timestamp);
        } else if (isYesterday(timestamp)) {
            return "Yesterday";
        }
        return new SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(new Date(timestamp));
    }

    public static String formatDateDivider(long timestamp) {
        if (timestamp <= 0) return "";
        if (isToday(timestamp)) return "Today";
        if (isYesterday(timestamp)) return "Yesterday";
        return new SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(new Date(timestamp));
    }

    public static String formatLastSeen(long timestamp) {
        if (timestamp <= 0) return "last seen recently";
        if (isToday(timestamp)) {
            return "last seen today at " + formatMessageTime(timestamp);
        } else if (isYesterday(timestamp)) {
            return "last seen yesterday at " + formatMessageTime(timestamp);
        }
        String date = new SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(new Date(timestamp));
        return "last seen " + date + " at " + formatMessageTime(timestamp);
    }

    public static String formatDuration(long seconds) {
        long mins = seconds / 60;
        long secs = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", mins, secs);
    }

    public static boolean isSameDay(long ts1, long ts2) {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(ts1);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(ts2);
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR)
                && c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR);
    }

    public static boolean isToday(long timestamp) {
        return isSameDay(timestamp, System.currentTimeMillis());
    }

    public static boolean isYesterday(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        return isSameDay(timestamp, cal.getTimeInMillis());
    }
}
