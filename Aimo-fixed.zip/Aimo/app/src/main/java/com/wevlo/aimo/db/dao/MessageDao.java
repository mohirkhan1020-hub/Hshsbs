package com.wevlo.aimo.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.wevlo.aimo.db.entity.MessageEntity;

import java.util.List;

@Dao
public interface MessageDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(MessageEntity message);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<MessageEntity> messages);

    @Update
    void update(MessageEntity message);

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    LiveData<List<MessageEntity>> observeMessages(String chatId);

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    List<MessageEntity> getMessagesSync(String chatId);

    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    List<MessageEntity> getAllMessagesSync();

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    MessageEntity getMessageById(String messageId);

    @Query("SELECT * FROM messages WHERE starred = 1 ORDER BY timestamp DESC")
    LiveData<List<MessageEntity>> observeStarredMessages();

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    void updateStatus(String messageId, int status);

    @Query("UPDATE messages SET status = 3 WHERE chatId = :chatId AND senderId != :myUid AND status < 3")
    void markChatRead(String chatId, String myUid);

    @Query("UPDATE messages SET deleted = 1, text = 'This message was deleted', mediaBase64 = '', mediaUrl = '' WHERE messageId = :messageId")
    void markDeleted(String messageId);

    @Query("UPDATE messages SET starred = :starred WHERE messageId = :messageId")
    void setStarred(String messageId, boolean starred);

    @Query("DELETE FROM messages WHERE messageId = :messageId")
    void deleteById(String messageId);

    @Query("DELETE FROM messages WHERE chatId = :chatId")
    void deleteChatMessages(String chatId);

    @Query("DELETE FROM messages")
    void deleteAll();
}
