package com.wevlo.aimo.utils;

import android.content.Context;

import com.google.gson.Gson;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.db.entity.UserEntity;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

public final class BackupRestoreHelper {

    public interface Callback {
        void onComplete(boolean success, String message);
    }

    private static class BackupPayload {
        List<UserEntity> users;
        List<MessageEntity> messages;
    }

    private BackupRestoreHelper() {
    }

    public static void exportBackup(Context context, Callback callback) {
        AppDatabase.dbExecutor.execute(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(context);
                BackupPayload payload = new BackupPayload();
                payload.users = db.userDao().getAllUsersSync();
                payload.messages = db.messageDao().getAllMessagesSync();

                File outFile = new File(context.getExternalFilesDir(null), "aimo_backup.json");
                try (FileWriter writer = new FileWriter(outFile)) {
                    new Gson().toJson(payload, writer);
                }
                if (callback != null) {
                    callback.onComplete(true, "Backup saved: " + outFile.getName());
                }
            } catch (Exception e) {
                if (callback != null) {
                    callback.onComplete(false, "Backup failed");
                }
            }
        });
    }

    public static void importBackup(Context context, Callback callback) {
        AppDatabase.dbExecutor.execute(() -> {
            try {
                File inFile = new File(context.getExternalFilesDir(null), "aimo_backup.json");
                if (!inFile.exists()) {
                    if (callback != null) callback.onComplete(false, "No local backup found");
                    return;
                }
                BackupPayload payload;
                try (FileReader reader = new FileReader(inFile)) {
                    payload = new Gson().fromJson(reader, BackupPayload.class);
                }
                if (payload != null) {
                    AppDatabase db = AppDatabase.getInstance(context);
                    if (payload.users != null) db.userDao().insertAll(payload.users);
                    if (payload.messages != null) db.messageDao().insertAll(payload.messages);
                }
                if (callback != null) callback.onComplete(true, "Backup restored");
            } catch (Exception e) {
                if (callback != null) callback.onComplete(false, "Restore failed");
            }
        });
    }
}
