package com.wevlo.aimo.ui.home;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.CallLogModel;
import com.wevlo.aimo.data.UserModel;
import com.wevlo.aimo.databinding.ActivityMainBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.service.WhatsAppBgService;
import com.wevlo.aimo.ui.auth.LoginActivity;
import com.wevlo.aimo.ui.call.IncomingCallActivity;
import com.wevlo.aimo.ui.group.CreateGroupActivity;
import com.wevlo.aimo.ui.settings.SettingsActivity;
import com.wevlo.aimo.ui.status.StatusComposerActivity;
import com.wevlo.aimo.utils.FirestorePaths;
import com.wevlo.aimo.utils.PermissionHelper;

public class MainActivity extends AppCompatActivity {

    private static final int TAB_CHATS = 100;
    private static final int TAB_UPDATES = 101;
    private static final int TAB_CALLS = 102;

    private ActivityMainBinding binding;
    private ChatsFragment chatsFragment;
    private UpdatesFragment updatesFragment;
    private CallsFragment callsFragment;
    private ListenerRegistration incomingCallListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.app_name);
        }

        setupPagerAndNav();
        setupSearchToolbar();
        PermissionHelper.requestCorePermissions(this);
        startBackgroundService();
        listenForIncomingCalls(currentUser.getUid());
    }

    private void setupPagerAndNav() {
        chatsFragment = new ChatsFragment();
        updatesFragment = new UpdatesFragment();
        callsFragment = new CallsFragment();

        binding.viewPager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                if (position == 1) return updatesFragment;
                if (position == 2) return callsFragment;
                return chatsFragment;
            }

            @Override
            public int getItemCount() {
                return 3;
            }
        });
        binding.viewPager.setOffscreenPageLimit(2);

        Menu navMenu = binding.bottomNav.getMenu();
        navMenu.add(0, TAB_CHATS, 0, R.string.tab_chats).setIcon(R.drawable.ic_chat_filled);
        navMenu.add(0, TAB_UPDATES, 1, R.string.tab_updates).setIcon(R.drawable.ic_updates_outline);
        navMenu.add(0, TAB_CALLS, 2, R.string.tab_calls).setIcon(R.drawable.ic_calls_outline);

        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == TAB_CHATS) {
                binding.viewPager.setCurrentItem(0, true);
                updateNavIcons(0);
                return true;
            } else if (id == TAB_UPDATES) {
                binding.viewPager.setCurrentItem(1, true);
                updateNavIcons(1);
                return true;
            } else if (id == TAB_CALLS) {
                binding.viewPager.setCurrentItem(2, true);
                updateNavIcons(2);
                return true;
            }
            return false;
        });

        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                int targetId = position == 1 ? TAB_UPDATES : (position == 2 ? TAB_CALLS : TAB_CHATS);
                binding.bottomNav.setSelectedItemId(targetId);
                updateNavIcons(position);
            }
        });
    }

    private void updateNavIcons(int position) {
        Menu m = binding.bottomNav.getMenu();
        m.findItem(TAB_CHATS).setIcon(position == 0 ? R.drawable.ic_chat_filled : R.drawable.ic_chat_outline);
        m.findItem(TAB_UPDATES).setIcon(position == 1 ? R.drawable.ic_updates_filled : R.drawable.ic_updates_outline);
        m.findItem(TAB_CALLS).setIcon(position == 2 ? R.drawable.ic_calls_filled : R.drawable.ic_calls_outline);
    }

    private void setupSearchToolbar() {
        binding.searchToolbar.btnSearchBack.setOnClickListener(v -> closeSearch());
        binding.searchToolbar.btnClearSearch.setOnClickListener(v ->
                binding.searchToolbar.etSearch.setText(""));
        binding.searchToolbar.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s != null ? s.toString().trim() : "";
                binding.searchToolbar.btnClearSearch.setVisibility(q.isEmpty() ? View.GONE : View.VISIBLE);
                if (chatsFragment != null) chatsFragment.setSearchQuery(q);
                if (callsFragment != null) callsFragment.setSearchQuery(q);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void openSearch() {
        binding.toolbar.setVisibility(View.GONE);
        binding.searchToolbar.getRoot().setVisibility(View.VISIBLE);
        binding.searchToolbar.etSearch.requestFocus();
    }

    private void closeSearch() {
        binding.searchToolbar.etSearch.setText("");
        binding.searchToolbar.getRoot().setVisibility(View.GONE);
        binding.toolbar.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            openSearch();
            return true;
        } else if (id == R.id.action_camera) {
            startActivity(new Intent(this, StatusComposerActivity.class));
            return true;
        } else if (id == R.id.action_new_group) {
            startActivity(new Intent(this, CreateGroupActivity.class));
            return true;
        } else if (id == R.id.action_add_friend) {
            showAddFriendDialog();
            return true;
        } else if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAddFriendDialog() {
        EditText input = new EditText(this);
        input.setHint("Enter friend email");
        input.setTextColor(ContextCompat.getColor(this, R.color.aimo_text_primary));
        input.setHintTextColor(ContextCompat.getColor(this, R.color.aimo_text_secondary));
        int pad = getResources().getDimensionPixelSize(R.dimen.spacing_lg);
        input.setPadding(pad, pad, pad, pad);

        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_add_friend)
                .setView(input)
                .setPositiveButton(R.string.action_done, (dialog, which) -> {
                    String email = input.getText().toString().trim();
                    if (!email.isEmpty()) {
                        findFriendByEmail(email);
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void findFriendByEmail(String email) {
        FirestorePaths.usersCol().whereEqualTo("email", email).limit(1).get()
                .addOnSuccessListener(query -> {
                    if (query.isEmpty()) {
                        Toast.makeText(this, "No Aimo user found with this email", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    DocumentSnapshot doc = query.getDocuments().get(0);
                    UserModel friend = doc.toObject(UserModel.class);
                    if (friend != null) {
                        AppDatabase.dbExecutor.execute(() ->
                                AppDatabase.getInstance(this).userDao().insert(UserEntity.fromModel(friend)));
                        Toast.makeText(this, friend.name + " added to chats", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to search user", Toast.LENGTH_SHORT).show());
    }

    private void startBackgroundService() {
        Intent serviceIntent = new Intent(this, WhatsAppBgService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    private void listenForIncomingCalls(String myUid) {
        incomingCallListener = FirestorePaths.callsCol()
                .whereEqualTo("receiverId", myUid)
                .whereEqualTo("status", Constants.CALL_STATE_RINGING)
                .addSnapshotListener((snapshots, error) -> {
                    if (snapshots == null || snapshots.isEmpty()) return;
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        CallLogModel call = doc.toObject(CallLogModel.class);
                        if (call != null) {
                            Intent intent = new Intent(this, IncomingCallActivity.class);
                            intent.putExtra(Constants.EXTRA_CALL_ID, call.callId);
                            intent.putExtra(Constants.EXTRA_PEER_UID, call.callerId);
                            intent.putExtra(Constants.EXTRA_PEER_NAME, call.callerName);
                            intent.putExtra(Constants.EXTRA_PEER_PHOTO, call.callerPhoto);
                            intent.putExtra(Constants.EXTRA_IS_VIDEO, call.isVideo);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(intent);
                            break;
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (incomingCallListener != null) {
            incomingCallListener.remove();
        }
    }
}
