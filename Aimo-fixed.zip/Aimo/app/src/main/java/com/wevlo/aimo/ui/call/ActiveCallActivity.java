package com.wevlo.aimo.ui.call;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.CallLogModel;
import com.wevlo.aimo.databinding.ActivityActiveCallBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.CallLogEntity;
import com.wevlo.aimo.service.ActiveCallService;
import com.wevlo.aimo.service.ScreenShareService;
import com.wevlo.aimo.ui.call.bottomsheet.AudioOutputSheet;
import com.wevlo.aimo.ui.call.bottomsheet.RemoteScreenRequestSheet;
import com.wevlo.aimo.ui.call.view.CallControlsView;
import com.wevlo.aimo.ui.call.webrtc.WebRTCManager;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;
import com.wevlo.aimo.utils.PermissionHelper;

import org.webrtc.VideoTrack;

import java.util.UUID;

public class ActiveCallActivity extends AppCompatActivity {

    private ActivityActiveCallBinding binding;
    private WebRTCManager rtcManager;
    private AudioManager audioManager;

    private String callId = "";
    private String peerUid = "";
    private String peerName = "";
    private String peerPhoto = "";
    private boolean isVideo = false;
    private boolean isIncoming = false;
    private boolean isMuted = false;
    private boolean isConnected = false;
    private long elapsedSec = 0L;

    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            elapsedSec++;
            binding.tvCallStatus.setText(DateUtils.formatDuration(elapsedSec));
            timerHandler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityActiveCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        callId = getIntent().getStringExtra(Constants.EXTRA_CALL_ID);
        peerUid = getIntent().getStringExtra(Constants.EXTRA_PEER_UID);
        peerName = getIntent().getStringExtra(Constants.EXTRA_PEER_NAME);
        peerPhoto = getIntent().getStringExtra(Constants.EXTRA_PEER_PHOTO);
        isVideo = getIntent().getBooleanExtra(Constants.EXTRA_IS_VIDEO, false);
        isIncoming = getIntent().getBooleanExtra(Constants.EXTRA_IS_INCOMING, false);

        if (callId == null || callId.isEmpty()) callId = UUID.randomUUID().toString();
        if (peerUid == null) peerUid = "";
        if (peerName == null) peerName = "User";

        setupUi();
        if (PermissionHelper.hasCallPermissions(this, isVideo)) {
            startCallSession();
        } else {
            PermissionHelper.requestCallPermissions(this, isVideo);
        }
    }

    private void setupUi() {
        binding.tvPeerName.setText(peerName);
        binding.tvCallStatus.setText(isIncoming ? R.string.call_connecting : R.string.call_calling);
        Base64ImageUtils.loadAvatar(binding.ivPeerAvatar, "avatar_" + peerUid,
                peerPhoto, "", R.drawable.ic_attachment_contact);

        binding.remoteVideoView.setVisibility(isVideo ? View.VISIBLE : View.GONE);
        binding.pipView.setVisibility(isVideo ? View.VISIBLE : View.GONE);
        binding.ivPeerAvatar.setVisibility(isVideo ? View.GONE : View.VISIBLE);

        binding.callControls.setVideoMode(isVideo);
        binding.callControls.setListener(new CallControlsView.Listener() {
            @Override
            public void onToggleMute() {
                isMuted = !isMuted;
                binding.callControls.setMuted(isMuted);
                if (rtcManager != null) rtcManager.setMicEnabled(!isMuted);
            }

            @Override
            public void onAudioRouteClicked() {
                AudioOutputSheet sheet = new AudioOutputSheet();
                sheet.setListener(route -> applyAudioRoute(route));
                sheet.show(getSupportFragmentManager(), "audio_route");
            }

            @Override
            public void onSwitchCameraClicked() {
                if (rtcManager != null) rtcManager.switchCamera();
            }

            @Override
            public void onScreenShareClicked() {
                RemoteScreenRequestSheet sheet = new RemoteScreenRequestSheet();
                sheet.setListener(() -> {
                    Intent ss = new Intent(ActiveCallActivity.this, ScreenShareService.class);
                    ContextCompat.startForegroundService(ActiveCallActivity.this, ss);
                    Toast.makeText(ActiveCallActivity.this, "Screen sharing active", Toast.LENGTH_SHORT).show();
                });
                sheet.show(getSupportFragmentManager(), "screen_share");
            }

            @Override
            public void onEndCallClicked() {
                endCallAndFinish();
            }
        });
    }

    private void startCallSession() {
        Intent serviceIntent = new Intent(this, ActiveCallService.class);
        serviceIntent.putExtra(Constants.EXTRA_PEER_NAME, peerName);
        ContextCompat.startForegroundService(this, serviceIntent);

        rtcManager = new WebRTCManager(this, callId, !isIncoming, new WebRTCManager.CallEvents() {
            @Override
            public void onRemoteVideoAvailable(VideoTrack track) {
                runOnUiThread(() -> {
                    if (isVideo) {
                        track.addSink(binding.remoteVideoView);
                    }
                });
            }

            @Override
            public void onCallConnected() {
                runOnUiThread(() -> {
                    if (!isConnected) {
                        isConnected = true;
                        timerHandler.post(timerRunnable);
                    }
                });
            }

            @Override
            public void onCallEnded() {
                runOnUiThread(() -> finishCallLocally());
            }
        });

        if (isVideo) {
            binding.remoteVideoView.init(rtcManager.getEglContext(), null);
            binding.pipView.getSurfaceRenderer().init(rtcManager.getEglContext(), null);
            binding.pipView.getSurfaceRenderer().setMirror(true);
            binding.pipView.getSurfaceRenderer().setZOrderMediaOverlay(true);
        }

        CallLogModel outgoingModel = null;
        if (!isIncoming) {
            String myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
            SharedPreferences prefs = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
            String myName = prefs.getString(Constants.PREF_CURRENT_NAME, "Me");
            outgoingModel = new CallLogModel(callId, myUid, myName, peerUid, peerName, isVideo);
            outgoingModel.receiverPhoto = peerPhoto != null ? peerPhoto : "";
        }

        rtcManager.start(isVideo, isVideo ? binding.pipView.getSurfaceRenderer() : null, outgoingModel);
    }

    private void applyAudioRoute(String route) {
        if (audioManager == null) return;
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        audioManager.setSpeakerphoneOn("SPEAKER".equals(route));
    }

    private void endCallAndFinish() {
        String finalStatus = isConnected ? Constants.CALL_STATE_ENDED : Constants.CALL_STATE_MISSED;
        if (rtcManager != null) {
            rtcManager.endCall(finalStatus, elapsedSec);
            rtcManager = null;
        }
        saveLocalLog(finalStatus);
        finishCallLocally();
    }

    private void saveLocalLog(String status) {
        CallLogEntity entity = new CallLogEntity();
        entity.callId = callId;
        entity.peerId = peerUid;
        entity.peerName = peerName;
        entity.peerPhoto = peerPhoto != null ? peerPhoto : "";
        entity.isVideo = isVideo;
        entity.direction = isIncoming ? Constants.CALL_DIR_INCOMING : Constants.CALL_DIR_OUTGOING;
        entity.status = status;
        entity.startedAt = System.currentTimeMillis();
        entity.durationSec = elapsedSec;
        AppDatabase.dbExecutor.execute(() ->
                AppDatabase.getInstance(this).callLogDao().insert(entity));
    }

    private void finishCallLocally() {
        timerHandler.removeCallbacks(timerRunnable);
        stopService(new Intent(this, ActiveCallService.class));
        stopService(new Intent(this, ScreenShareService.class));
        if (!isFinishing()) finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQ_CALL_PERMISSIONS) {
            if (PermissionHelper.hasCallPermissions(this, isVideo)) {
                startCallSession();
            } else {
                Toast.makeText(this, "Call permissions denied", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacks(timerRunnable);
        if (rtcManager != null) {
            rtcManager.release();
            rtcManager = null;
        }
        if (isVideo) {
            binding.remoteVideoView.release();
            binding.pipView.getSurfaceRenderer().release();
        }
        stopService(new Intent(this, ActiveCallService.class));
    }
}
