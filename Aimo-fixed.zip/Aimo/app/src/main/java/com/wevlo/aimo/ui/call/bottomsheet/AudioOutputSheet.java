package com.wevlo.aimo.ui.call.bottomsheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.databinding.SheetAudioOutputBinding;

public class AudioOutputSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onAudioOutputSelected(String route);
    }

    private SheetAudioOutputBinding binding;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetAudioOutputBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.rowSpeaker.setOnClickListener(v -> select("SPEAKER"));
        binding.rowEarpiece.setOnClickListener(v -> select("EARPIECE"));
        binding.rowBluetooth.setOnClickListener(v -> select("BLUETOOTH"));
        binding.rowHeadset.setOnClickListener(v -> select("HEADSET"));
    }

    private void select(String route) {
        if (listener != null) listener.onAudioOutputSelected(route);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
