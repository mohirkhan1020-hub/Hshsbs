package com.wevlo.aimo.service;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.notification.NotificationHelper;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.Map;

public class AimoFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE)
                .edit()
                .putString(Constants.PREF_FCM_TOKEN, token)
                .apply();

        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid != null) {
            FirestorePaths.userDoc(myUid).update("fcmToken", token);
        }
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);
        Map<String, String> data = message.getData();
        if (data.isEmpty()) return;

        String kind = data.get("kind");
        if ("call".equals(kind)) {
            String callId = data.get("callId");
            String callerId = data.get("callerId");
            String callerName = data.get("callerName");
            boolean isVideo = Boolean.parseBoolean(data.get("isVideo"));
            NotificationHelper.showIncomingCallNotification(
                    this, callId, callerId, callerName, isVideo);
        } else {
            String chatId = data.get("chatId");
            String senderId = data.get("senderId");
            String senderName = data.get("senderName");
            String text = data.get("text");
            boolean isGroup = Boolean.parseBoolean(data.get("isGroup"));
            NotificationHelper.showMessageNotification(
                    this, chatId, senderId, senderName, text, isGroup);
        }
    }
}
