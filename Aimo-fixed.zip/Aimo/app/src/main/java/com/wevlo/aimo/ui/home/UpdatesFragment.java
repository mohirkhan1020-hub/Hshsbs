package com.wevlo.aimo.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.StatusModel;
import com.wevlo.aimo.databinding.FragmentUpdatesBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.StatusEntity;
import com.wevlo.aimo.ui.home.adapter.StatusAdapter;
import com.wevlo.aimo.ui.status.StatusComposerActivity;
import com.wevlo.aimo.ui.status.StatusViewerActivity;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class UpdatesFragment extends Fragment {

    private FragmentUpdatesBinding binding;
    private StatusAdapter adapter;
    private ListenerRegistration statusListener;
    private boolean hasMyStatus = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentUpdatesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new StatusAdapter(summary -> {
            Intent intent = new Intent(requireContext(), StatusViewerActivity.class);
            intent.putExtra(Constants.EXTRA_STATUS_USER_ID, summary.userId);
            startActivity(intent);
        });

        binding.rvStatuses.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvStatuses.setAdapter(adapter);

        binding.layoutMyStatus.setOnClickListener(v -> {
            String myUid = FirebaseAuth.getInstance().getUid();
            if (hasMyStatus && myUid != null) {
                Intent intent = new Intent(requireContext(), StatusViewerActivity.class);
                intent.putExtra(Constants.EXTRA_STATUS_USER_ID, myUid);
                startActivity(intent);
            } else {
                startActivity(new Intent(requireContext(), StatusComposerActivity.class));
            }
        });

        binding.fabCameraStatus.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), StatusComposerActivity.class)));

        observeStatuses();
        syncStatuses();
    }

    private void observeStatuses() {
        String myUid = FirebaseAuth.getInstance().getUid();
        long now = System.currentTimeMillis();
        AppDatabase.getInstance(requireContext()).statusDao()
                .observeActiveStatuses(now)
                .observe(getViewLifecycleOwner(), statuses -> {
                    if (statuses == null || binding == null) return;
                    hasMyStatus = false;
                    Map<String, StatusAdapter.StatusSummary> grouped = new LinkedHashMap<>();

                    for (StatusEntity s : statuses) {
                        if (myUid != null && myUid.equals(s.userId)) {
                            hasMyStatus = true;
                            continue;
                        }
                        StatusAdapter.StatusSummary summary = grouped.get(s.userId);
                        if (summary == null) {
                            summary = new StatusAdapter.StatusSummary();
                            summary.userId = s.userId;
                            summary.userName = s.userName;
                            summary.userPhoto = s.userPhoto;
                            summary.latestTimestamp = s.timestamp;
                            summary.count = 1;
                            summary.seen = myUid != null && s.viewers != null && s.viewers.contains(myUid);
                            grouped.put(s.userId, summary);
                        } else {
                            summary.count++;
                            if (s.timestamp > summary.latestTimestamp) {
                                summary.latestTimestamp = s.timestamp;
                            }
                            if (myUid != null && (s.viewers == null || !s.viewers.contains(myUid))) {
                                summary.seen = false;
                            }
                        }
                    }

                    binding.tvMyStatusSubtitle.setText(hasMyStatus
                            ? "Tap to view your status"
                            : getString(R.string.status_tap_to_add));
                    List<StatusAdapter.StatusSummary> items = new ArrayList<>(grouped.values());
                    adapter.submitList(items);
                    binding.tvEmptyStatuses.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                });
    }

    private void syncStatuses() {
        long now = System.currentTimeMillis();
        statusListener = FirestorePaths.statusesCol()
                .whereGreaterThan("expiresAt", now)
                .addSnapshotListener((snapshots, error) -> {
                    if (snapshots == null || getContext() == null) return;
                    List<StatusEntity> entities = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        StatusModel model = doc.toObject(StatusModel.class);
                        if (model != null) {
                            entities.add(StatusEntity.fromModel(model));
                        }
                    }
                    AppDatabase db = AppDatabase.getInstance(requireContext().getApplicationContext());
                    AppDatabase.dbExecutor.execute(() -> {
                        db.statusDao().deleteExpired(System.currentTimeMillis());
                        db.statusDao().insertAll(entities);
                    });
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (statusListener != null) statusListener.remove();
        binding = null;
    }
}
