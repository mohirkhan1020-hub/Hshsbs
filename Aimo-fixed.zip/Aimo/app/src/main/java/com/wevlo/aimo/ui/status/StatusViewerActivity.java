package com.wevlo.aimo.ui.status;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.MessageModel;
import com.wevlo.aimo.databinding.ActivityStatusViewerBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.db.entity.StatusEntity;
import com.wevlo.aimo.ui.status.adapter.StatusStoryAdapter;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;
import com.wevlo.aimo.utils.FirestorePaths;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StatusViewerActivity extends AppCompatActivity {

    private ActivityStatusViewerBinding binding;
    private StatusStoryAdapter adapter;
    private final List<StatusEntity> stories = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean paused = false;
    private int progress = 0;
    private String targetUserId = "", myUid = "", myName = "Me";

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!paused && !stories.isEmpty()) {
                progress += 2;
                binding.progressStory.setProgress(progress);
                if (progress >= 100) {
                    int current = binding.viewPagerStories.getCurrentItem();
                    if (current + 1 < stories.size()) {
                        progress = 0;
                        binding.viewPagerStories.setCurrentItem(current + 1, true);
                    } else {
                        finish();
                        return;
                    }
                }
            }
            handler.postDelayed(this, 100);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStatusViewerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
        myName = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).getString(Constants.PREF_CURRENT_NAME, "Me");
        targetUserId = getIntent().getStringExtra(Constants.EXTRA_STATUS_USER_ID);
        if (targetUserId == null) targetUserId = "";

        adapter = new StatusStoryAdapter();
        binding.viewPagerStories.setAdapter(adapter);
        binding.viewPagerStories.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                progress = 0;
                binding.progressStory.setProgress(0);
                updateHeader(position);
            }
        });

        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnPause.setOnClickListener(v -> {
            paused = !paused;
            binding.btnPause.setImageResource(paused ? R.drawable.ic_play : R.drawable.ic_story_pause);
        });
        binding.layoutReplyBar.setVisibility(myUid.equals(targetUserId) ? View.GONE : View.VISIBLE);
        binding.btnSendReply.setOnClickListener(v -> sendStoryReply());

        loadStories();
    }

    private void loadStories() {
        long now = System.currentTimeMillis();
        AppDatabase.dbExecutor.execute(() -> {
            List<StatusEntity> list = AppDatabase.getInstance(this).statusDao().getStatusesByUser(targetUserId, now);
            runOnUiThread(() -> {
                stories.clear();
                if (list != null) stories.addAll(list);
                if (stories.isEmpty()) {
                    Toast.makeText(this, "No active status", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                adapter.submitList(stories);
                updateHeader(0);
                handler.post(tickRunnable);
            });
        });
    }

    private void updateHeader(int position) {
        if (position < 0 || position >= stories.size()) return;
        StatusEntity current = stories.get(position);
        binding.tvUserName.setText(current.userName);
        binding.tvTime.setText(DateUtils.formatChatTime(current.timestamp));
        Base64ImageUtils.loadAvatar(binding.ivUserAvatar, "avatar_" + current.userId,
                current.userPhoto, "", R.drawable.ic_attachment_contact);
        if (!myUid.isEmpty() && !myUid.equals(current.userId)) {
            FirestorePaths.statusesCol().document(current.statusId)
                    .update("viewers", FieldValue.arrayUnion(myUid));
        }
    }

    private void sendStoryReply() {
        String text = binding.etStoryReply.getText() != null
                ? binding.etStoryReply.getText().toString().trim() : "";
        if (text.isEmpty() || stories.isEmpty()) return;

        StatusEntity current = stories.get(binding.viewPagerStories.getCurrentItem());
        String chatId = FirestorePaths.getDirectChatId(myUid, current.userId);
        String msgId = UUID.randomUUID().toString();
        MessageModel replyMsg = new MessageModel(msgId, chatId, myUid, myName, current.userId, Constants.MSG_TEXT, text);
        replyMsg.replyToId = current.statusId;
        replyMsg.replyToSender = current.userName + " (Status)";
        replyMsg.replyToText = !current.text.isEmpty() ? current.text : "Photo status";
        replyMsg.status = Constants.STATUS_SENT;

        AppDatabase.dbExecutor.execute(() ->
                AppDatabase.getInstance(this).messageDao().insert(MessageEntity.fromModel(replyMsg)));
        FirestorePaths.messageDoc(chatId, msgId).set(replyMsg);
        binding.etStoryReply.setText("");
        Toast.makeText(this, "Reply sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(tickRunnable);
    }
}
