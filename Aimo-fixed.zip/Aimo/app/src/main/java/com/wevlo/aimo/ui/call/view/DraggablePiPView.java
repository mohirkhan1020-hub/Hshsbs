package com.wevlo.aimo.ui.call.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.wevlo.aimo.R;

import org.webrtc.SurfaceViewRenderer;

public class DraggablePiPView extends FrameLayout {

    private final SurfaceViewRenderer surfaceRenderer;
    private float dX;
    private float dY;

    public DraggablePiPView(@NonNull Context context) {
        this(context, null);
    }

    public DraggablePiPView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DraggablePiPView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.view_draggable_pip, this, true);
        surfaceRenderer = findViewById(R.id.localSurfaceView);
    }

    public SurfaceViewRenderer getSurfaceRenderer() {
        return surfaceRenderer;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        ViewGroup parent = (ViewGroup) getParent();
        if (parent == null) return super.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dX = getX() - event.getRawX();
                dY = getY() - event.getRawY();
                return true;

            case MotionEvent.ACTION_MOVE:
                float newX = Math.max(0f, Math.min(event.getRawX() + dX, parent.getWidth() - getWidth()));
                float newY = Math.max(0f, Math.min(event.getRawY() + dY, parent.getHeight() - getHeight()));
                setX(newX);
                setY(newY);
                return true;
        }
        return super.onTouchEvent(event);
    }
}
