package com.wevlo.aimo.notification;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.ui.call.ActiveCallActivity;
import com.wevlo.aimo.ui.call.IncomingCallActivity;

public final class CallNotificationBuilder {

    private CallNotificationBuilder() {
    }

    public static Notification buildActiveCallNotification(Context context, String peerName) {
        Intent intent = new Intent(context, ActiveCallActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(context, Constants.CHANNEL_SERVICE)
                .setSmallIcon(R.drawable.ic_stat_aimo)
                .setContentTitle("Ongoing Aimo call")
                .setContentText(peerName != null && !peerName.isEmpty() ? peerName : "Connected")
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setContentIntent(pi)
                .build();
    }

    public static Notification buildIncomingCallNotification(Context context, String callId,
                                                             String peerUid, String peerName,
                                                             boolean isVideo) {
        Intent intent = new Intent(context, IncomingCallActivity.class);
        intent.putExtra(Constants.EXTRA_CALL_ID, callId);
        intent.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        intent.putExtra(Constants.EXTRA_PEER_NAME, peerName);
        intent.putExtra(Constants.EXTRA_IS_VIDEO, isVideo);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pi = PendingIntent.getActivity(
                context,
                1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(context, Constants.CHANNEL_CALLS)
                .setSmallIcon(R.drawable.ic_stat_aimo)
                .setContentTitle(peerName != null ? peerName : "Incoming call")
                .setContentText(isVideo ? "Incoming video call" : "Incoming voice call")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .build();
    }
}
