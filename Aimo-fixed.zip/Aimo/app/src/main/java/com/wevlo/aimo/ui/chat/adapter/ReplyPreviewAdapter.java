package com.wevlo.aimo.ui.chat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.R;
import com.wevlo.aimo.db.entity.MessageEntity;

import java.util.ArrayList;
import java.util.List;

public class ReplyPreviewAdapter extends RecyclerView.Adapter<ReplyPreviewAdapter.ViewHolder> {

    public interface Listener {
        void onReplyItemClicked(MessageEntity message);
    }

    private final List<MessageEntity> items = new ArrayList<>();
    private final Listener listener;

    public ReplyPreviewAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<MessageEntity> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MessageEntity item = items.get(position);
        holder.tvSender.setText(item.senderName);
        holder.tvSnippet.setText(item.text);
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onReplyItemClicked(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvSender;
        final TextView tvSnippet;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSender = itemView.findViewById(R.id.tvReactorUid);
            tvSnippet = itemView.findViewById(R.id.tvEmoji);
        }
    }
}
