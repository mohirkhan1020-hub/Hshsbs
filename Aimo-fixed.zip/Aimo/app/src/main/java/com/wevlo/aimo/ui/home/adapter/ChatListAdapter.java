package com.wevlo.aimo.ui.home.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ItemChatBinding;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {

    public static class ChatListItem {
        public String chatId = "";
        public String peerId = "";
        public String title = "";
        public String subtitle = "";
        public String photoBase64 = "";
        public long timestamp = 0L;
        public int unreadCount = 0;
        public boolean online = false;
        public boolean pinned = false;
        public boolean muted = false;
        public boolean isGroup = false;
    }

    public interface Listener {
        void onChatClicked(ChatListItem item);
        void onAvatarClicked(ChatListItem item);
    }

    private final List<ChatListItem> items = new ArrayList<>();
    private final Listener listener;

    public ChatListAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<ChatListItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemChatBinding binding = ItemChatBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatListItem item = items.get(position);
        holder.binding.tvTitle.setText(item.title);
        holder.binding.tvSubtitle.setText(item.subtitle);
        holder.binding.tvTime.setText(DateUtils.formatChatTime(item.timestamp));

        int placeholder = item.isGroup ? R.drawable.ic_group : R.drawable.ic_attachment_contact;
        Base64ImageUtils.loadAvatar(holder.binding.ivAvatar, "avatar_" + item.peerId,
                item.photoBase64, "", placeholder);

        holder.binding.vOnlineDot.setVisibility(!item.isGroup && item.online ? View.VISIBLE : View.GONE);
        holder.binding.ivPinned.setVisibility(item.pinned ? View.VISIBLE : View.GONE);
        holder.binding.ivMuted.setVisibility(item.muted ? View.VISIBLE : View.GONE);

        if (item.unreadCount > 0) {
            holder.binding.tvUnreadBadge.setVisibility(View.VISIBLE);
            holder.binding.tvUnreadBadge.setText(item.unreadCount > 99 ? "99+" : String.valueOf(item.unreadCount));
        } else {
            holder.binding.tvUnreadBadge.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onChatClicked(item);
        });
        holder.binding.ivAvatar.setOnClickListener(v -> {
            if (listener != null) listener.onAvatarClicked(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemChatBinding binding;

        ViewHolder(ItemChatBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
