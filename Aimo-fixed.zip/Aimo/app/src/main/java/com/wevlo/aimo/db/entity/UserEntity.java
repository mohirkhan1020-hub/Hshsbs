package com.wevlo.aimo.db.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.wevlo.aimo.data.UserModel;

@Entity(tableName = "users")
public class UserEntity {

    @PrimaryKey
    @NonNull
    public String uid = "";

    public String name = "";
    public String email = "";
    public String about = "";
    public String photoBase64 = "";
    public String photoUrl = "";
    public boolean online = false;
    public long lastSeen = 0L;
    public String typingTo = "";

    // Local Chat Summary Fields
    public String lastMessage = "";
    public String lastMessageSenderId = "";
    public long lastMessageTime = 0L;
    public int unreadCount = 0;
    public boolean pinned = false;
    public boolean muted = false;
    public boolean archived = false;

    public UserEntity() {
    }

    @Ignore
    public UserEntity(@NonNull String uid, String name, String email, String about) {
        this.uid = uid;
        this.name = name != null ? name : "";
        this.email = email != null ? email : "";
        this.about = about != null ? about : "";
    }

    @Ignore
    public static UserEntity fromModel(UserModel model) {
        UserEntity entity = new UserEntity();
        if (model == null) return entity;
        entity.uid = model.uid != null ? model.uid : "";
        entity.name = model.name != null ? model.name : "";
        entity.email = model.email != null ? model.email : "";
        entity.about = model.about != null ? model.about : "";
        entity.photoBase64 = model.photoBase64 != null ? model.photoBase64 : "";
        entity.photoUrl = model.photoUrl != null ? model.photoUrl : "";
        entity.online = model.online;
        entity.lastSeen = model.lastSeen;
        entity.typingTo = model.typingTo != null ? model.typingTo : "";
        return entity;
    }
}
