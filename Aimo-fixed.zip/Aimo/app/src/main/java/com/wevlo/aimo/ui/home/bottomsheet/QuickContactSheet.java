package com.wevlo.aimo.ui.home.bottomsheet;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.SheetQuickContactBinding;
import com.wevlo.aimo.ui.call.ActiveCallActivity;
import com.wevlo.aimo.ui.chat.ChatActivity;
import com.wevlo.aimo.ui.group.GroupInfoActivity;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;

public class QuickContactSheet extends BottomSheetDialogFragment {

    private static final String ARG_PEER_ID = "peer_id";
    private static final String ARG_TITLE = "title";
    private static final String ARG_PHOTO = "photo";
    private static final String ARG_IS_GROUP = "is_group";

    private SheetQuickContactBinding binding;

    public static QuickContactSheet newInstance(String peerId, String title, String photo, boolean isGroup) {
        QuickContactSheet sheet = new QuickContactSheet();
        Bundle args = new Bundle();
        args.putString(ARG_PEER_ID, peerId);
        args.putString(ARG_TITLE, title);
        args.putString(ARG_PHOTO, photo);
        args.putBoolean(ARG_IS_GROUP, isGroup);
        sheet.setArguments(args);
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetQuickContactBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        if (args == null) return;

        String peerId = args.getString(ARG_PEER_ID, "");
        String title = args.getString(ARG_TITLE, "");
        String photo = args.getString(ARG_PHOTO, "");
        boolean isGroup = args.getBoolean(ARG_IS_GROUP, false);

        binding.tvName.setText(title);
        int placeholder = isGroup ? R.drawable.ic_group : R.drawable.ic_attachment_contact;
        Base64ImageUtils.loadAvatar(binding.ivAvatar, "avatar_" + peerId, photo, "", placeholder);

        binding.btnVoiceCall.setVisibility(isGroup ? View.GONE : View.VISIBLE);
        binding.btnVideoCall.setVisibility(isGroup ? View.GONE : View.VISIBLE);

        binding.btnMessage.setOnClickListener(v -> {
            String myUid = FirebaseAuth.getInstance().getUid();
            String chatId = isGroup ? peerId : FirestorePaths.getDirectChatId(myUid, peerId);
            Intent intent = new Intent(requireContext(), ChatActivity.class);
            intent.putExtra(Constants.EXTRA_CHAT_ID, chatId);
            intent.putExtra(Constants.EXTRA_PEER_UID, peerId);
            intent.putExtra(Constants.EXTRA_PEER_NAME, title);
            intent.putExtra(Constants.EXTRA_PEER_PHOTO, photo);
            intent.putExtra(Constants.EXTRA_IS_GROUP, isGroup);
            startActivity(intent);
            dismiss();
        });

        binding.btnVoiceCall.setOnClickListener(v -> startCall(peerId, title, photo, false));
        binding.btnVideoCall.setOnClickListener(v -> startCall(peerId, title, photo, true));

        binding.btnInfo.setOnClickListener(v -> {
            if (isGroup) {
                Intent intent = new Intent(requireContext(), GroupInfoActivity.class);
                intent.putExtra(Constants.EXTRA_GROUP_ID, peerId);
                startActivity(intent);
            }
            dismiss();
        });
    }

    private void startCall(String peerId, String name, String photo, boolean isVideo) {
        Intent intent = new Intent(requireContext(), ActiveCallActivity.class);
        intent.putExtra(Constants.EXTRA_PEER_UID, peerId);
        intent.putExtra(Constants.EXTRA_PEER_NAME, name);
        intent.putExtra(Constants.EXTRA_PEER_PHOTO, photo);
        intent.putExtra(Constants.EXTRA_IS_VIDEO, isVideo);
        intent.putExtra(Constants.EXTRA_IS_INCOMING, false);
        startActivity(intent);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
