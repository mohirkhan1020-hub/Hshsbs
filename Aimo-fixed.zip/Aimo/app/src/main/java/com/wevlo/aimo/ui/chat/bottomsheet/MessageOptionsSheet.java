package com.wevlo.aimo.ui.chat.bottomsheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.SheetMessageOptionsBinding;

public class MessageOptionsSheet extends BottomSheetDialogFragment {

    private static final String ARG_IS_MINE = "is_mine";
    private static final String ARG_STARRED = "starred";

    public interface Listener {
        void onReactionSelected(String emoji);
        void onActionSelected(String action);
    }

    private SheetMessageOptionsBinding binding;
    private Listener listener;

    public static MessageOptionsSheet newInstance(boolean isMine, boolean isStarred) {
        MessageOptionsSheet sheet = new MessageOptionsSheet();
        Bundle args = new Bundle();
        args.putBoolean(ARG_IS_MINE, isMine);
        args.putBoolean(ARG_STARRED, isStarred);
        sheet.setArguments(args);
        return sheet;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetMessageOptionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        boolean isMine = getArguments() != null && getArguments().getBoolean(ARG_IS_MINE, false);
        boolean isStarred = getArguments() != null && getArguments().getBoolean(ARG_STARRED, false);

        String[] emojis = getResources().getStringArray(R.array.reactions);
        for (String emoji : emojis) {
            TextView tv = new TextView(requireContext());
            tv.setText(emoji);
            tv.setTextSize(26f);
            int pad = getResources().getDimensionPixelSize(R.dimen.spacing_sm);
            tv.setPadding(pad, pad, pad, pad);
            tv.setBackgroundResource(R.drawable.bg_ripple_circle);
            tv.setOnClickListener(v -> {
                if (listener != null) listener.onReactionSelected(emoji);
                dismiss();
            });
            binding.layoutReactionsBar.addView(tv);
        }

        binding.tvActionEdit.setVisibility(isMine ? View.VISIBLE : View.GONE);
        binding.tvActionDelete.setVisibility(isMine ? View.VISIBLE : View.GONE);
        binding.tvActionStar.setText(isStarred ? "Unstar" : getString(R.string.action_star));

        binding.tvActionReply.setOnClickListener(v -> emitAction("REPLY"));
        binding.tvActionCopy.setOnClickListener(v -> emitAction("COPY"));
        binding.tvActionEdit.setOnClickListener(v -> emitAction("EDIT"));
        binding.tvActionStar.setOnClickListener(v -> emitAction("STAR"));
        binding.tvActionDelete.setOnClickListener(v -> emitAction("DELETE"));
    }

    private void emitAction(String action) {
        if (listener != null) listener.onActionSelected(action);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
