package com.wevlo.aimo.utils;

import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.File;

public class AudioPlayerHelper {

    public interface Callback {
        void onProgress(int currentMs, int totalMs);
        void onCompleted();
    }

    private static volatile AudioPlayerHelper instance;
    private MediaPlayer player;
    private String currentKey = "";
    private Callback currentCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            if (player != null && player.isPlaying() && currentCallback != null) {
                currentCallback.onProgress(player.getCurrentPosition(), player.getDuration());
                handler.postDelayed(this, 100);
            }
        }
    };

    private AudioPlayerHelper() {
    }

    public static AudioPlayerHelper getInstance() {
        if (instance == null) {
            synchronized (AudioPlayerHelper.class) {
                if (instance == null) {
                    instance = new AudioPlayerHelper();
                }
            }
        }
        return instance;
    }

    public boolean isPlaying(String key) {
        return player != null && player.isPlaying() && key != null && key.equals(currentKey);
    }

    public void play(String key, File file, Callback callback) {
        stop();
        try {
            currentKey = key != null ? key : "";
            currentCallback = callback;
            player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                Callback cb = currentCallback;
                stop();
                if (cb != null) cb.onCompleted();
            });
            player.prepare();
            player.start();
            handler.post(progressRunnable);
        } catch (Exception e) {
            stop();
            if (callback != null) callback.onCompleted();
        }
    }

    public void stop() {
        handler.removeCallbacks(progressRunnable);
        currentKey = "";
        currentCallback = null;
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
                player.reset();
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }
}
