package com.wevlo.aimo.data;

import com.wevlo.aimo.Constants;

import java.util.ArrayList;
import java.util.List;

public class StatusModel {

    public String statusId = "";
    public String userId = "";
    public String userName = "";
    public String userPhoto = "";
    public String type = Constants.MSG_TEXT;
    public String text = "";
    public String mediaBase64 = "";
    public String mediaUrl = "";
    public String bgColor = "#005C4B";
    public long timestamp = 0L;
    public long expiresAt = 0L;
    public List<String> viewers = new ArrayList<>();

    public StatusModel() {
    }

    public StatusModel(String statusId, String userId, String userName, String type, String text) {
        this.statusId = statusId != null ? statusId : "";
        this.userId = userId != null ? userId : "";
        this.userName = userName != null ? userName : "";
        this.type = type != null ? type : Constants.MSG_TEXT;
        this.text = text != null ? text : "";
        this.timestamp = System.currentTimeMillis();
        this.expiresAt = this.timestamp + Constants.STATUS_TTL_MS;
    }
}
