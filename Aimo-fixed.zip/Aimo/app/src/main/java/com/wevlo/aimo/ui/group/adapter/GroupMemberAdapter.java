package com.wevlo.aimo.ui.group.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ItemChatBinding;
import com.wevlo.aimo.db.entity.UserEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GroupMemberAdapter extends RecyclerView.Adapter<GroupMemberAdapter.MemberVH> {

    private final boolean selectionMode;
    private final List<UserEntity> users = new ArrayList<>();
    private final Set<String> selectedIds = new HashSet<>();
    private final Set<String> adminIds = new HashSet<>();

    public GroupMemberAdapter(boolean selectionMode) {
        this.selectionMode = selectionMode;
    }

    public void submitUsers(List<UserEntity> list) {
        users.clear();
        if (list != null) users.addAll(list);
        notifyDataSetChanged();
    }

    public void setAdminIds(List<String> admins) {
        adminIds.clear();
        if (admins != null) adminIds.addAll(admins);
        notifyDataSetChanged();
    }

    public List<String> getSelectedIds() {
        return new ArrayList<>(selectedIds);
    }

    @NonNull
    @Override
    public MemberVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemChatBinding binding = ItemChatBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new MemberVH(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MemberVH holder, int position) {
        UserEntity user = users.get(position);
        holder.binding.tvTitle.setText(user.name);
        holder.binding.tvSubtitle.setText(user.about);
        Base64ImageUtils.loadAvatar(holder.binding.ivAvatar, "avatar_" + user.uid,
                user.photoBase64, user.photoUrl, R.drawable.ic_attachment_contact);

        if (selectionMode) {
            boolean selected = selectedIds.contains(user.uid);
            holder.binding.tvUnreadBadge.setVisibility(selected ? View.VISIBLE : View.GONE);
            holder.binding.tvUnreadBadge.setText("✓");
            holder.binding.tvTime.setText("");
            holder.itemView.setOnClickListener(v -> {
                if (selectedIds.contains(user.uid)) {
                    selectedIds.remove(user.uid);
                } else {
                    selectedIds.add(user.uid);
                }
                notifyItemChanged(holder.getBindingAdapterPosition());
            });
        } else {
            holder.binding.tvUnreadBadge.setVisibility(View.GONE);
            holder.binding.tvTime.setText(adminIds.contains(user.uid) ? "Admin" : "");
        }
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    static class MemberVH extends RecyclerView.ViewHolder {
        final ItemChatBinding binding;

        MemberVH(ItemChatBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
