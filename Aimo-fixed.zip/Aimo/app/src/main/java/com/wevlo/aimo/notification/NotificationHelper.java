package com.wevlo.aimo.notification;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.wevlo.aimo.Constants;

public final class NotificationHelper {

    private NotificationHelper() {
    }

    public static boolean canPostNotifications(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public static void showMessageNotification(Context context, String chatId, String peerUid,
                                               String senderName, String text, boolean isGroup) {
        if (!canPostNotifications(context)) return;
        Notification notification = MessageNotificationBuilder.build(
                context, chatId, peerUid, senderName, text, isGroup);
        int notifId = chatId != null ? Math.abs(chatId.hashCode()) : 2001;
        NotificationManagerCompat.from(context).notify(notifId, notification);
    }

    public static void showIncomingCallNotification(Context context, String callId, String peerUid,
                                                    String peerName, boolean isVideo) {
        if (!canPostNotifications(context)) return;
        Notification notification = CallNotificationBuilder.buildIncomingCallNotification(
                context, callId, peerUid, peerName, isVideo);
        NotificationManagerCompat.from(context).notify(Constants.NOTIF_ID_INCOMING_CALL, notification);
    }

    public static void cancel(Context context, int notifId) {
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.cancel(notifId);
        }
    }
}
