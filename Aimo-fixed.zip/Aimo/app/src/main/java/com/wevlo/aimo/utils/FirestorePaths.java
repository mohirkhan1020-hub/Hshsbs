package com.wevlo.aimo.utils;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.wevlo.aimo.Constants;

public final class FirestorePaths {

    private FirestorePaths() {
    }

    public static FirebaseFirestore db() {
        return FirebaseFirestore.getInstance();
    }

    public static String getDirectChatId(String uid1, String uid2) {
        if (uid1 == null) uid1 = "";
        if (uid2 == null) uid2 = "";
        return uid1.compareTo(uid2) < 0 ? uid1 + "_" + uid2 : uid2 + "_" + uid1;
    }

    public static CollectionReference usersCol() {
        return db().collection(Constants.COL_USERS);
    }

    public static DocumentReference userDoc(String uid) {
        return usersCol().document(uid);
    }

    public static CollectionReference chatMessagesCol(String chatId) {
        return db().collection(Constants.COL_CHATS).document(chatId).collection(Constants.COL_MESSAGES);
    }

    public static DocumentReference messageDoc(String chatId, String messageId) {
        return chatMessagesCol(chatId).document(messageId);
    }

    public static CollectionReference statusesCol() {
        return db().collection(Constants.COL_STATUS);
    }

    public static CollectionReference callsCol() {
        return db().collection(Constants.COL_CALLS);
    }

    public static DocumentReference callDoc(String callId) {
        return callsCol().document(callId);
    }

    public static CollectionReference groupsCol() {
        return db().collection(Constants.COL_GROUPS);
    }

    public static DocumentReference groupDoc(String groupId) {
        return groupsCol().document(groupId);
    }

    public static DocumentReference deviceBindingDoc(String uid) {
        return db().collection(Constants.COL_DEVICE_BINDINGS).document(uid);
    }

    public static DocumentReference appConfigDoc() {
        return db().collection(Constants.COL_APP_CONFIG).document("latest");
    }
}
