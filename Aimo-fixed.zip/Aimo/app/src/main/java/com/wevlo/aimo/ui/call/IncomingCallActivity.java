package com.wevlo.aimo.ui.call;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.ActivityIncomingCallBinding;
import com.wevlo.aimo.service.CallRingtoneService;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;

public class IncomingCallActivity extends AppCompatActivity {

    private ActivityIncomingCallBinding binding;
    private String callId = "";
    private String peerUid = "";
    private String peerName = "";
    private String peerPhoto = "";
    private boolean isVideo = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIncomingCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        callId = getIntent().getStringExtra(Constants.EXTRA_CALL_ID);
        peerUid = getIntent().getStringExtra(Constants.EXTRA_PEER_UID);
        peerName = getIntent().getStringExtra(Constants.EXTRA_PEER_NAME);
        peerPhoto = getIntent().getStringExtra(Constants.EXTRA_PEER_PHOTO);
        isVideo = getIntent().getBooleanExtra(Constants.EXTRA_IS_VIDEO, false);

        if (callId == null) callId = "";
        if (peerName == null) peerName = "Caller";

        binding.tvCallerName.setText(peerName);
        binding.tvCallType.setText(isVideo ? R.string.call_incoming_video : R.string.call_incoming_voice);
        Base64ImageUtils.loadAvatar(binding.ivCallerAvatar, "avatar_" + peerUid,
                peerPhoto, "", R.drawable.ic_attachment_contact);

        startService(new Intent(this, CallRingtoneService.class));

        binding.btnAccept.setOnClickListener(v -> acceptCall());
        binding.btnDecline.setOnClickListener(v -> declineCall());
    }

    private void acceptCall() {
        stopService(new Intent(this, CallRingtoneService.class));
        Intent intent = new Intent(this, ActiveCallActivity.class);
        intent.putExtra(Constants.EXTRA_CALL_ID, callId);
        intent.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        intent.putExtra(Constants.EXTRA_PEER_NAME, peerName);
        intent.putExtra(Constants.EXTRA_PEER_PHOTO, peerPhoto);
        intent.putExtra(Constants.EXTRA_IS_VIDEO, isVideo);
        intent.putExtra(Constants.EXTRA_IS_INCOMING, true);
        startActivity(intent);
        finish();
    }

    private void declineCall() {
        stopService(new Intent(this, CallRingtoneService.class));
        if (!callId.isEmpty()) {
            FirestorePaths.callDoc(callId).update("status", Constants.CALL_STATE_DECLINED);
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(new Intent(this, CallRingtoneService.class));
    }
}
