package com.wevlo.aimo.ui.chat;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.MessageModel;
import com.wevlo.aimo.data.UserModel;
import com.wevlo.aimo.databinding.ActivityChatBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.ui.call.ActiveCallActivity;
import com.wevlo.aimo.ui.chat.adapter.MessageAdapter;
import com.wevlo.aimo.ui.chat.bottomsheet.AttachmentSheet;
import com.wevlo.aimo.ui.chat.bottomsheet.MessageOptionsSheet;
import com.wevlo.aimo.ui.chat.bottomsheet.ReactionDetailsSheet;
import com.wevlo.aimo.ui.chat.bottomsheet.WallpaperPickerSheet;
import com.wevlo.aimo.ui.chat.view.VoiceRecordButton;
import com.wevlo.aimo.ui.group.GroupInfoActivity;
import com.wevlo.aimo.ui.media.MediaPreviewActivity;
import com.wevlo.aimo.utils.AudioRecorderHelper;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.DateUtils;
import com.wevlo.aimo.utils.FirestorePaths;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ChatActivity extends AppCompatActivity {

    private ActivityChatBinding binding;
    private MessageAdapter adapter;
    private LinearLayoutManager layoutManager;
    private String myUid = "", myName = "Me", chatId = "", peerUid = "", peerName = "", peerPhoto = "";
    private boolean isGroup = false;
    private MessageEntity replyingTo, editingMessage;
    private ListenerRegistration messagesListener, peerListener;
    private AudioRecorderHelper recorderHelper;

    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    Intent i = new Intent(this, MediaPreviewActivity.class);
                    i.putExtra(Constants.EXTRA_CHAT_ID, chatId);
                    i.putExtra(Constants.EXTRA_PEER_UID, peerUid);
                    i.putExtra(Constants.EXTRA_MEDIA_URI, uri.toString());
                    i.putExtra(Constants.EXTRA_IS_GROUP, isGroup);
                    startActivity(i);
                }
            });

    private final ActivityResultLauncher<String> docLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    String name = uri.getLastPathSegment() != null ? uri.getLastPathSegment() : "Document";
                    sendTypedMessage(Constants.MSG_DOCUMENT, name, "", name);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
        myName = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).getString(Constants.PREF_CURRENT_NAME, "Me");
        chatId = getIntent().getStringExtra(Constants.EXTRA_CHAT_ID);
        peerUid = getIntent().getStringExtra(Constants.EXTRA_PEER_UID);
        peerName = getIntent().getStringExtra(Constants.EXTRA_PEER_NAME);
        peerPhoto = getIntent().getStringExtra(Constants.EXTRA_PEER_PHOTO);
        isGroup = getIntent().getBooleanExtra(Constants.EXTRA_IS_GROUP, false);
        if (chatId == null) chatId = "";
        if (peerUid == null) peerUid = "";
        if (peerName == null) peerName = "Chat";

        recorderHelper = new AudioRecorderHelper(this);
        setupToolbar();
        setupRecycler();
        setupInputBar();
        applySavedWallpaper();
        observeMessages();
        listenRemoteMessages();
        listenPeerPresence();
        clearUnread();
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayShowTitleEnabled(false);
        binding.tvPeerName.setText(peerName);
        int ph = isGroup ? R.drawable.ic_group : R.drawable.ic_attachment_contact;
        Base64ImageUtils.loadAvatar(binding.ivPeerAvatar, "avatar_" + peerUid, peerPhoto, "", ph);
        binding.btnBack.setOnClickListener(v -> finish());
        binding.layoutPeerInfo.setOnClickListener(v -> {
            if (isGroup) {
                Intent i = new Intent(this, GroupInfoActivity.class);
                i.putExtra(Constants.EXTRA_GROUP_ID, peerUid);
                startActivity(i);
            }
        });
        binding.btnVoiceCall.setVisibility(isGroup ? View.GONE : View.VISIBLE);
        binding.btnVideoCall.setVisibility(isGroup ? View.GONE : View.VISIBLE);
        binding.btnVoiceCall.setOnClickListener(v -> startCall(false));
        binding.btnVideoCall.setOnClickListener(v -> startCall(true));
    }

    private void setupRecycler() {
        adapter = new MessageAdapter(myUid, new MessageAdapter.Listener() {
            @Override public void onMessageLongClicked(MessageEntity m) { showMessageOptions(m); }
            @Override public void onSwipeReply(MessageEntity m) { startReply(m); }
            @Override public void onReactionClicked(MessageEntity m) {
                ReactionDetailsSheet.newInstance(m.reactions).show(getSupportFragmentManager(), "reaction_details");
            }
            @Override public void onImageClicked(MessageEntity m) {
                Toast.makeText(ChatActivity.this, "Viewing image", Toast.LENGTH_SHORT).show();
            }
        });
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        binding.rvMessages.setLayoutManager(layoutManager);
        binding.rvMessages.setAdapter(adapter);
        binding.rvMessages.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                int last = layoutManager.findLastCompletelyVisibleItemPosition();
                int total = adapter.getItemCount();
                binding.fabScrollBottom.setVisibility(total > 0 && last < total - 3 ? View.VISIBLE : View.GONE);
            }
        });
        binding.fabScrollBottom.setOnClickListener(v -> {
            if (adapter.getItemCount() > 0) binding.rvMessages.smoothScrollToPosition(adapter.getItemCount() - 1);
        });
    }

    private void setupInputBar() {
        binding.etMessage.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean hasText = s != null && s.toString().trim().length() > 0;
                binding.btnSend.setVisibility(hasText ? View.VISIBLE : View.GONE);
                binding.btnVoiceRecord.setVisibility(hasText ? View.GONE : View.VISIBLE);
                if (!myUid.isEmpty()) FirestorePaths.userDoc(myUid).update("typingTo", hasText ? chatId : "");
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        binding.btnSend.setOnClickListener(v -> sendTextMessage());
        binding.btnAttach.setOnClickListener(v -> showAttachmentSheet());
        binding.btnCameraInput.setOnClickListener(v -> galleryLauncher.launch("image/*"));
        binding.btnCancelReply.setOnClickListener(v -> cancelReplyOrEdit());
        binding.btnVoiceRecord.setVoiceRecordListener(new VoiceRecordButton.VoiceRecordListener() {
            @Override public void onRecordStart() {
                binding.layoutVoiceRecording.setVisibility(View.VISIBLE);
                recorderHelper.startRecording();
            }
            @Override public void onRecordStop(boolean cancelled) {
                binding.layoutVoiceRecording.setVisibility(View.GONE);
                File recorded = recorderHelper.stopRecording();
                if (!cancelled && recorded != null && recorded.exists()) {
                    sendAudioFile(recorded, recorderHelper.getLastDurationMs());
                }
            }
        });
    }

    private void showAttachmentSheet() {
        AttachmentSheet sheet = new AttachmentSheet();
        sheet.setListener(type -> {
            if ("GALLERY".equals(type) || "CAMERA".equals(type)) galleryLauncher.launch("image/*");
            else if ("DOCUMENT".equals(type)) docLauncher.launch("*/*");
            else if ("AUDIO".equals(type)) docLauncher.launch("audio/*");
            else if ("LOCATION".equals(type)) sendTypedMessage(Constants.MSG_LOCATION, "Shared location", "", "");
            else if ("CONTACT".equals(type)) sendTypedMessage(Constants.MSG_CONTACT, myName, "", "");
        });
        sheet.show(getSupportFragmentManager(), "attachment_sheet");
    }

    private void sendTextMessage() {
        String text = binding.etMessage.getText() != null ? binding.etMessage.getText().toString().trim() : "";
        if (text.isEmpty()) return;
        if (editingMessage != null) {
            editingMessage.text = text;
            editingMessage.edited = true;
            MessageEntity target = editingMessage;
            AppDatabase.dbExecutor.execute(() -> AppDatabase.getInstance(this).messageDao().update(target));
            FirestorePaths.messageDoc(chatId, target.messageId).update("text", text, "edited", true);
            cancelReplyOrEdit();
            binding.etMessage.setText("");
            return;
        }
        binding.etMessage.setText("");
        sendTypedMessage(Constants.MSG_TEXT, text, "", "");
    }

    private void sendAudioFile(File file, long durationMs) {
        AppDatabase.dbExecutor.execute(() -> {
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] bytes = new byte[(int) file.length()];
                int read = fis.read(bytes);
                if (read > 0) {
                    MessageModel m = buildModel(Constants.MSG_AUDIO, "Voice message",
                            Base64.encodeToString(bytes, 0, read, Base64.NO_WRAP), file.getName());
                    m.durationMs = durationMs;
                    m.localPath = file.getAbsolutePath();
                    dispatchMessage(m);
                }
            } catch (Exception ignored) {}
        });
    }

    private void sendTypedMessage(String type, String text, String b64, String fileName) {
        dispatchMessage(buildModel(type, text, b64, fileName));
        cancelReplyOrEdit();
    }

    private MessageModel buildModel(String type, String text, String b64, String fileName) {
        MessageModel m = new MessageModel(UUID.randomUUID().toString(), chatId, myUid, myName, peerUid, type, text);
        m.mediaBase64 = b64 != null ? b64 : "";
        m.fileName = fileName != null ? fileName : "";
        m.status = Constants.STATUS_SENT;
        if (replyingTo != null) {
            m.replyToId = replyingTo.messageId;
            m.replyToSender = replyingTo.senderName;
            m.replyToText = replyingTo.text;
        }
        return m;
    }

    private void dispatchMessage(MessageModel m) {
        AppDatabase db = AppDatabase.getInstance(this);
        AppDatabase.dbExecutor.execute(() -> {
            db.messageDao().insert(MessageEntity.fromModel(m));
            if (isGroup) {
                FirestorePaths.groupDoc(chatId).update("lastMessage", m.text,
                        "lastMessageSender", myName, "lastMessageTime", m.timestamp);
            } else {
                db.userDao().updateChatSummary(peerUid, m.text, myUid, m.timestamp);
            }
        });
        FirestorePaths.messageDoc(chatId, m.messageId).set(m);
    }

    private void observeMessages() {
        AppDatabase.getInstance(this).messageDao().observeMessages(chatId).observe(this, list -> {
            if (list == null) return;
            adapter.submitList(list);
            if (!list.isEmpty()) binding.rvMessages.scrollToPosition(list.size() - 1);
        });
    }

    private void listenRemoteMessages() {
        messagesListener = FirestorePaths.chatMessagesCol(chatId).orderBy("timestamp")
                .addSnapshotListener((snapshots, error) -> {
                    if (snapshots == null) return;
                    List<MessageEntity> list = new ArrayList<>();
                    MessageModel latest = null;
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        MessageModel m = doc.toObject(MessageModel.class);
                        if (m != null) {
                            if (!myUid.equals(m.senderId) && m.status < Constants.STATUS_READ) {
                                m.status = Constants.STATUS_READ;
                                FirestorePaths.messageDoc(chatId, m.messageId).update("status", Constants.STATUS_READ);
                            }
                            list.add(MessageEntity.fromModel(m));
                            latest = m;
                        }
                    }
                    MessageModel finalLatest = latest;
                    AppDatabase db = AppDatabase.getInstance(this);
                    AppDatabase.dbExecutor.execute(() -> {
                        db.messageDao().insertAll(list);
                        if (!isGroup && finalLatest != null) {
                            db.userDao().updateChatSummary(peerUid, finalLatest.text, finalLatest.senderId, finalLatest.timestamp);
                        }
                    });
                });
    }

    private void listenPeerPresence() {
        if (isGroup || peerUid.isEmpty()) {
            binding.tvPeerStatus.setText("Tap for group info");
            return;
        }
        peerListener = FirestorePaths.userDoc(peerUid).addSnapshotListener((snap, e) -> {
            if (snap == null || !snap.exists()) return;
            UserModel peer = snap.toObject(UserModel.class);
            if (peer == null) return;
            if (chatId.equals(peer.typingTo)) binding.tvPeerStatus.setText(R.string.status_typing);
            else if (peer.online) binding.tvPeerStatus.setText(R.string.status_online);
            else binding.tvPeerStatus.setText(DateUtils.formatLastSeen(peer.lastSeen));
        });
    }

    private void clearUnread() {
        AppDatabase db = AppDatabase.getInstance(this);
        AppDatabase.dbExecutor.execute(() -> {
            if (isGroup) db.groupDao().clearUnread(chatId);
            else {
                db.userDao().clearUnread(peerUid);
                db.messageDao().markChatRead(chatId, myUid);
            }
        });
    }

    private void startReply(MessageEntity m) {
        replyingTo = m;
        editingMessage = null;
        binding.layoutReplyPreview.setVisibility(View.VISIBLE);
        binding.tvReplySender.setText(myUid.equals(m.senderId) ? "You" : m.senderName);
        binding.tvReplyText.setText(m.text);
    }

    private void cancelReplyOrEdit() {
        replyingTo = null;
        editingMessage = null;
        binding.layoutReplyPreview.setVisibility(View.GONE);
    }

    private void showMessageOptions(MessageEntity m) {
        MessageOptionsSheet sheet = MessageOptionsSheet.newInstance(myUid.equals(m.senderId), m.starred);
        sheet.setListener(new MessageOptionsSheet.Listener() {
            @Override public void onReactionSelected(String emoji) {
                Map<String, String> updated = new HashMap<>(m.reactions);
                updated.put(myUid, emoji);
                m.reactions = updated;
                AppDatabase.dbExecutor.execute(() -> AppDatabase.getInstance(ChatActivity.this).messageDao().update(m));
                FirestorePaths.messageDoc(chatId, m.messageId).update("reactions", updated);
            }
            @Override public void onActionSelected(String action) {
                if ("REPLY".equals(action)) startReply(m);
                else if ("COPY".equals(action)) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Aimo", m.text));
                } else if ("EDIT".equals(action)) {
                    editingMessage = m;
                    binding.layoutReplyPreview.setVisibility(View.VISIBLE);
                    binding.tvReplySender.setText("Editing message");
                    binding.tvReplyText.setText(m.text);
                    binding.etMessage.setText(m.text);
                } else if ("STAR".equals(action)) {
                    boolean next = !m.starred;
                    AppDatabase.dbExecutor.execute(() -> AppDatabase.getInstance(ChatActivity.this).messageDao().setStarred(m.messageId, next));
                    FirestorePaths.messageDoc(chatId, m.messageId).update("starred", next);
                } else if ("DELETE".equals(action)) {
                    AppDatabase.dbExecutor.execute(() -> AppDatabase.getInstance(ChatActivity.this).messageDao().markDeleted(m.messageId));
                    FirestorePaths.messageDoc(chatId, m.messageId).update("deleted", true, "text", "This message was deleted", "mediaBase64", "");
                }
            }
        });
        sheet.show(getSupportFragmentManager(), "message_options");
    }

    private void startCall(boolean isVideo) {
        Intent i = new Intent(this, ActiveCallActivity.class);
        i.putExtra(Constants.EXTRA_PEER_UID, peerUid);
        i.putExtra(Constants.EXTRA_PEER_NAME, peerName);
        i.putExtra(Constants.EXTRA_PEER_PHOTO, peerPhoto);
        i.putExtra(Constants.EXTRA_IS_VIDEO, isVideo);
        i.putExtra(Constants.EXTRA_IS_INCOMING, false);
        startActivity(i);
    }

    private void applySavedWallpaper() {
        String hex = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).getString(Constants.PREF_WALLPAPER_COLOR, "#0B141A");
        try { binding.rootChatContainer.setBackgroundColor(Color.parseColor(hex)); } catch (Exception ignored) {}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_chat, menu);
        menu.findItem(R.id.action_group_info).setVisible(isGroup);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_wallpaper) {
            WallpaperPickerSheet sheet = new WallpaperPickerSheet();
            sheet.setListener(hex -> {
                getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).edit().putString(Constants.PREF_WALLPAPER_COLOR, hex).apply();
                applySavedWallpaper();
            });
            sheet.show(getSupportFragmentManager(), "wallpaper_picker");
            return true;
        } else if (id == R.id.action_clear_chat) {
            new AlertDialog.Builder(this).setTitle("Clear chat?")
                    .setPositiveButton("Clear", (d, w) -> AppDatabase.dbExecutor.execute(() ->
                            AppDatabase.getInstance(this).messageDao().deleteChatMessages(chatId)))
                    .setNegativeButton(R.string.action_cancel, null).show();
            return true;
        } else if (id == R.id.action_group_info && isGroup) {
            Intent i = new Intent(this, GroupInfoActivity.class);
            i.putExtra(Constants.EXTRA_GROUP_ID, peerUid);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!myUid.isEmpty()) FirestorePaths.userDoc(myUid).update("typingTo", "");
        if (messagesListener != null) messagesListener.remove();
        if (peerListener != null) peerListener.remove();
    }
}
