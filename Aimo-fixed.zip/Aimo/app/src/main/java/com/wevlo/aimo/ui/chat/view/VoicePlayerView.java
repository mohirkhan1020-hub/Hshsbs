package com.wevlo.aimo.ui.chat.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Base64;
import android.view.Gravity;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.wevlo.aimo.R;
import com.wevlo.aimo.utils.AudioPlayerHelper;
import com.wevlo.aimo.utils.DateUtils;

import java.io.File;
import java.io.FileOutputStream;

public class VoicePlayerView extends LinearLayout {

    private final ImageButton btnPlayPause;
    private final SeekBar seekBar;
    private final TextView tvDuration;

    private String boundId = "";
    private String mediaBase64 = "";
    private String localPath = "";
    private long durationMs = 0L;

    public VoicePlayerView(Context context) {
        this(context, null);
    }

    public VoicePlayerView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VoicePlayerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        int pad = (int) (4 * getResources().getDisplayMetrics().density);
        setPadding(pad, pad, pad, pad);

        int btnSize = (int) (36 * getResources().getDisplayMetrics().density);
        btnPlayPause = new ImageButton(context);
        btnPlayPause.setLayoutParams(new LayoutParams(btnSize, btnSize));
        btnPlayPause.setBackgroundResource(R.drawable.bg_ripple_circle);
        btnPlayPause.setImageResource(R.drawable.ic_play);
        addView(btnPlayPause);

        seekBar = new SeekBar(context);
        LayoutParams sbParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        sbParams.setMargins(pad, 0, pad, 0);
        seekBar.setLayoutParams(sbParams);
        addView(seekBar);

        tvDuration = new TextView(context);
        tvDuration.setTextSize(11f);
        tvDuration.setTextColor(ContextCompat.getColor(context, R.color.aimo_text_secondary));
        addView(tvDuration);

        btnPlayPause.setOnClickListener(v -> togglePlay());
    }

    public void bind(String messageId, String mediaBase64, String localPath, long durationMs) {
        this.boundId = messageId != null ? messageId : "";
        this.mediaBase64 = mediaBase64 != null ? mediaBase64 : "";
        this.localPath = localPath != null ? localPath : "";
        this.durationMs = durationMs;

        tvDuration.setText(DateUtils.formatDuration(Math.max(0, durationMs / 1000L)));
        boolean playing = AudioPlayerHelper.getInstance().isPlaying(boundId);
        btnPlayPause.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        if (!playing) seekBar.setProgress(0);
    }

    private void togglePlay() {
        AudioPlayerHelper helper = AudioPlayerHelper.getInstance();
        if (helper.isPlaying(boundId)) {
            helper.stop();
            btnPlayPause.setImageResource(R.drawable.ic_play);
            seekBar.setProgress(0);
            return;
        }

        File file = resolveAudioFile();
        if (file == null || !file.exists()) return;

        btnPlayPause.setImageResource(R.drawable.ic_pause);
        helper.play(boundId, file, new AudioPlayerHelper.Callback() {
            @Override
            public void onProgress(int currentMs, int totalMs) {
                if (totalMs > 0) {
                    seekBar.setMax(totalMs);
                    seekBar.setProgress(currentMs);
                    tvDuration.setText(DateUtils.formatDuration(currentMs / 1000L));
                }
            }

            @Override
            public void onCompleted() {
                btnPlayPause.setImageResource(R.drawable.ic_play);
                seekBar.setProgress(0);
                tvDuration.setText(DateUtils.formatDuration(Math.max(0, durationMs / 1000L)));
            }
        });
    }

    private File resolveAudioFile() {
        if (!localPath.isEmpty()) {
            File local = new File(localPath);
            if (local.exists()) return local;
        }
        if (mediaBase64.isEmpty()) return null;
        File cached = new File(getContext().getCacheDir(), "voice_" + boundId + ".m4a");
        if (cached.exists()) return cached;
        try (FileOutputStream fos = new FileOutputStream(cached)) {
            byte[] decoded = Base64.decode(mediaBase64, Base64.DEFAULT);
            fos.write(decoded);
            return cached;
        } catch (Exception e) {
            return null;
        }
    }
}
