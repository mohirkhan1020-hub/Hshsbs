package com.wevlo.aimo.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.wevlo.aimo.db.converters.DateConverter;
import com.wevlo.aimo.db.dao.CallLogDao;
import com.wevlo.aimo.db.dao.GroupDao;
import com.wevlo.aimo.db.dao.MessageDao;
import com.wevlo.aimo.db.dao.StatusDao;
import com.wevlo.aimo.db.dao.UserDao;
import com.wevlo.aimo.db.entity.CallLogEntity;
import com.wevlo.aimo.db.entity.GroupEntity;
import com.wevlo.aimo.db.entity.MessageEntity;
import com.wevlo.aimo.db.entity.StatusEntity;
import com.wevlo.aimo.db.entity.UserEntity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(
        entities = {
                UserEntity.class,
                MessageEntity.class,
                StatusEntity.class,
                CallLogEntity.class,
                GroupEntity.class
        },
        version = 1,
        exportSchema = true
)
@TypeConverters({DateConverter.class})
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;
    public static final ExecutorService dbExecutor = Executors.newFixedThreadPool(4);

    public abstract UserDao userDao();

    public abstract MessageDao messageDao();

    public abstract StatusDao statusDao();

    public abstract CallLogDao callLogDao();

    public abstract GroupDao groupDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "aimo_db"
                            )
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
