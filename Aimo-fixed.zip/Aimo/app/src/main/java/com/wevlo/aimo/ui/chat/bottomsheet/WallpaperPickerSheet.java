package com.wevlo.aimo.ui.chat.bottomsheet;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.databinding.SheetWallpaperPickerBinding;

import java.util.Arrays;
import java.util.List;

public class WallpaperPickerSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onWallpaperSelected(String colorHex);
    }

    private SheetWallpaperPickerBinding binding;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetWallpaperPickerBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<String> colors = Arrays.asList(
                "#0B141A",
                "#12232E",
                "#112922",
                "#22192E",
                "#2A1F1D",
                "#1D262B"
        );

        binding.rvWallpapers.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        binding.rvWallpapers.setAdapter(new RecyclerView.Adapter<SwatchVH>() {
            @NonNull
            @Override
            public SwatchVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View swatch = new View(parent.getContext());
                int height = (int) (88 * parent.getResources().getDisplayMetrics().density);
                int margin = (int) (6 * parent.getResources().getDisplayMetrics().density);
                RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, height);
                lp.setMargins(margin, margin, margin, margin);
                swatch.setLayoutParams(lp);
                return new SwatchVH(swatch);
            }

            @Override
            public void onBindViewHolder(@NonNull SwatchVH holder, int position) {
                String hex = colors.get(position);
                holder.itemView.setBackgroundColor(Color.parseColor(hex));
                holder.itemView.setOnClickListener(v -> {
                    if (listener != null) listener.onWallpaperSelected(hex);
                    dismiss();
                });
            }

            @Override
            public int getItemCount() {
                return colors.size();
            }
        });

        binding.btnResetWallpaper.setOnClickListener(v -> {
            if (listener != null) listener.onWallpaperSelected("#0B141A");
            dismiss();
        });
    }

    static class SwatchVH extends RecyclerView.ViewHolder {
        SwatchVH(@NonNull View itemView) {
            super(itemView);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
