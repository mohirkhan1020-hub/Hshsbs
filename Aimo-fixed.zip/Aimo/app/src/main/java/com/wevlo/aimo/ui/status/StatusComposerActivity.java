package com.wevlo.aimo.ui.status;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.StatusModel;
import com.wevlo.aimo.databinding.ActivityStatusComposerBinding;
import com.wevlo.aimo.db.AppDatabase;
import com.wevlo.aimo.db.entity.StatusEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;
import com.wevlo.aimo.utils.FirestorePaths;
import com.wevlo.aimo.utils.ImageCompressor;

import java.util.UUID;

public class StatusComposerActivity extends AppCompatActivity {

    private ActivityStatusComposerBinding binding;
    private final String[] bgPalette = {"#005C4B", "#1F2C34", "#7F66FF", "#BF2E97", "#0095FF"};
    private int bgIndex = 0;
    private Bitmap selectedBitmap;

    private final ActivityResultLauncher<String> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) loadImage(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStatusComposerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        applyBackgroundColor();
        binding.btnClose.setOnClickListener(v -> finish());
        binding.btnPickColor.setOnClickListener(v -> {
            bgIndex = (bgIndex + 1) % bgPalette.length;
            applyBackgroundColor();
        });
        binding.btnPickImage.setOnClickListener(v -> pickImageLauncher.launch("image/*"));
        binding.fabPublishStatus.setOnClickListener(v -> publishStatus());
    }

    private void applyBackgroundColor() {
        binding.rootComposer.setBackgroundColor(Color.parseColor(bgPalette[bgIndex]));
    }

    private void loadImage(Uri uri) {
        AppDatabase.dbExecutor.execute(() -> {
            Bitmap bmp = ImageCompressor.decodeSampledBitmap(this, uri, Constants.MAX_IMAGE_DIM);
            runOnUiThread(() -> {
                if (bmp != null) {
                    selectedBitmap = bmp;
                    binding.ivStatusPreview.setImageBitmap(bmp);
                    binding.ivStatusPreview.setVisibility(View.VISIBLE);
                }
            });
        });
    }

    private void publishStatus() {
        String text = binding.etStatusText.getText() != null
                ? binding.etStatusText.getText().toString().trim() : "";
        if (text.isEmpty() && selectedBitmap == null) {
            Toast.makeText(this, "Write something or pick an image", Toast.LENGTH_SHORT).show();
            return;
        }
        binding.fabPublishStatus.setEnabled(false);
        String myUid = FirebaseAuth.getInstance().getUid() != null ? FirebaseAuth.getInstance().getUid() : "";
        String myName = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE).getString(Constants.PREF_CURRENT_NAME, "Me");

        AppDatabase.dbExecutor.execute(() -> {
            String statusId = UUID.randomUUID().toString();
            String type = selectedBitmap != null ? Constants.MSG_IMAGE : Constants.MSG_TEXT;
            StatusModel model = new StatusModel(statusId, myUid, myName, type, text);
            model.bgColor = bgPalette[bgIndex];
            if (selectedBitmap != null) {
                model.mediaBase64 = Base64ImageUtils.bitmapToBase64(selectedBitmap);
            }
            AppDatabase.getInstance(this).statusDao().insert(StatusEntity.fromModel(model));
            FirestorePaths.statusesCol().document(statusId).set(model);
            runOnUiThread(() -> {
                Toast.makeText(this, "Status posted", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }
}
