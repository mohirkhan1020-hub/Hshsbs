package com.wevlo.aimo;

public final class Constants {

    private Constants() {
    }

    // Firestore Collections
    public static final String COL_USERS = "users";
    public static final String COL_CHATS = "chats";
    public static final String COL_MESSAGES = "messages";
    public static final String COL_STATUS = "statuses";
    public static final String COL_CALLS = "calls";
    public static final String COL_GROUPS = "groups";
    public static final String COL_DEVICE_BINDINGS = "device_bindings";
    public static final String COL_APP_CONFIG = "app_config";

    // Message Types
    public static final String MSG_TEXT = "TEXT";
    public static final String MSG_IMAGE = "IMAGE";
    public static final String MSG_VIDEO = "VIDEO";
    public static final String MSG_AUDIO = "AUDIO";
    public static final String MSG_DOCUMENT = "DOCUMENT";
    public static final String MSG_LOCATION = "LOCATION";
    public static final String MSG_CONTACT = "CONTACT";
    public static final String MSG_SYSTEM = "SYSTEM";

    // Message Delivery Status
    public static final int STATUS_SENDING = 0;
    public static final int STATUS_SENT = 1;
    public static final int STATUS_DELIVERED = 2;
    public static final int STATUS_READ = 3;

    // Call Types & Directions
    public static final String CALL_DIR_INCOMING = "INCOMING";
    public static final String CALL_DIR_OUTGOING = "OUTGOING";
    public static final String CALL_DIR_MISSED = "MISSED";

    public static final String CALL_STATE_RINGING = "RINGING";
    public static final String CALL_STATE_CONNECTED = "CONNECTED";
    public static final String CALL_STATE_ENDED = "ENDED";
    public static final String CALL_STATE_DECLINED = "DECLINED";
    public static final String CALL_STATE_MISSED = "MISSED";

    // Intent Extras
    public static final String EXTRA_CHAT_ID = "extra_chat_id";
    public static final String EXTRA_PEER_UID = "extra_peer_uid";
    public static final String EXTRA_PEER_NAME = "extra_peer_name";
    public static final String EXTRA_PEER_PHOTO = "extra_peer_photo";
    public static final String EXTRA_IS_GROUP = "extra_is_group";
    public static final String EXTRA_CALL_ID = "extra_call_id";
    public static final String EXTRA_IS_VIDEO = "extra_is_video";
    public static final String EXTRA_IS_INCOMING = "extra_is_incoming";
    public static final String EXTRA_MEDIA_URI = "extra_media_uri";
    public static final String EXTRA_MEDIA_TYPE = "extra_media_type";
    public static final String EXTRA_STATUS_USER_ID = "extra_status_user_id";
    public static final String EXTRA_GROUP_ID = "extra_group_id";

    // Notification Channels & IDs
    public static final String CHANNEL_MESSAGES = "aimo_messages";
    public static final String CHANNEL_CALLS = "aimo_calls";
    public static final String CHANNEL_SERVICE = "aimo_service";

    public static final int NOTIF_ID_BG_SERVICE = 1001;
    public static final int NOTIF_ID_ACTIVE_CALL = 1002;
    public static final int NOTIF_ID_INCOMING_CALL = 1003;
    public static final int NOTIF_ID_SCREEN_SHARE = 1004;

    // SharedPreferences Keys
    public static final String PREF_NAME = "aimo_prefs";
    public static final String PREF_DEVICE_ID = "device_id";
    public static final String PREF_CURRENT_UID = "current_uid";
    public static final String PREF_CURRENT_NAME = "current_name";
    public static final String PREF_WALLPAPER_COLOR = "wallpaper_color";
    public static final String PREF_WALLPAPER_URI = "wallpaper_uri";
    public static final String PREF_FCM_TOKEN = "fcm_token";

    // Media & Limits
    public static final int MAX_IMAGE_DIM = 1024;
    public static final int IMAGE_QUALITY = 75;
    public static final int MAX_BASE64_BYTES = 700000;
    public static final long STATUS_TTL_MS = 24L * 60L * 60L * 1000L;
}
