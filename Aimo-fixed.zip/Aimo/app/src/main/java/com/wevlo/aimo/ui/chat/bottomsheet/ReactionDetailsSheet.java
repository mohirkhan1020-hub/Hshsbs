package com.wevlo.aimo.ui.chat.bottomsheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.R;
import com.wevlo.aimo.databinding.SheetReactionDetailsBinding;

import java.util.ArrayList;
import java.util.Map;

public class ReactionDetailsSheet extends BottomSheetDialogFragment {

    private static final String ARG_USERS = "users";
    private static final String ARG_EMOJIS = "emojis";

    private SheetReactionDetailsBinding binding;

    public static ReactionDetailsSheet newInstance(Map<String, String> reactions) {
        ReactionDetailsSheet sheet = new ReactionDetailsSheet();
        Bundle args = new Bundle();
        ArrayList<String> users = new ArrayList<>();
        ArrayList<String> emojis = new ArrayList<>();
        if (reactions != null) {
            for (Map.Entry<String, String> entry : reactions.entrySet()) {
                users.add(entry.getKey());
                emojis.add(entry.getValue());
            }
        }
        args.putStringArrayList(ARG_USERS, users);
        args.putStringArrayList(ARG_EMOJIS, emojis);
        sheet.setArguments(args);
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetReactionDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ArrayList<String> users = getArguments() != null
                ? getArguments().getStringArrayList(ARG_USERS) : new ArrayList<>();
        ArrayList<String> emojis = getArguments() != null
                ? getArguments().getStringArrayList(ARG_EMOJIS) : new ArrayList<>();
        if (users == null) users = new ArrayList<>();
        if (emojis == null) emojis = new ArrayList<>();

        ArrayList<String> finalUsers = users;
        ArrayList<String> finalEmojis = emojis;
        binding.tvReactionCount.setText(finalUsers.size() + " reactions");
        binding.rvReactionDetails.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvReactionDetails.setAdapter(new RecyclerView.Adapter<VH>() {
            @NonNull
            @Override
            public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_reaction, parent, false);
                return new VH(v);
            }

            @Override
            public void onBindViewHolder(@NonNull VH holder, int position) {
                holder.tvUser.setText(finalUsers.get(position));
                holder.tvEmoji.setText(finalEmojis.get(position));
            }

            @Override
            public int getItemCount() {
                return finalUsers.size();
            }
        });
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvUser;
        final TextView tvEmoji;

        VH(@NonNull View itemView) {
            super(itemView);
            tvUser = itemView.findViewById(R.id.tvReactorUid);
            tvEmoji = itemView.findViewById(R.id.tvEmoji);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
