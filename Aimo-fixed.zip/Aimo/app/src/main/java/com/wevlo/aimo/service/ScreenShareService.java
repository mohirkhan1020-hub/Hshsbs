package com.wevlo.aimo.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;

public class ScreenShareService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = new NotificationCompat.Builder(this, Constants.CHANNEL_SERVICE)
                .setSmallIcon(R.drawable.ic_stat_aimo)
                .setContentTitle("Aimo Screen Sharing")
                .setContentText("Your screen is being shared in the call")
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    Constants.NOTIF_ID_SCREEN_SHARE,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            );
        } else {
            startForeground(Constants.NOTIF_ID_SCREEN_SHARE, notification);
        }
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
