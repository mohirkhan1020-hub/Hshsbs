package com.wevlo.aimo.data;

import com.wevlo.aimo.Constants;

import java.util.HashMap;
import java.util.Map;

public class MessageModel {

    public String messageId = "";
    public String chatId = "";
    public String senderId = "";
    public String senderName = "";
    public String receiverId = "";
    public String type = Constants.MSG_TEXT;
    public String text = "";
    public String mediaBase64 = "";
    public String mediaUrl = "";
    public String localPath = "";
    public String fileName = "";
    public long mediaSize = 0L;
    public long durationMs = 0L;
    public long timestamp = 0L;
    public int status = Constants.STATUS_SENDING;

    public String replyToId = "";
    public String replyToText = "";
    public String replyToSender = "";

    public boolean forwarded = false;
    public boolean edited = false;
    public boolean deleted = false;
    public boolean starred = false;

    public Map<String, String> reactions = new HashMap<>();

    public MessageModel() {
    }

    public MessageModel(String messageId, String chatId, String senderId, String senderName,
                        String receiverId, String type, String text) {
        this.messageId = messageId != null ? messageId : "";
        this.chatId = chatId != null ? chatId : "";
        this.senderId = senderId != null ? senderId : "";
        this.senderName = senderName != null ? senderName : "";
        this.receiverId = receiverId != null ? receiverId : "";
        this.type = type != null ? type : Constants.MSG_TEXT;
        this.text = text != null ? text : "";
        this.timestamp = System.currentTimeMillis();
    }
}
