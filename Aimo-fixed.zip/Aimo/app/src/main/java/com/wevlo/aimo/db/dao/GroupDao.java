package com.wevlo.aimo.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.wevlo.aimo.db.entity.GroupEntity;

import java.util.List;

@Dao
public interface GroupDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(GroupEntity group);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<GroupEntity> groups);

    @Update
    void update(GroupEntity group);

    @Query("SELECT * FROM groups ORDER BY pinned DESC, lastMessageTime DESC, name ASC")
    LiveData<List<GroupEntity>> observeAllGroups();

    @Query("SELECT * FROM groups ORDER BY lastMessageTime DESC")
    List<GroupEntity> getAllGroupsSync();

    @Query("SELECT * FROM groups WHERE groupId = :groupId LIMIT 1")
    LiveData<GroupEntity> observeGroup(String groupId);

    @Query("SELECT * FROM groups WHERE groupId = :groupId LIMIT 1")
    GroupEntity getGroupById(String groupId);

    @Query("UPDATE groups SET unreadCount = 0 WHERE groupId = :groupId")
    void clearUnread(String groupId);

    @Query("UPDATE groups SET pinned = :pinned WHERE groupId = :groupId")
    void setPinned(String groupId, boolean pinned);

    @Query("UPDATE groups SET muted = :muted WHERE groupId = :groupId")
    void setMuted(String groupId, boolean muted);

    @Query("UPDATE groups SET archived = :archived WHERE groupId = :groupId")
    void setArchived(String groupId, boolean archived);

    @Query("DELETE FROM groups WHERE groupId = :groupId")
    void deleteById(String groupId);

    @Query("DELETE FROM groups")
    void deleteAll();
}
