package com.wevlo.aimo.service;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.data.CallLogModel;
import com.wevlo.aimo.notification.NotificationHelper;
import com.wevlo.aimo.receiver.AlarmRestartReceiver;
import com.wevlo.aimo.ui.home.MainActivity;
import com.wevlo.aimo.utils.FirestorePaths;

public class WhatsAppBgService extends Service {

    private ListenerRegistration incomingCallListener;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        attachCallListener();
        return START_STICKY;
    }

    private void startAsForeground() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, Constants.CHANNEL_SERVICE)
                .setSmallIcon(R.drawable.ic_stat_aimo)
                .setContentTitle("Aimo")
                .setContentText("Connected for messages and calls")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pi)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    Constants.NOTIF_ID_BG_SERVICE,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            );
        } else {
            startForeground(Constants.NOTIF_ID_BG_SERVICE, notification);
        }
    }

    private void attachCallListener() {
        String myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null || incomingCallListener != null) return;

        incomingCallListener = FirestorePaths.callsCol()
                .whereEqualTo("receiverId", myUid)
                .whereEqualTo("status", Constants.CALL_STATE_RINGING)
                .addSnapshotListener((snapshots, error) -> {
                    if (snapshots == null || snapshots.isEmpty()) return;
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        CallLogModel call = doc.toObject(CallLogModel.class);
                        if (call != null) {
                            NotificationHelper.showIncomingCallNotification(
                                    this, call.callId, call.callerId, call.callerName, call.isVideo);
                            break;
                        }
                    }
                });
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartIntent = new Intent(this, AlarmRestartReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                this, 0, restartIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (am != null) {
            am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 2000, pi);
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (incomingCallListener != null) {
            incomingCallListener.remove();
            incomingCallListener = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
