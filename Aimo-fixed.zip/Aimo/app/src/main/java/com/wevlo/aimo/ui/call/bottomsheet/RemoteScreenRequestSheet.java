package com.wevlo.aimo.ui.call.bottomsheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.databinding.SheetDeviceBoundBinding;

public class RemoteScreenRequestSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onConfirmed();
    }

    private SheetDeviceBoundBinding binding;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetDeviceBoundBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.tvBoundDeviceInfo.setText(
                "Share your screen with the other participant during this call?"
        );
        binding.btnSwitchDevice.setText("Start Screen Share");
        binding.btnSwitchDevice.setOnClickListener(v -> {
            if (listener != null) listener.onConfirmed();
            dismiss();
        });
        binding.btnCancel.setOnClickListener(v -> dismiss());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
