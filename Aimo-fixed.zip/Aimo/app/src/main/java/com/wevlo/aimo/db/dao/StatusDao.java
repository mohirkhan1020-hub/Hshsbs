package com.wevlo.aimo.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.wevlo.aimo.db.entity.StatusEntity;

import java.util.List;

@Dao
public interface StatusDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(StatusEntity status);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<StatusEntity> statuses);

    @Query("SELECT * FROM statuses WHERE expiresAt > :now ORDER BY timestamp DESC")
    LiveData<List<StatusEntity>> observeActiveStatuses(long now);

    @Query("SELECT * FROM statuses WHERE userId = :userId AND expiresAt > :now ORDER BY timestamp ASC")
    List<StatusEntity> getStatusesByUser(String userId, long now);

    @Query("DELETE FROM statuses WHERE expiresAt <= :now")
    void deleteExpired(long now);

    @Query("DELETE FROM statuses WHERE statusId = :statusId")
    void deleteById(String statusId);

    @Query("DELETE FROM statuses")
    void deleteAll();
}
