package com.wevlo.aimo.ui.status.adapter;

import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.R;
import com.wevlo.aimo.db.entity.StatusEntity;
import com.wevlo.aimo.utils.Base64ImageUtils;

import java.util.ArrayList;
import java.util.List;

public class StatusStoryAdapter extends RecyclerView.Adapter<StatusStoryAdapter.StoryVH> {

    private final List<StatusEntity> items = new ArrayList<>();

    public void submitList(List<StatusEntity> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StoryVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        FrameLayout root = new FrameLayout(parent.getContext());
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        ImageView imageView = new ImageView(parent.getContext());
        imageView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);

        TextView textView = new TextView(parent.getContext());
        FrameLayout.LayoutParams tvLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );
        int pad = (int) (24 * parent.getResources().getDisplayMetrics().density);
        textView.setPadding(pad, pad, pad, pad);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(22f);
        textView.setLayoutParams(tvLp);

        root.addView(imageView);
        root.addView(textView);
        return new StoryVH(root, imageView, textView);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryVH holder, int position) {
        StatusEntity item = items.get(position);
        try {
            holder.root.setBackgroundColor(Color.parseColor(
                    item.bgColor != null && !item.bgColor.isEmpty() ? item.bgColor : "#005C4B"));
        } catch (Exception e) {
            holder.root.setBackgroundColor(Color.parseColor("#005C4B"));
        }

        boolean hasImage = Constants.MSG_IMAGE.equals(item.type) && !item.mediaBase64.isEmpty();
        holder.imageView.setVisibility(hasImage ? View.VISIBLE : View.GONE);
        if (hasImage) {
            Base64ImageUtils.loadImage(holder.imageView, "status_" + item.statusId,
                    item.mediaBase64, item.mediaUrl, R.drawable.bg_avatar_placeholder);
        }

        holder.textView.setVisibility(!item.text.isEmpty() ? View.VISIBLE : View.GONE);
        holder.textView.setText(item.text);
        if (hasImage) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) holder.textView.getLayoutParams();
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.bottomMargin = (int) (80 * holder.root.getResources().getDisplayMetrics().density);
            holder.textView.setLayoutParams(lp);
            holder.textView.setTextSize(16f);
        } else {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) holder.textView.getLayoutParams();
            lp.gravity = Gravity.CENTER;
            lp.bottomMargin = 0;
            holder.textView.setLayoutParams(lp);
            holder.textView.setTextSize(22f);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class StoryVH extends RecyclerView.ViewHolder {
        final FrameLayout root;
        final ImageView imageView;
        final TextView textView;

        StoryVH(@NonNull FrameLayout root, ImageView imageView, TextView textView) {
            super(root);
            this.root = root;
            this.imageView = imageView;
            this.textView = textView;
        }
    }
}
