package com.wevlo.aimo.db.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.StatusModel;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "statuses")
public class StatusEntity {

    @PrimaryKey
    @NonNull
    public String statusId = "";

    public String userId = "";
    public String userName = "";
    public String userPhoto = "";
    public String type = Constants.MSG_TEXT;
    public String text = "";
    public String mediaBase64 = "";
    public String mediaUrl = "";
    public String bgColor = "#005C4B";
    public long timestamp = 0L;
    public long expiresAt = 0L;
    public List<String> viewers = new ArrayList<>();

    public StatusEntity() {
    }

    @Ignore
    public static StatusEntity fromModel(StatusModel model) {
        StatusEntity entity = new StatusEntity();
        if (model == null) return entity;
        entity.statusId = model.statusId != null ? model.statusId : "";
        entity.userId = model.userId != null ? model.userId : "";
        entity.userName = model.userName != null ? model.userName : "";
        entity.userPhoto = model.userPhoto != null ? model.userPhoto : "";
        entity.type = model.type != null ? model.type : Constants.MSG_TEXT;
        entity.text = model.text != null ? model.text : "";
        entity.mediaBase64 = model.mediaBase64 != null ? model.mediaBase64 : "";
        entity.mediaUrl = model.mediaUrl != null ? model.mediaUrl : "";
        entity.bgColor = model.bgColor != null ? model.bgColor : "#005C4B";
        entity.timestamp = model.timestamp;
        entity.expiresAt = model.expiresAt;
        entity.viewers = model.viewers != null ? new ArrayList<>(model.viewers) : new ArrayList<>();
        return entity;
    }
}
