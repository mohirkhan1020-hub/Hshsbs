package com.wevlo.aimo.ui.auth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wevlo.aimo.databinding.SheetDeviceBoundBinding;

public class DeviceBoundSheet extends BottomSheetDialogFragment {

    private static final String ARG_DEVICE_NAME = "arg_device_name";
    private SheetDeviceBoundBinding binding;
    private Listener listener;

    public interface Listener {
        void onSwitchDeviceConfirmed();
        void onSwitchDeviceCancelled();
    }

    public static DeviceBoundSheet newInstance(String existingDeviceName) {
        DeviceBoundSheet sheet = new DeviceBoundSheet();
        Bundle args = new Bundle();
        args.putString(ARG_DEVICE_NAME, existingDeviceName);
        sheet.setArguments(args);
        return sheet;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = SheetDeviceBoundBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        String deviceName = getArguments() != null
                ? getArguments().getString(ARG_DEVICE_NAME, "another device")
                : "another device";
        binding.tvBoundDeviceInfo.setText(
                "This account is currently active on " + deviceName
                        + ". Switching will sign out the previous device."
        );

        binding.btnSwitchDevice.setOnClickListener(v -> {
            if (listener != null) listener.onSwitchDeviceConfirmed();
            dismiss();
        });

        binding.btnCancel.setOnClickListener(v -> {
            if (listener != null) listener.onSwitchDeviceCancelled();
            dismiss();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
