package com.wevlo.aimo.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import com.wevlo.aimo.Constants;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public final class ImageCompressor {

    private ImageCompressor() {
    }

    public static Bitmap decodeSampledBitmap(Context context, Uri uri, int maxDim) {
        if (context == null || uri == null) return null;
        try (InputStream boundsStream = context.getContentResolver().openInputStream(uri)) {
            if (boundsStream == null) return null;

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(boundsStream, null, options);

            int sampleSize = 1;
            int width = options.outWidth;
            int height = options.outHeight;
            while (width / sampleSize > maxDim || height / sampleSize > maxDim) {
                sampleSize *= 2;
            }

            BitmapFactory.Options decodeOpts = new BitmapFactory.Options();
            decodeOpts.inSampleSize = sampleSize;

            try (InputStream decodeStream = context.getContentResolver().openInputStream(uri)) {
                if (decodeStream == null) return null;
                Bitmap bitmap = BitmapFactory.decodeStream(decodeStream, null, decodeOpts);
                if (bitmap == null) return null;
                return fixOrientation(context, uri, scaleDown(bitmap, maxDim));
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap scaleDown(Bitmap source, int maxDim) {
        if (source == null) return null;
        int w = source.getWidth();
        int h = source.getHeight();
        if (w <= maxDim && h <= maxDim) return source;
        float ratio = Math.min((float) maxDim / w, (float) maxDim / h);
        int newW = Math.max(1, Math.round(w * ratio));
        int newH = Math.max(1, Math.round(h * ratio));
        return Bitmap.createScaledBitmap(source, newW, newH, true);
    }

    private static Bitmap fixOrientation(Context context, Uri uri, Bitmap bitmap) {
        if (bitmap == null) return null;
        try (InputStream exifStream = context.getContentResolver().openInputStream(uri)) {
            if (exifStream == null) return bitmap;
            ExifInterface exif = new ExifInterface(exifStream);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
            );
            int degrees = 0;
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) degrees = 90;
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) degrees = 180;
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) degrees = 270;

            if (degrees == 0) return bitmap;
            Matrix matrix = new Matrix();
            matrix.postRotate(degrees);
            return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        } catch (Exception e) {
            return bitmap;
        }
    }

    public static byte[] compressToJpeg(Bitmap bitmap, int maxBytes) {
        if (bitmap == null) return new byte[0];
        int quality = Constants.IMAGE_QUALITY;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out);

        while (out.toByteArray().length > maxBytes && quality > 25) {
            out.reset();
            quality -= 10;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out);
        }
        return out.toByteArray();
    }
}
