package com.wevlo.aimo.data;

import com.wevlo.aimo.Constants;

import java.util.ArrayList;
import java.util.List;

public class CallLogModel {

    public String callId = "";
    public String callerId = "";
    public String callerName = "";
    public String callerPhoto = "";
    public String receiverId = "";
    public String receiverName = "";
    public String receiverPhoto = "";
    public boolean isVideo = false;
    public String direction = Constants.CALL_DIR_OUTGOING;
    public String status = Constants.CALL_STATE_RINGING;
    public String offerSdp = "";
    public String answerSdp = "";
    public List<String> callerCandidates = new ArrayList<>();
    public List<String> calleeCandidates = new ArrayList<>();
    public long startedAt = 0L;
    public long endedAt = 0L;
    public long durationSec = 0L;

    public CallLogModel() {
    }

    public CallLogModel(String callId, String callerId, String callerName,
                        String receiverId, String receiverName, boolean isVideo) {
        this.callId = callId != null ? callId : "";
        this.callerId = callerId != null ? callerId : "";
        this.callerName = callerName != null ? callerName : "";
        this.receiverId = receiverId != null ? receiverId : "";
        this.receiverName = receiverName != null ? receiverName : "";
        this.isVideo = isVideo;
        this.startedAt = System.currentTimeMillis();
    }
}
