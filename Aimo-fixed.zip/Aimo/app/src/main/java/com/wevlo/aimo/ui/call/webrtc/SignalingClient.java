package com.wevlo.aimo.ui.call.webrtc;

import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.gson.Gson;
import com.wevlo.aimo.Constants;
import com.wevlo.aimo.data.CallLogModel;
import com.wevlo.aimo.utils.FirestorePaths;

import org.webrtc.IceCandidate;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SignalingClient {

    public interface Listener {
        void onOfferReceived(String sdp);
        void onAnswerReceived(String sdp);
        void onIceCandidateReceived(IceCandidate candidate);
        void onCallEnded(String status);
    }

    private final String callId;
    private final boolean isCaller;
    private final Gson gson = new Gson();
    private final Set<String> processedCandidates = new HashSet<>();
    private ListenerRegistration registration;
    private boolean sdpDispatched = false;

    public SignalingClient(String callId, boolean isCaller) {
        this.callId = callId;
        this.isCaller = isCaller;
    }

    public void createCallDocument(CallLogModel model) {
        FirestorePaths.callDoc(callId).set(model);
    }

    public void sendOffer(String sdp) {
        FirestorePaths.callDoc(callId).update("offerSdp", sdp);
    }

    public void sendAnswer(String sdp) {
        FirestorePaths.callDoc(callId).update(
                "answerSdp", sdp,
                "status", Constants.CALL_STATE_CONNECTED
        );
    }

    public void sendIceCandidate(IceCandidate candidate) {
        String field = isCaller ? "callerCandidates" : "calleeCandidates";
        String json = gson.toJson(new CandidatePayload(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp));
        FirestorePaths.callDoc(callId).update(field, FieldValue.arrayUnion(json));
    }

    public void updateCallStatus(String status, long durationSec) {
        FirestorePaths.callDoc(callId).update(
                "status", status,
                "endedAt", System.currentTimeMillis(),
                "durationSec", durationSec
        );
    }

    public void listen(Listener listener) {
        registration = FirestorePaths.callDoc(callId).addSnapshotListener((snapshot, error) -> {
            if (snapshot == null || !snapshot.exists() || listener == null) return;
            CallLogModel model = snapshot.toObject(CallLogModel.class);
            if (model == null) return;

            if (Constants.CALL_STATE_ENDED.equals(model.status)
                    || Constants.CALL_STATE_DECLINED.equals(model.status)
                    || Constants.CALL_STATE_MISSED.equals(model.status)) {
                listener.onCallEnded(model.status);
                return;
            }

            if (!sdpDispatched) {
                if (isCaller && model.answerSdp != null && !model.answerSdp.isEmpty()) {
                    sdpDispatched = true;
                    listener.onAnswerReceived(model.answerSdp);
                } else if (!isCaller && model.offerSdp != null && !model.offerSdp.isEmpty()) {
                    sdpDispatched = true;
                    listener.onOfferReceived(model.offerSdp);
                }
            }

            List<String> remoteCandidates = isCaller ? model.calleeCandidates : model.callerCandidates;
            if (remoteCandidates != null) {
                for (String raw : remoteCandidates) {
                    if (processedCandidates.add(raw)) {
                        CandidatePayload payload = gson.fromJson(raw, CandidatePayload.class);
                        if (payload != null) {
                            listener.onIceCandidateReceived(
                                    new IceCandidate(payload.sdpMid, payload.sdpMLineIndex, payload.sdp));
                        }
                    }
                }
            }
        });
    }

    public void stop() {
        if (registration != null) {
            registration.remove();
            registration = null;
        }
    }

    private static class CandidatePayload {
        final String sdpMid;
        final int sdpMLineIndex;
        final String sdp;

        CandidatePayload(String sdpMid, int sdpMLineIndex, String sdp) {
            this.sdpMid = sdpMid;
            this.sdpMLineIndex = sdpMLineIndex;
            this.sdp = sdp;
        }
    }
}
