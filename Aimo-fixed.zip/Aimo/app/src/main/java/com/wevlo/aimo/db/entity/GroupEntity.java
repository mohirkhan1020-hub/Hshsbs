package com.wevlo.aimo.db.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.wevlo.aimo.data.GroupModel;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "groups")
public class GroupEntity {

    @PrimaryKey
    @NonNull
    public String groupId = "";

    public String name = "";
    public String description = "";
    public String photoBase64 = "";
    public String photoUrl = "";
    public String createdBy = "";
    public long createdAt = 0L;
    public List<String> memberIds = new ArrayList<>();
    public List<String> adminIds = new ArrayList<>();
    public String lastMessage = "";
    public String lastMessageSender = "";
    public long lastMessageTime = 0L;
    public int unreadCount = 0;
    public boolean pinned = false;
    public boolean muted = false;
    public boolean archived = false;
    public boolean onlyAdminsCanSend = false;

    public GroupEntity() {
    }

    @Ignore
    public static GroupEntity fromModel(GroupModel model) {
        GroupEntity entity = new GroupEntity();
        if (model == null) return entity;
        entity.groupId = model.groupId != null ? model.groupId : "";
        entity.name = model.name != null ? model.name : "";
        entity.description = model.description != null ? model.description : "";
        entity.photoBase64 = model.photoBase64 != null ? model.photoBase64 : "";
        entity.photoUrl = model.photoUrl != null ? model.photoUrl : "";
        entity.createdBy = model.createdBy != null ? model.createdBy : "";
        entity.createdAt = model.createdAt;
        entity.memberIds = model.memberIds != null ? new ArrayList<>(model.memberIds) : new ArrayList<>();
        entity.adminIds = model.adminIds != null ? new ArrayList<>(model.adminIds) : new ArrayList<>();
        entity.lastMessage = model.lastMessage != null ? model.lastMessage : "";
        entity.lastMessageSender = model.lastMessageSender != null ? model.lastMessageSender : "";
        entity.lastMessageTime = model.lastMessageTime;
        entity.onlyAdminsCanSend = model.onlyAdminsCanSend;
        return entity;
    }
}
