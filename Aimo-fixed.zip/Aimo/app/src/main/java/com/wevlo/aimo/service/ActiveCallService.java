package com.wevlo.aimo.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.wevlo.aimo.Constants;
import com.wevlo.aimo.notification.CallNotificationBuilder;

public class ActiveCallService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String peerName = intent != null ? intent.getStringExtra(Constants.EXTRA_PEER_NAME) : "";
        Notification notification = CallNotificationBuilder.buildActiveCallNotification(this, peerName);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                    Constants.NOTIF_ID_ACTIVE_CALL,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            );
        } else {
            startForeground(Constants.NOTIF_ID_ACTIVE_CALL, notification);
        }
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
